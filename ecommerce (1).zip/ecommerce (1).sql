-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2019 at 03:19 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(10) UNSIGNED NOT NULL,
  `img1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description1` text COLLATE utf8mb4_unicode_ci,
  `status1` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `img2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description2` text COLLATE utf8mb4_unicode_ci,
  `status2` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `img3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description3` text COLLATE utf8mb4_unicode_ci,
  `status3` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `img4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description4` text COLLATE utf8mb4_unicode_ci,
  `status4` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `img5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description5` text COLLATE utf8mb4_unicode_ci,
  `status5` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `img1`, `link1`, `description1`, `status1`, `img2`, `link2`, `description2`, `status2`, `img3`, `link3`, `description3`, `status3`, `img4`, `link4`, `description4`, `status4`, `img5`, `link5`, `description5`, `status5`, `created_at`, `updated_at`) VALUES
(1, 'ads/larg/img1_1556448839.jpg', 'http/sara.com', NULL, '1', 'ads/larg/img2_1556447223.jpg', NULL, NULL, '1', NULL, NULL, NULL, '0', NULL, NULL, NULL, '0', 'ads/larg/img5_1556448780.jpeg', 'http/ads5.com', NULL, '1', '2019-04-28 08:27:03', '2019-04-28 08:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` longtext COLLATE utf8mb4_unicode_ci,
  `tag_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_ar`, `name_en`, `description_ar`, `description_en`, `tag_ar`, `tag_en`, `image`, `slogen_ar`, `slogen_en`, `status`, `created_at`, `updated_at`) VALUES
(3, 'الكترونيات', 'Electronic', 'هذا القسم هو القسم 1', NULL, NULL, NULL, 'category/larg/Category_1556459591.jpg', 'الكترونيات', 'electronic', '1', '2019-04-28 11:01:37', '2019-05-13 10:15:16'),
(4, 'ازياء', 'fashion', 'قسم 222', 'قسم 555', 'قسم,egh', NULL, 'category/larg/Category_1556459562.jpg', 'ازياء', 'fashion', '1', '2019-04-28 11:46:03', '2019-05-13 10:16:05'),
(5, 'موبايلات', 'mobiles & tablet', 'fdfd', NULL, NULL, NULL, NULL, 'موبايلات', 'mobiles-tablet', '1', '2019-05-08 06:59:55', '2019-05-13 10:17:07'),
(6, 'معدات', 'Tools', 'fdkkf', NULL, NULL, NULL, NULL, 'معدات', 'tools', '1', '2019-05-13 10:28:27', '2019-05-13 10:28:27'),
(7, 'مكياج', 'makupe', 'مكياج', NULL, NULL, NULL, NULL, 'مكياج', 'makupe', '1', '2019-05-13 10:28:54', '2019-05-13 10:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `category_filter`
--

CREATE TABLE `category_filter` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_filter`
--

INSERT INTO `category_filter` (`id`, `category_id`, `filter_id`, `created_at`, `updated_at`) VALUES
(3, 1, 1, NULL, NULL),
(4, 1, 2, NULL, NULL),
(5, 2, 3, NULL, NULL),
(7, 3, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_new_newsite`
--

CREATE TABLE `category_new_newsite` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `newsite_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_new_newsite`
--

INSERT INTO `category_new_newsite` (`id`, `category_id`, `newsite_id`, `created_at`, `updated_at`) VALUES
(10, 1, 7, NULL, NULL),
(12, 2, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `catergories_news`
--

CREATE TABLE `catergories_news` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `catergories_news`
--

INSERT INTO `catergories_news` (`id`, `name_ar`, `name_en`, `status`, `slogen_ar`, `slogen_en`, `created_at`, `updated_at`) VALUES
(1, 'قسم الاخبار الفنية', 'fin news', '1', 'قسم-الاخبار-الفنية', 'fin-news', '2019-04-28 12:54:06', '2019-04-29 09:46:28'),
(2, 'قسم 2', NULL, '1', 'قسم-2', '', '2019-04-29 09:45:42', '2019-04-29 09:45:42'),
(3, 'قسم 3', NULL, '0', 'قسم-3', '', '2019-04-29 09:48:29', '2019-04-29 11:24:25');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `name_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name_ar`, `name_en`, `country_id`, `name_fr`, `code`, `created_at`, `updated_at`) VALUES
(1, 'سانت جوليا دي لوريا', 'Sant Julia de Loria', 1, 'Sant Julia de Loria', '06', NULL, NULL),
(2, 'أندورا لا فيلا', 'Andorra la Vella', 1, 'Andorra la Vella', '07', NULL, NULL),
(3, 'لا ماسانا', 'La Massana', 1, 'La Massana', '04', NULL, NULL),
(4, 'أوردينو', 'Ordino', 1, 'Ordino', '05', NULL, NULL),
(5, 'كانيلو', 'Canillo', 1, 'Canillo', '02', NULL, NULL),
(6, 'نزلوا', 'Encamp', 1, 'Camper', '03', NULL, NULL),
(7, 'إسكالديس أنجوردني', 'Escaldes-Engordany', 1, 'Escaldes-Engordany', '08', NULL, NULL),
(8, 'الفجيرة', 'Fujairah', 2, 'Fujairah', '04', NULL, NULL),
(9, 'أبو ظبي', 'Abu Dhabi', 2, 'Abu Dhabi', '01', NULL, NULL),
(10, 'دبي', 'Dubai', 2, 'Dubai', '03', NULL, '2019-04-24 11:24:29'),
(11, 'رأس الخيمة', 'Ras Al Khaimah', 2, 'Ras Al Khaimah', '05', NULL, NULL),
(12, 'ام القيوين', 'Umm Al Quwain', 2, 'Umm Al Quwain', '07', NULL, NULL),
(13, 'الشارقة', 'Sharjah', 2, 'Sharjah', '06', NULL, NULL),
(14, 'عجمان', 'Ajman', 2, 'Ajman', '02', NULL, NULL),
(15, 'بكتيكا', 'Paktika', 3, 'Paktika', '29', NULL, NULL),
(16, 'فرح', 'Farah', 3, 'Farah', '06', NULL, NULL),
(17, 'هلمند', 'Helmand', 3, 'Helmand', '10', NULL, NULL),
(18, 'قندز', 'Kondoz', 3, 'Kondoz', '24', NULL, NULL),
(19, 'باميان', 'Bamian', 3, 'Bamian', '05', NULL, NULL),
(20, 'غور', 'Ghowr', 3, 'Ghowr', '09', NULL, NULL),
(21, 'لغمان', 'Laghman', 3, 'Laghman', '35', NULL, NULL),
(23, 'غزنة', 'Ghazni', 3, 'Ghazni', '08', NULL, NULL),
(24, 'ورداك', 'Vardak', 3, 'Vardak', '27', NULL, NULL),
(25, 'أوروزغان', 'Oruzgan', 3, 'Oruzgan', '39', NULL, NULL),
(26, 'زابول', 'Zabol', 3, 'Zabol', '28', NULL, NULL),
(27, 'بادغيس', 'Badghis', 3, 'Badghis', '02', NULL, NULL),
(28, 'بدخشان', 'Badakhshan', 3, 'Badakhshan', '01', NULL, NULL),
(29, 'فارياب', 'Faryab', 3, 'Faryab', '07', NULL, NULL),
(30, 'تخار', 'Takhar', 3, 'Takhar', '26', NULL, NULL),
(31, 'لوجار', 'Lowgar', 3, 'Lowgar', '17', NULL, NULL),
(32, 'هرات', 'Herat', 3, 'Herat', '11', NULL, NULL),
(33, 'دايكندي', 'Daykondi', 3, 'Daykondi', '41', NULL, NULL),
(34, 'سار بول', 'Sar-e Pol', 3, 'Sar-e Pol', '33', NULL, NULL),
(35, 'بلخ', 'Balkh', 3, 'Balkh', '30', NULL, NULL),
(36, 'كابول', 'Kabol', 3, 'Kabol', '13', NULL, NULL),
(37, 'نيمروز', 'Nimruz', 3, 'Nimruz', '19', NULL, NULL),
(38, 'قندهار', 'Kandahar', 3, 'Kandahar', '23', NULL, NULL),
(39, 'خوست', 'Khowst', 3, 'Khowst', '37', NULL, NULL),
(41, 'كابيسا', 'Kapisa', 3, 'Kapisa', '14', NULL, NULL),
(42, 'ننجرهار', 'Nangarhar', 3, 'Nangarhar', '18', NULL, NULL),
(43, 'سامانغان', 'Samangan', 3, 'Samangan', '32', NULL, NULL),
(44, 'بكتيا', 'Paktia', 3, 'Paktia', '36', NULL, NULL),
(45, 'بغلان', 'Baghlan', 3, 'Baghlan', '03', NULL, NULL),
(46, 'جوزجان', 'Jowzjan', 3, 'Jowzjan', '31', NULL, NULL),
(47, 'كونار', 'Konar', 3, 'Konar', '34', NULL, NULL),
(48, 'نورستان', 'Nurestan', 3, 'Nurestan', '38', NULL, NULL),
(52, 'بانجشير', 'Panjshir', 3, 'Panjshir', '42', NULL, NULL),
(53, 'القديس يوحنا', 'Saint John', 4, 'Saint Jean', '04', NULL, NULL),
(54, 'القديس بول', 'Saint Paul', 4, 'Saint Paul', '06', NULL, NULL),
(55, 'القديس جورج', 'Saint George', 4, 'Saint George', '03', NULL, NULL),
(56, 'القديس بطرس', 'Saint Peter', 4, 'Saint Pierre', '07', NULL, NULL),
(57, 'القديس ماري', 'Saint Mary', 4, 'Sainte Marie', '05', NULL, NULL),
(58, 'باربودا', 'Barbuda', 4, 'Barbuda', '01', NULL, NULL),
(59, 'سانت فيليب', 'Saint Philip', 4, 'Saint philippe', '08', NULL, NULL),
(61, 'فلور', 'Vlore', 6, 'Vlore', '51', NULL, NULL),
(62, 'كورتشي', 'Korce', 6, 'Korce', '46', NULL, NULL),
(63, 'شكودر', 'Shkoder', 6, 'Shkoder', '49', NULL, NULL),
(64, 'دوريس', 'Durres', 6, 'Durres', '42', NULL, NULL),
(65, 'الباسان', 'Elbasan', 6, 'Elbasan', '43', NULL, NULL),
(66, 'كوكس', 'Kukes', 6, 'Kukes', '47', NULL, NULL),
(67, 'فيير', 'Fier', 6, 'Fier', '44', NULL, NULL),
(68, 'بيرات', 'Berat', 6, 'Berat', '40', NULL, NULL),
(69, 'جيروكاستر', 'Gjirokaster', 6, 'Gjirokaster', '45', NULL, NULL),
(70, 'تيرانا', 'Tirane', 6, 'Tirane', '50', NULL, NULL),
(71, 'ليج', 'Lezhe', 6, 'Lezhe', '48', NULL, NULL),
(72, 'ديبر', 'Diber', 6, 'Diber', '41', NULL, NULL),
(73, 'Aragatsotn', 'Aragatsotn', 7, 'Aragatsotn', '01', NULL, NULL),
(74, 'أرارات', 'Ararat', 7, 'Ararat', '02', NULL, NULL),
(75, 'كوتايك', 'Kotayk\'', 7, 'Kotayk \'', '05', NULL, NULL),
(76, 'تافوش', 'Tavush', 7, 'Tavush', '09', NULL, NULL),
(77, 'سيونيك', 'Syunik\'', 7, 'Syunik \'', '08', NULL, NULL),
(78, 'Geghark\'unik \"', 'Geghark\'unik\'', 7, 'Geghark\'unik \'', '04', NULL, NULL),
(79, 'دزوتس دازور', 'Vayots\' Dzor', 7, 'Dzor de Vayots', '10', NULL, NULL),
(80, 'Lorri', 'Lorri', 7, 'Lorri', '06', NULL, NULL),
(81, 'أرمافير', 'Armavir', 7, 'Armavir', '03', NULL, NULL),
(82, 'يريفان', 'Yerevan', 7, 'Erevan', '11', NULL, NULL),
(83, 'شيراك', 'Shirak', 7, 'Shirak', '07', NULL, NULL),
(85, 'بنغيلا', 'Benguela', 9, 'Benguela', '01', NULL, NULL),
(86, 'يجي', 'Uige', 9, 'Uige', '15', NULL, NULL),
(87, 'بنغو', 'Bengo', 9, 'Bengo', '19', NULL, NULL),
(88, 'كوانزا نورتي', 'Cuanza Norte', 9, 'Cuanza Norte', '05', NULL, NULL),
(89, 'مالانج', 'Malanje', 9, 'Malanje', '12', NULL, NULL),
(90, 'كوانزا سول', 'Cuanza Sul', 9, 'Cuanza Sul', '06', NULL, NULL),
(91, 'هوامبو', 'Huambo', 9, 'Huambo', '08', NULL, NULL),
(92, 'موكسيكو', 'Moxico', 9, 'Moxico', '14', NULL, NULL),
(93, 'كواندو كوبانجو', 'Cuando Cubango', 9, 'Cuando Cubango', '04', NULL, NULL),
(94, 'بيي', 'Bie', 9, 'Bie', '02', NULL, NULL),
(95, 'هويلا', 'Huila', 9, 'Huila', '09', NULL, NULL),
(96, 'لوندا سول', 'Lunda Sul', 9, 'Lunda Sul', '18', NULL, NULL),
(98, 'زائير', 'Zaire', 9, 'Zaïre', '16', NULL, NULL),
(99, 'كونين', 'Cunene', 9, 'Cunene', '07', NULL, NULL),
(100, 'لوندا نورتي', 'Lunda Norte', 9, 'Lunda Norte', '17', NULL, NULL),
(101, 'ناميبي', 'Namibe', 9, 'Namibe', '13', NULL, NULL),
(102, 'كابيندا', 'Cabinda', 9, 'Cabinda', '03', NULL, NULL),
(103, 'بوينس آيرس', 'Buenos Aires', 10, 'Buenos Aires', '01', NULL, NULL),
(104, 'قرطبة', 'Cordoba', 10, 'Cordoba', '05', NULL, NULL),
(105, 'انتري ريوس', 'Entre Rios', 10, 'Entre Rios', '08', NULL, NULL),
(106, 'سالتا', 'Salta', 10, 'Salta', '17', NULL, NULL),
(107, 'خوخوي', 'Jujuy', 10, 'Jujuy', '10', NULL, NULL),
(108, 'لا بامبا', 'La Pampa', 10, 'La Pampa', '11', NULL, NULL),
(109, 'مندوزا', 'Mendoza', 10, 'Mendoza', '13', NULL, NULL),
(110, 'ميسيونيس', 'Misiones', 10, 'Misiones', '14', NULL, NULL),
(111, 'سانتا كروز', 'Santa Cruz', 10, 'Santa Cruz', '20', NULL, NULL),
(112, 'سانتا في', 'Santa Fe', 10, 'Santa Fe', '21', NULL, NULL),
(113, 'توكومان', 'Tucuman', 10, 'Tucuman', '24', NULL, NULL),
(114, 'كورينتس', 'Corrientes', 10, 'Corrientes', '06', NULL, NULL),
(115, 'سان خوان', 'San Juan', 10, 'San Juan', '18', NULL, NULL),
(116, 'سانتياغو ديل إستيرو', 'Santiago del Estero', 10, 'Santiago del Estero', '22', NULL, NULL),
(117, 'كاتاماركا', 'Catamarca', 10, 'Catamarca', '02', NULL, NULL),
(118, 'نيوكوين', 'Neuquen', 10, 'Neuquen', '15', NULL, NULL),
(119, 'وفي مقاطعة الاتحادية', 'Distrito Federal', 10, 'Distrito Federal', '07', NULL, NULL),
(120, 'لا ريوخا', 'La Rioja', 10, 'La Rioja', '12', NULL, NULL),
(121, 'ريو نيغرو', 'Rio Negro', 10, 'Rio Negro', '16', NULL, NULL),
(122, 'شوبوت', 'Chubut', 10, 'Chubut', '04', NULL, NULL),
(123, 'سان لويس', 'San Luis', 10, 'San Luis', '19', NULL, NULL),
(124, 'تييرا ديل فويغو', 'Tierra del Fuego', 10, 'Terre de Feu', '23', NULL, NULL),
(125, 'فورموزا', 'Formosa', 10, 'Formose', '09', NULL, NULL),
(126, 'شاكو', 'Chaco', 10, 'Chaco', '03', NULL, NULL),
(127, 'Niederosterreich', 'Niederosterreich', 11, 'Niederosterreich', '03', NULL, NULL),
(128, 'سالزبورغ', 'Salzburg', 11, 'Salzbourg', '05', NULL, NULL),
(129, 'Oberosterreich', 'Oberosterreich', 11, 'Oberosterreich', '04', NULL, NULL),
(130, 'تيرول', 'Tirol', 11, 'Tirol', '07', NULL, NULL),
(131, 'كارنتين', 'Karnten', 11, 'Karnten', '02', NULL, NULL),
(132, 'STEIERMARK', 'Steiermark', 11, 'Steiermark', '06', NULL, NULL),
(133, 'فورارلبرغ', 'Vorarlberg', 11, 'Vorarlberg', '08', NULL, NULL),
(134, 'فيينا', 'Wien', 11, 'Wien', '09', NULL, NULL),
(135, 'بورغنلاند', 'Burgenland', 11, 'Burgenland', '01', NULL, NULL),
(136, 'نيو ساوث ويلز', 'New South Wales', 12, 'Nouvelle Galles du Sud', '02', NULL, NULL),
(137, 'تسمانيا', 'Tasmania', 12, 'Tasmanie', '06', NULL, NULL),
(138, 'القسم الغربي من استراليا', 'Western Australia', 12, 'Australie occidentale', '08', NULL, NULL),
(139, 'كوينزلاند', 'Queensland', 12, 'Queensland', '04', NULL, NULL),
(140, 'فيكتوريا', 'Victoria', 12, 'Victoria', '07', NULL, NULL),
(141, 'جنوب استراليا', 'South Australia', 12, 'Australie du Sud', '05', NULL, NULL),
(142, 'الإقليم الشمالي', 'Northern Territory', 12, 'Territoire du Nord', '03', NULL, NULL),
(143, 'إقليم العاصمة الأسترالية', 'Australian Capital Territory', 12, 'Territoire de la capitale australienne', '01', NULL, NULL),
(146, 'نيفتكالا', 'Neftcala', 14, 'Neftcala', '36', NULL, NULL),
(147, 'زانلار', 'Xanlar', 14, 'Xanlar', '62', NULL, NULL),
(148, 'يفلاكس', 'Yevlax', 14, 'Yevlax', '68', NULL, NULL),
(149, 'أجداس', 'Agdas', 14, 'Agdas', '04', NULL, NULL),
(150, 'سابيراباد', 'Sabirabad', 14, 'Sabirabad', '46', NULL, NULL),
(151, 'يارديملي', 'Yardimli', 14, 'Yardimli', '66', NULL, NULL),
(152, 'Calilabad', 'Calilabad', 14, 'Calilabad', '15', NULL, NULL),
(153, 'ساتلي', 'Saatli', 14, 'Saatli', '45', NULL, NULL),
(154, 'الساقي', 'Saki', 14, 'Saki', '47', NULL, NULL),
(155, 'كوردامير', 'Kurdamir', 14, 'Kurdamir', '27', NULL, NULL),
(156, 'كازاكس', 'Qazax', 14, 'Qazax', '40', NULL, NULL),
(157, 'توفوز', 'Tovuz', 14, 'Tovuz', '58', NULL, NULL),
(158, 'سامكير', 'Samkir', 14, 'Samkir', '51', NULL, NULL),
(159, 'أغدام', 'Agdam', 14, 'Agdam', '03', NULL, NULL),
(160, 'كوبادلي', 'Qubadli', 14, 'Qubadli', '43', NULL, NULL),
(161, 'أوغوز', 'Oguz', 14, 'Oguz', '37', NULL, NULL),
(162, 'لاكين', 'Lacin', 14, 'Lacin', '28', NULL, NULL),
(163, 'كالباكار', 'Kalbacar', 14, 'Kalbacar', '26', NULL, NULL),
(164, 'Haciqabul', 'Haciqabul', 14, 'Haciqabul', '23', NULL, NULL),
(165, 'بيلاسوفار', 'Bilasuvar', 14, 'Bilasuvar', '13', NULL, NULL),
(166, 'بالاكان', 'Balakan', 14, 'Balakan', '10', NULL, NULL),
(167, 'ناخيتشيفان', 'Naxcivan', 14, 'Naxcivan', '35', NULL, NULL),
(168, 'قابالا', 'Qabala', 14, 'Qabala', '38', NULL, NULL),
(169, 'أجكابادي', 'Agcabadi', 14, 'Agcabadi', '02', NULL, NULL),
(170, 'ساماكسي', 'Samaxi', 14, 'Samaxi', '50', NULL, NULL),
(171, 'دافاسي', 'Davaci', 14, 'Davaci', '17', NULL, NULL),
(172, 'قباء', 'Quba', 14, 'Quba', '42', NULL, NULL),
(173, 'كوسار', 'Qusar', 14, 'Qusar', '44', NULL, NULL),
(174, 'إيميسلي', 'Imisli', 14, 'Imisli', '24', NULL, NULL),
(175, 'أبسيرون', 'Abseron', 14, 'Abseron', '01', NULL, NULL),
(176, 'زاكماز', 'Xacmaz', 14, 'Xacmaz', '60', NULL, NULL),
(177, 'كابرايل', 'Cabrayil', 14, 'Cabrayil', '14', NULL, NULL),
(178, 'إيسمييلي', 'Ismayilli', 14, 'Ismayilli', '25', NULL, NULL),
(179, 'غورانبوي', 'Goranboy', 14, 'Goranboy', '21', NULL, NULL),
(180, 'فضولي', 'Fuzuli', 14, 'Fuzuli', '18', NULL, NULL),
(181, 'باكي', 'Baki', 14, 'Baki', '09', NULL, NULL),
(182, 'بيلاكان', 'Beylaqan', 14, 'Beylaqan', '12', NULL, NULL),
(183, 'داسكاسان', 'Daskasan', 14, 'Daskasan', '16', NULL, NULL),
(184, 'ماسالي', 'Masalli', 14, 'Masalli', '32', NULL, NULL),
(185, 'زاكاتالا', 'Zaqatala', 14, 'Zaqatala', '70', NULL, NULL),
(186, 'نكران', 'Lankaran', 14, 'Lankaran', '29', NULL, NULL),
(187, 'ليريك', 'Lerik', 14, 'Lerik', '31', NULL, NULL),
(188, 'علي بيرملي', 'Ali Bayramli', 14, 'Ali Bayramli', '07', NULL, NULL),
(189, 'QAX', 'Qax', 14, 'Qax', '39', NULL, NULL),
(190, 'ساموكس', 'Samux', 14, 'Samux', '52', NULL, NULL),
(191, 'زارداب', 'Zardab', 14, 'Zardab', '71', NULL, NULL),
(192, 'جاداباي', 'Gadabay', 14, 'Gadabay', '19', NULL, NULL),
(193, 'أوكار', 'Ucar', 14, 'Ucar', '59', NULL, NULL),
(194, 'بردا', 'Barda', 14, 'Barda', '11', NULL, NULL),
(195, 'سيازان', 'Siyazan', 14, 'Siyazan', '53', NULL, NULL),
(196, 'كسوكافاند', 'Xocavand', 14, 'Xocavand', '65', NULL, NULL),
(197, 'زانجيلان', 'Zangilan', 14, 'Zangilan', '69', NULL, NULL),
(198, 'XIZI', 'Xizi', 14, 'Xizi', '63', NULL, NULL),
(199, 'يفلاكس', 'Yevlax', 14, 'Yevlax', '67', NULL, NULL),
(200, 'AGSU', 'Agsu', 14, 'Agsu', '06', NULL, NULL),
(201, 'كوبستان', 'Qobustan', 14, 'Qobustan', '41', NULL, NULL),
(202, 'جويكاي', 'Goycay', 14, 'Goycay', '22', NULL, NULL),
(203, 'أستارا', 'Astara', 14, 'Astara', '08', NULL, NULL),
(204, 'كسوكالي', 'Xocali', 14, 'Xocali', '64', NULL, NULL),
(205, 'زانكاندي', 'Xankandi', 14, 'Xankandi', '61', NULL, NULL),
(206, 'رواسب', 'Tartar', 14, 'Tartre', '57', NULL, NULL),
(207, 'أجستافا', 'Agstafa', 14, 'Agstafa', '05', NULL, NULL),
(208, 'ساليان', 'Salyan', 14, 'Salyan', '49', NULL, NULL),
(209, 'سوسة', 'Susa', 14, 'Susa', '55', NULL, NULL),
(210, 'غانكا', 'Ganca', 14, 'Ganca', '20', NULL, NULL),
(211, 'سامكيت', 'Sumqayit', 14, 'Sumqayit', '54', NULL, NULL),
(212, 'الساقي', 'Saki', 14, 'Saki', '48', NULL, NULL),
(213, 'نفتالان', 'Naftalan', 14, 'Naftalan', '34', NULL, NULL),
(214, 'نكران', 'Lankaran', 14, 'Lankaran', '30', NULL, NULL),
(215, 'مينغاشفير', 'Mingacevir', 14, 'Mingacevir', '33', NULL, NULL),
(216, 'سوسة', 'Susa', 14, 'Susa', '56', NULL, NULL),
(217, 'جمهورية صربسكا', 'Republika Srpska', 15, 'Republika Srpska', '02', NULL, NULL),
(218, 'اتحاد البوسنة والهرسك', 'Federation of Bosnia and Herzegovina', 15, 'Fédération de Bosnie et Herzégovine', '01', NULL, NULL),
(220, 'القديس يوسف', 'Saint Joseph', 16, 'Saint Joseph', '06', NULL, NULL),
(221, 'سانت لوسي', 'Saint Lucy', 16, 'Sainte Lucie', '07', NULL, NULL),
(222, 'سانت توماس', 'Saint Thomas', 16, 'Saint thomas', '11', NULL, NULL),
(223, 'جيمس قديس', 'Saint James', 16, 'Saint James', '04', NULL, NULL),
(224, 'القديس يوحنا', 'Saint John', 16, 'Saint Jean', '05', NULL, NULL),
(225, 'القديس بطرس', 'Saint Peter', 16, 'Saint Pierre', '09', NULL, NULL),
(226, 'كنيسة المسيح', 'Christ Church', 16, 'Christ Church', '01', NULL, NULL),
(227, 'القديس جورج', 'Saint George', 16, 'Saint George', '03', NULL, NULL),
(228, 'القديس مايكل', 'Saint Michael', 16, 'Saint michel', '08', NULL, NULL),
(229, 'القديس أندرو', 'Saint Andrew', 16, 'Saint andrew', '02', NULL, NULL),
(230, 'سانت فيليب', 'Saint Philip', 16, 'Saint philippe', '10', NULL, NULL),
(231, 'خولنا', 'Khulna', 17, 'Khulna', '82', NULL, NULL),
(232, 'راجشاهي', 'Rajshahi', 17, 'Rajshahi', '83', NULL, NULL),
(233, 'دكا', 'Dhaka', 17, 'Dhaka', '81', NULL, NULL),
(235, 'باريسال', 'Barisal', 17, 'Barisal', '85', NULL, NULL),
(236, 'سيلهيت', 'Sylhet', 17, 'Sylhet', '86', NULL, NULL),
(237, 'شيتاغونغ', 'Chittagong', 17, 'Chittagong', '84', NULL, NULL),
(238, 'فلاندر الشرقية', 'Oost-Vlaanderen', 18, 'Oost-Vlaanderen', '08', NULL, NULL),
(239, 'فلاندر الغربية', 'West-Vlaanderen', 18, 'West-Vlaanderen', '09', NULL, NULL),
(241, 'ليمبورغ', 'Limburg', 18, 'Limbourg', '05', NULL, NULL),
(242, 'أنتويرب', 'Antwerpen', 18, 'Antwerpen', '01', NULL, NULL),
(243, 'لوكسمبورغ', 'Luxembourg', 18, 'Luxembourg', '06', NULL, NULL),
(244, 'ليمبورغ', 'Hainaut', 18, 'Hainaut', '03', NULL, NULL),
(245, 'مرتبط ب', 'Liege', 18, 'Lige', '04', NULL, NULL),
(246, 'نامور', 'Namur', 18, 'Namur', '07', NULL, NULL),
(247, 'بروكسل Hoofdstedelijk Gewest', 'Brussels Hoofdstedelijk Gewest', 18, 'Bruxelles Hoofdstedelijk Gewest', '11', NULL, NULL),
(248, 'فلامس برابانت', 'Vlaams-Brabant', 18, 'Brabant flamand', '12', NULL, NULL),
(249, 'برابانت الوالون', 'Brabant Wallon', 18, 'Brabant Wallon', '10', NULL, NULL),
(251, 'موهون', 'Mouhoun', 19, 'Mouhoun', '63', NULL, NULL),
(252, 'بام', 'Bam', 19, 'Bam', '15', NULL, NULL),
(257, 'تابوا', 'Tapoa', 19, 'Tapoa', '42', NULL, NULL),
(258, 'سوم', 'Soum', 19, 'Soum', '40', NULL, NULL),
(259, 'يرابا', 'Leraba', 19, 'Leraba', '61', NULL, NULL),
(260, 'نومبيل', 'Noumbiel', 19, 'Noumbiel', '67', NULL, NULL),
(262, 'جناجنا', 'Gnagna', 19, 'Gnagna', '21', NULL, NULL),
(265, 'ياتينجا', 'Yatenga', 19, 'Yatenga', '76', NULL, NULL),
(266, 'بانوا', 'Banwa', 19, 'Banwa', '46', NULL, NULL),
(267, 'بوني', 'Poni', 19, 'Poni', '69', NULL, NULL),
(268, 'وروم', 'Loroum', 19, 'Loroum', '62', NULL, NULL),
(269, 'كوريتنجا', 'Kouritenga', 19, 'Kouritenga', '28', NULL, NULL),
(270, 'توي', 'Tuy', 19, 'Tuy', '74', NULL, NULL),
(271, 'كوسي', 'Kossi', 19, 'Kossi', '58', NULL, NULL),
(272, 'باسور', 'Passore', 19, 'Passore', '34', NULL, NULL),
(273, 'كيندوجو', 'Kenedougou', 19, 'Kénédougou', '54', NULL, NULL),
(274, 'بالة', 'Bale', 19, 'Balle', '45', NULL, NULL),
(275, 'بوغوريبا', 'Bougouriba', 19, 'Bougouriba', '48', NULL, NULL),
(276, 'هويت', 'Houet', 19, 'Houet', '51', NULL, NULL),
(277, 'جورما', 'Gourma', 19, 'Gourma', '50', NULL, NULL),
(278, 'نامنتنجا', 'Namentenga', 19, 'Namentenga', '64', NULL, NULL),
(279, 'سانماتينغا', 'Sanmatenga', 19, 'Sanmatenga', '70', NULL, NULL),
(281, 'إيوبا', 'Ioba', 19, 'Ioba', '52', NULL, NULL),
(282, 'غانزورغو', 'Ganzourgou', 19, 'Ganzourgou', '20', NULL, NULL),
(283, 'الناعوري', 'Naouri', 19, 'Naouri', '65', NULL, NULL),
(284, 'بولكيمد', 'Boulkiemde', 19, 'Boulkiemde', '19', NULL, NULL),
(285, 'زوندويجو', 'Zoundweogo', 19, 'Zoundweogo', '44', NULL, NULL),
(286, 'زوندوما', 'Zondoma', 19, 'Zondoma', '78', NULL, NULL),
(289, 'Komoe', 'Komoe', 19, 'Komoe', '55', NULL, NULL),
(290, 'ياغا', 'Yagha', 19, 'Yagha', '75', NULL, NULL),
(291, 'كوموندجاري', 'Komondjari', 19, 'Komondjari', '56', NULL, NULL),
(292, 'سورو', 'Sourou', 19, 'Sourou', '73', NULL, NULL),
(293, 'نايالا', 'Nayala', 19, 'Nayala', '66', NULL, NULL),
(294, 'سيسيلي', 'Sissili', 19, 'Sissili', '72', NULL, NULL),
(295, 'سانجوي', 'Sanguie', 19, 'Sanguie', '36', NULL, NULL),
(296, 'أودالان', 'Oudalan', 19, 'Oudalan', '33', NULL, NULL),
(297, 'كولبيلوجو', 'Koulpelogo', 19, 'Koulpelogo', '59', NULL, NULL),
(298, 'زيرو', 'Ziro', 19, 'Ziro', '77', NULL, NULL),
(299, 'كورويجو', 'Kourweogo', 19, 'Kourweogo', '60', NULL, NULL),
(300, 'أوبريتنغا', 'Oubritenga', 19, 'Oubritenga', '68', NULL, NULL),
(301, 'سينو', 'Seno', 19, 'Seno', '71', NULL, NULL),
(302, 'بازيجا', 'Bazega', 19, 'Bazega', '47', NULL, NULL),
(303, 'كاديوغو', 'Kadiogo', 19, 'Kadiogo', '53', NULL, NULL),
(304, 'كومبينغا', 'Kompienga', 19, 'Kompienga', '57', NULL, NULL),
(305, 'بولغو', 'Boulgou', 19, 'Boulgou', '49', NULL, NULL),
(306, 'لوفيتش', 'Lovech', 20, 'Lovech', '46', NULL, NULL),
(307, 'فارنا', 'Varna', 20, 'Varna', '61', NULL, NULL),
(308, 'بورغاس', 'Burgas', 20, 'Burgas', '39', NULL, NULL),
(309, 'رازغراد', 'Razgrad', 20, 'Razgrad', '52', NULL, NULL),
(310, 'بلوفديف', 'Plovdiv', 20, 'Plovdiv', '51', NULL, NULL),
(311, 'Khaskovo', 'Khaskovo', 20, 'Khaskovo', '43', NULL, NULL),
(312, 'SOFIYA', 'Sofiya', 20, 'Sofiya', '58', NULL, NULL),
(313, 'سيليسترا', 'Silistra', 20, 'Silistra', '55', NULL, NULL),
(314, 'فيدين', 'Vidin', 20, 'Vidin', '63', NULL, NULL),
(315, 'مونتانا', 'Montana', 20, 'Montana', '47', NULL, NULL),
(316, 'Mikhaylovgrad', 'Mikhaylovgrad', 20, 'Mikhaylovgrad', '33', NULL, NULL),
(317, 'جراد صوفيا', 'Grad Sofiya', 20, 'Grad Sofiya', '42', NULL, NULL),
(318, 'تارغوفيشته', 'Turgovishte', 20, 'Turgovishte', '60', NULL, NULL),
(319, 'Kurdzhali', 'Kurdzhali', 20, 'Kurdzhali', '44', NULL, NULL),
(320, 'دوبريتش', 'Dobrich', 20, 'Dobrich', '40', NULL, NULL),
(321, 'شومين', 'Shumen', 20, 'Shumen', '54', NULL, NULL),
(322, 'بلاغويفغارد', 'Blagoevgrad', 20, 'Blagoevgrad', '38', NULL, NULL),
(323, 'سموليان', 'Smolyan', 20, 'Smolyan', '57', NULL, NULL),
(324, 'ستارا زاغورا', 'Stara Zagora', 20, 'Stara Zagora', '59', NULL, NULL),
(325, 'بازارجيك', 'Pazardzhik', 20, 'Pazardzhik', '48', NULL, NULL),
(326, 'حيلة', 'Ruse', 20, 'Ruse', '53', NULL, NULL),
(327, 'فراتسا', 'Vratsa', 20, 'Vratsa', '64', NULL, NULL),
(328, 'بليفين', 'Pleven', 20, 'Pleven', '50', NULL, NULL),
(329, 'برنيك', 'Pernik', 20, 'Pernik', '49', NULL, NULL),
(330, 'كيوستينديل', 'Kyustendil', 20, 'Kyustendil', '45', NULL, NULL),
(331, 'يامبول', 'Yambol', 20, 'Yambol', '65', NULL, NULL),
(332, 'غابروفو', 'Gabrovo', 20, 'Gabrovo', '41', NULL, NULL),
(333, 'سليفن', 'Sliven', 20, 'Sliven', '56', NULL, NULL),
(334, 'فيليكو ترنوفو', 'Veliko Turnovo', 20, 'Veliko Turnovo', '62', NULL, NULL),
(335, 'جد حفص', 'Jidd Hafs', 21, 'Jidd Hafs', '05', NULL, NULL),
(337, 'المنطقة الشمالية', 'Al Mintaqah ash Shamaliyah', 21, 'Al Mintaqah cendres Shamaliyah', '10', NULL, NULL),
(339, 'المنامة', 'Al Manamah', 21, 'Al Manamah', '02', NULL, NULL),
(340, 'سترة', 'Sitrah', 21, 'Sitrah', '06', NULL, NULL),
(341, 'المنطقة الغربية', 'Al Mintaqah al Gharbiyah', 21, 'Al Mintaqah al Gharbiyah', '08', NULL, NULL),
(342, 'ولاية جزرور حوار', 'Mintaqat Juzur Hawar', 21, 'Mintaqat Juzur Hawar', '09', NULL, NULL),
(343, 'الحد', 'Al Hadd', 21, 'Al Hadd', '01', NULL, NULL),
(344, 'المنطقة الوسطى', 'Al Mintaqah al Wusta', 21, 'Al Mintaqah al Wusta', '11', NULL, NULL),
(345, 'الرفاع', 'Ar Rifa', 21, 'Ar Rifa', '13', NULL, NULL),
(346, 'مدينة', 'Madinat', 21, 'Madinat', '12', NULL, NULL),
(347, 'كاروزي', 'Karuzi', 22, 'Karuzi', '14', NULL, NULL),
(348, 'رويجي', 'Ruyigi', 22, 'Ruyigi', '21', NULL, NULL),
(349, 'بوبانزا', 'Bubanza', 22, 'Bubanza', '09', NULL, NULL),
(350, 'بوروري', 'Bururi', 22, 'Bururi', '10', NULL, NULL),
(351, 'ماكامبا', 'Makamba', 22, 'Makamba', '17', NULL, NULL),
(352, 'كاينزا', 'Kayanza', 22, 'Kayanza', '15', NULL, NULL),
(354, 'روتانا', 'Rutana', 22, 'Rutana', '20', NULL, NULL),
(355, 'مويينغا', 'Muyinga', 22, 'Muyinga', '18', NULL, NULL),
(356, 'سيبيتوكييه', 'Cibitoke', 22, 'Cibitoke', '12', NULL, NULL),
(357, 'غيتيغا', 'Gitega', 22, 'Gitega', '13', NULL, NULL),
(358, 'كانكوزا', 'Cankuzo', 22, 'Cankuzo', '11', NULL, NULL),
(359, 'بوجمبورا', 'Bujumbura', 22, 'Bujumbura', '02', NULL, NULL),
(360, 'نغوزي', 'Ngozi', 22, 'Ngozi', '19', NULL, NULL),
(361, 'كيروندو', 'Kirundo', 22, 'Kirundo', '16', NULL, NULL),
(362, 'هضبة', 'Plateau', 23, 'Plateau', '17', NULL, NULL),
(363, 'التلال', 'Collines', 23, 'Des collines', '11', NULL, NULL),
(366, 'أويمي', 'Oueme', 23, 'Oueme', '16', NULL, NULL),
(367, 'زو', 'Zou', 23, 'Zou', '18', NULL, NULL),
(370, 'Atlanyique', 'Atlanyique', 23, 'Atlanyique', '09', NULL, NULL),
(371, 'بورغو', 'Borgou', 23, 'Borgou', '10', NULL, NULL),
(372, 'مونو', 'Mono', 23, 'Mono', '15', NULL, NULL),
(374, 'كوفو', 'Kouffo', 23, 'Kouffo', '12', NULL, NULL),
(375, 'دونجا', 'Donga', 23, 'Donga', '13', NULL, NULL),
(376, 'ساحلي', 'Littoral', 23, 'Littoral', '14', NULL, NULL),
(377, 'أليبوري', 'Alibori', 23, 'Alibori', '07', NULL, NULL),
(378, 'أتاكورا', 'Atakora', 23, 'Atakora', '08', NULL, NULL),
(379, 'ديفونشاير', 'Devonshire', 24, 'Devonshire', '01', NULL, NULL),
(380, 'باجيت', 'Paget', 24, 'Paget', '04', NULL, NULL),
(381, 'سانت جورج', 'Saint George\'s', 24, 'Saint George\'s', '07', NULL, NULL),
(382, 'الحدادون', 'Smiths', 24, 'Smiths', '09', NULL, NULL),
(383, 'هاميلتون', 'Hamilton', 24, 'Hamilton', '03', NULL, NULL),
(384, 'وارويك', 'Warwick', 24, 'Warwick', '11', NULL, NULL),
(385, 'سانديز', 'Sandys', 24, 'Sandys', '08', NULL, NULL),
(386, 'القديس جورج', 'Saint George', 24, 'Saint George', '06', NULL, NULL),
(387, 'هاميلتون', 'Hamilton', 24, 'Hamilton', '02', NULL, NULL),
(389, 'سانتا كروز', 'Santa Cruz', 26, 'Santa Cruz', '08', NULL, NULL),
(390, 'باندو', 'Pando', 26, 'Pando', '06', NULL, NULL),
(391, 'تاريخا', 'Tarija', 26, 'Tarija', '09', NULL, NULL),
(392, 'لاباز', 'La Paz', 26, 'La paz', '04', NULL, NULL),
(393, 'أورورو', 'Oruro', 26, 'Oruro', '05', NULL, NULL),
(394, 'كوتشابامبا', 'Cochabamba', 26, 'Cochabamba', '02', NULL, NULL),
(395, 'بوتوسي', 'Potosi', 26, 'Potosi', '07', NULL, NULL),
(396, 'شوكيساكا', 'Chuquisaca', 26, 'Chuquisaca', '01', NULL, NULL),
(397, 'البنى', 'El Beni', 26, 'El Beni', '03', NULL, NULL),
(398, 'سانتا كاتارينا', 'Santa Catarina', 27, 'Santa Catarina', '26', NULL, NULL),
(399, 'ماتو جروسو دو سول', 'Mato Grosso do Sul', 27, 'Mato Grosso do Sul', '11', NULL, NULL),
(400, 'ريو غراندي دو سول', 'Rio Grande do Sul', 27, 'Rio Grande do Sul', '23', NULL, NULL),
(401, 'اسبيريتو سانتو', 'Espirito Santo', 27, 'Espirito Santo', '08', NULL, NULL),
(402, 'باهيا', 'Bahia', 27, 'Bahia', '05', NULL, NULL),
(403, 'روندونيا', 'Rondonia', 27, 'Rondonia', '24', NULL, NULL),
(404, 'ميناس جيرايس', 'Minas Gerais', 27, 'minas Gerais', '15', NULL, NULL),
(405, 'بارايبا', 'Paraiba', 27, 'Paraiba', '17', NULL, NULL),
(406, 'أمابا', 'Amapa', 27, 'Amapa', '03', NULL, NULL),
(407, 'أمازوناس', 'Amazonas', 27, 'Amazonas', '04', NULL, NULL),
(408, 'الفقرة', 'Para', 27, 'Para', '16', NULL, NULL),
(409, 'سيارا', 'Ceara', 27, 'Ceara', '06', NULL, NULL),
(410, 'ريو دي جانيرو', 'Rio de Janeiro', 27, 'Rio de Janeiro', '21', NULL, NULL),
(411, 'غوياس', 'Goias', 27, 'Goias', '29', NULL, NULL),
(412, 'ساو باولو', 'Sao Paulo', 27, 'Sao Paulo', '27', NULL, NULL),
(413, 'بارانا', 'Parana', 27, 'Parana', '18', NULL, NULL),
(414, 'ريو غراندي دو نورتي', 'Rio Grande do Norte', 27, 'Rio Grande do Norte', '22', NULL, NULL),
(415, 'فدان', 'Acre', 27, 'Acre', '01', NULL, NULL),
(416, 'بياوي', 'Piaui', 27, 'Piaui', '20', NULL, NULL),
(417, 'بيرنامبوكو', 'Pernambuco', 27, 'Pernambouc', '30', NULL, NULL),
(418, 'ماتو جروسو', 'Mato Grosso', 27, 'Mato Grosso', '14', NULL, NULL),
(419, 'مارانهاو', 'Maranhao', 27, 'Maranhao', '13', NULL, NULL),
(420, 'توكانتينز', 'Tocantins', 27, 'Tocantins', '31', NULL, NULL),
(421, 'رورايما', 'Roraima', 27, 'Roraima', '25', NULL, NULL),
(422, 'ألاغواس', 'Alagoas', 27, 'Alagoas', '02', NULL, NULL),
(423, 'سيرغيبي', 'Sergipe', 27, 'Sergipe', '28', NULL, NULL),
(424, 'وفي مقاطعة الاتحادية', 'Distrito Federal', 27, 'Distrito Federal', '07', NULL, NULL),
(425, 'Acklins and Crooked Islands', 'Acklins and Crooked Islands', 28, 'Acklins et les îles Crooked', '24', NULL, NULL),
(426, 'ماياجيوانا', 'Mayaguana', 28, 'Mayaguana', '16', NULL, NULL),
(427, 'جزيرة طويلة', 'Long Island', 28, 'Long Island', '15', NULL, NULL),
(428, 'بروفيدانس الجديدة', 'New Providence', 28, 'New Providence', '23', NULL, NULL),
(429, 'اكسوما', 'Exuma', 28, 'Exuma', '10', NULL, NULL),
(430, 'بيميني', 'Bimini', 28, 'Bimini', '05', NULL, NULL),
(431, 'ميناء الحاكم', 'Governor\'s Harbour', 28, 'Port du gouverneur', '27', NULL, NULL),
(432, 'سان سلفادور وروم كاي', 'San Salvador and Rum Cay', 28, 'San Salvador et Rum Cay', '35', NULL, NULL),
(433, 'فريش كريك', 'Fresh Creek', 28, 'Fresh Creek', '26', NULL, NULL),
(434, 'جزيرة القط', 'Cat Island', 28, 'Île de chat', '06', NULL, NULL),
(435, 'Nichollstown و جزر بيري', 'Nichollstown and Berry Islands', 28, 'Nichollstown et les îles Berry', '32', NULL, NULL),
(436, 'كيمبس باي', 'Kemps Bay', 28, 'Kemps Bay', '30', NULL, NULL),
(437, 'ميناء حر', 'Freeport', 28, 'Freeport', '25', NULL, NULL),
(438, 'صوت صخري', 'Rock Sound', 28, 'Son rock', '33', NULL, NULL),
(439, 'جزيرة الميناء', 'Harbour Island', 28, 'Harbour Island', '22', NULL, NULL),
(440, 'هاي روك', 'High Rock', 28, 'Haute roche', '29', NULL, NULL),
(441, 'جرين تيرتل كاي', 'Green Turtle Cay', 28, 'Green Turtle Cay', '28', NULL, NULL),
(442, 'مارش هاربر', 'Marsh Harbour', 28, 'Marsh Harbour', '31', NULL, NULL),
(443, 'جزيرة راكد', 'Ragged Island', 28, 'Ile déchiquetée', '18', NULL, NULL),
(444, 'ساندي بوينت', 'Sandy Point', 28, 'Sandy Point', '34', NULL, NULL),
(445, 'من Inagua', 'Inagua', 28, 'Inagua', '13', NULL, NULL),
(446, 'وانجدي Phodrang', 'Wangdi Phodrang', 29, 'Wangdi Phodrang', '22', NULL, NULL),
(447, 'بارو', 'Paro', 29, 'Paro', '13', NULL, NULL),
(448, 'داغا', 'Daga', 29, 'Daga', '08', NULL, NULL),
(449, 'مونغار', 'Mongar', 29, 'Mongar', '12', NULL, NULL),
(450, 'Shemgang', 'Shemgang', 29, 'Shemgang', '18', NULL, NULL),
(451, 'تيمفو', 'Thimphu', 29, 'Thimphu', '20', NULL, NULL),
(452, 'Tashigang', 'Tashigang', 29, 'Tashigang', '19', NULL, NULL),
(453, 'شيرانغ', 'Chirang', 29, 'Chirang', '07', NULL, NULL),
(454, 'Geylegphug', 'Geylegphug', 29, 'Geylegphug', '09', NULL, NULL),
(455, 'سامدروب', 'Samdrup', 29, 'Samdrup', '17', NULL, NULL),
(456, 'بوم ثانج', 'Bumthang', 29, 'Bumthang', '05', NULL, NULL),
(457, 'Samchi', 'Samchi', 29, 'Samchi', '16', NULL, NULL),
(458, 'Tongsa', 'Tongsa', 29, 'Tongsa', '21', NULL, NULL),
(459, 'جوخا', 'Chhukha', 29, 'Chhukha', '06', NULL, NULL),
(460, 'Pemagatsel', 'Pemagatsel', 29, 'Pemagatsel', '14', NULL, NULL),
(461, 'ها', 'Ha', 29, 'Ha', '10', NULL, NULL),
(462, 'بونخا', 'Punakha', 29, 'Punakha', '15', NULL, NULL),
(463, 'Lhuntshi', 'Lhuntshi', 29, 'Lhuntshi', '11', NULL, NULL),
(464, 'وسط', 'Central', 30, 'Central', '01', NULL, NULL),
(465, 'الجنوب الشرقي', 'South-East', 30, 'Sud-est', '09', NULL, NULL),
(466, 'شمال شرق', 'North-East', 30, 'Nord-est', '08', NULL, NULL),
(467, 'الشمال الغربي', 'North-West', 30, 'Nord Ouest', '11', NULL, NULL),
(468, 'غانزي', 'Ghanzi', 30, 'Ghanzi', '03', NULL, NULL),
(469, 'كوينينج', 'Kweneng', 30, 'Kweneng', '06', NULL, NULL),
(470, 'كغالاغادي', 'Kgalagadi', 30, 'Kgalagadi', '04', NULL, NULL),
(472, 'جنوبي', 'Southern', 30, 'Du sud', '10', NULL, NULL),
(473, 'كجاتلينج', 'Kgatleng', 30, 'Kgatleng', '05', NULL, NULL),
(474, 'Homyel\'skaya Voblasts \"', 'Homyel\'skaya Voblasts\'', 31, 'Homyel\'skaya Voblasts \'', '02', NULL, NULL),
(475, 'مينسك', 'Minsk', 31, 'Minsk', '04', NULL, NULL),
(476, 'Brestskaya Voblasts \"', 'Brestskaya Voblasts\'', 31, 'Brestskaya Voblasts \'', '01', NULL, NULL),
(477, 'هيرودزينسكايا فوبلاست', 'Hrodzyenskaya Voblasts\'', 31, 'Hrodzyenskaya Voblasts \'', '03', NULL, NULL),
(478, 'Mahilyowskaya Voblasts \"', 'Mahilyowskaya Voblasts\'', 31, 'Mahilyowskaya Voblasts \'', '06', NULL, NULL),
(479, 'Vitsyebskaya Voblasts \"', 'Vitsyebskaya Voblasts\'', 31, 'Vitsyebskaya Voblasts \'', '07', NULL, NULL),
(480, 'توليدو', 'Toledo', 32, 'Toledo', '06', NULL, NULL),
(481, 'كايو', 'Cayo', 32, 'Cayo', '02', NULL, NULL),
(482, 'ستان كريك', 'Stann Creek', 32, 'Stann Creek', '05', NULL, NULL),
(483, 'كوروزال', 'Corozal', 32, 'Corozal', '03', NULL, NULL),
(484, 'أورانج ووك', 'Orange Walk', 32, 'Orange Walk', '04', NULL, NULL),
(485, 'بليز', 'Belize', 32, 'Belize', '01', NULL, NULL),
(500, 'خط الاستواء', 'Equateur', 35, 'Équateur', '02', NULL, NULL),
(501, 'الشرقية', 'Orientale', 35, 'Orientale', '09', NULL, NULL),
(503, 'شمال كيفو', 'Nord-Kivu', 35, 'Nord-Kivu', '11', NULL, NULL),
(505, 'مانيما', 'Maniema', 35, 'Maniema', '10', NULL, NULL),
(506, 'باندوندو', 'Bandundu', 35, 'Bandundu', '01', NULL, NULL),
(508, 'كاتانغا', 'Katanga', 35, 'Katanga', '05', NULL, NULL),
(509, 'جنوب كيفو', 'Sud-Kivu', 35, 'Sud-Kivu', '12', NULL, NULL),
(510, 'الكونغو السفلى', 'Bas-Congo', 35, 'Bas-Congo', '08', NULL, NULL),
(511, 'كاساي الشرقية', 'Kasai-Oriental', 35, 'Kasai-Oriental', '04', NULL, NULL),
(512, 'كينشاسا', 'Kinshasa', 35, 'Kinshasa', '06', NULL, NULL),
(513, 'نانا مامبيري', 'Nana-Mambere', 36, 'Nana-Mambere', '09', NULL, NULL),
(514, 'أواكا', 'Ouaka', 36, 'Ouaka', '11', NULL, NULL),
(515, 'كوتو العليا', 'Haute-Kotto', 36, 'Haute-Kotto', '03', NULL, NULL),
(516, 'سانغا مباري', 'Sangha-Mbaere', 36, 'Sangha-Mbaere', '16', NULL, NULL),
(517, 'بامينغي-بانغوران', 'Bamingui-Bangoran', 36, 'Bamingui-Bangoran', '01', NULL, NULL),
(518, 'مبومو', 'Mbomou', 36, 'Mbomou', '08', NULL, NULL),
(519, 'باس كوتو', 'Basse-Kotto', 36, 'Basse-Kotto', '02', NULL, NULL),
(520, 'كيمو', 'Kemo', 36, 'Kemo', '06', NULL, NULL),
(521, 'هوت مبومو', 'Haut-Mbomou', 36, 'Haut-Mbomou', '05', NULL, NULL),
(522, 'أوهام بندي', 'Ouham-Pende', 36, 'Ouham-Pende', '13', NULL, NULL),
(523, 'أوهام', 'Ouham', 36, 'Ouham', '12', NULL, NULL),
(524, 'أومبلا مبوكي', 'Ombella-Mpoko', 36, 'Ombella-Mpoko', '17', NULL, NULL),
(525, 'كفيت-كويست', 'Cuvette-Ouest', 36, 'Cuvette-Ouest', '14', NULL, NULL),
(526, 'مامبري كادي', 'Mambere-Kadei', 36, 'Mambere-Kadei', '04', NULL, NULL),
(527, 'وباي', 'Lobaye', 36, 'Lobaye', '07', NULL, NULL),
(529, 'نانا غريبيزي', 'Nana-Grebizi', 36, 'Nana-Grebizi', '15', NULL, NULL),
(530, 'بانغي', 'Bangui', 36, 'Bangui', '18', NULL, NULL),
(532, 'الهضاب', 'Plateaux', 37, 'Plateaux', '08', NULL, NULL),
(533, 'حوض السباحة', 'Pool', 37, 'bassin', '11', NULL, NULL),
(534, 'سانغا', 'Sangha', 37, 'Sangha', '10', NULL, NULL),
(535, 'يكومو', 'Lekoumou', 37, 'Lekoumou', '05', NULL, NULL),
(536, 'يكوالا', 'Likouala', 37, 'Likouala', '06', NULL, NULL),
(537, 'كويلو', 'Kouilou', 37, 'Kouilou', '04', NULL, NULL),
(538, 'نياري', 'Niari', 37, 'Niari', '07', NULL, NULL),
(539, 'بوينزا', 'Bouenza', 37, 'Bouenza', '01', NULL, NULL),
(540, 'برازافيل', 'Brazzaville', 37, 'Brazzaville', '12', NULL, NULL),
(541, 'كفيت-كويست', 'Cuvette-Ouest', 37, 'Cuvette-Ouest', '14', NULL, NULL),
(542, 'كفيت', 'Cuvette', 37, 'Cuvette', '13', NULL, NULL),
(543, 'ثورجو', 'Thurgau', 38, 'Thurgovie', '19', NULL, NULL),
(544, 'أرجاو', 'Aargau', 38, 'Argovie', '01', NULL, NULL),
(545, 'برن', 'Bern', 38, 'Berne', '05', NULL, NULL),
(546, 'زيوريخ', 'Zurich', 38, 'Zurich', '25', NULL, NULL),
(547, 'فريبورغ', 'Fribourg', 38, 'Fribourg', '06', NULL, NULL),
(548, 'Ausser-رودين', 'Ausser-Rhoden', 38, 'Ausser-Rhoden', '02', NULL, NULL),
(549, 'فاليه', 'Valais', 38, 'Valais', '22', NULL, NULL),
(550, 'أوري', 'Uri', 38, 'Uri', '21', NULL, NULL),
(551, 'غراوبوندن', 'Graubunden', 38, 'Les Grisons', '09', NULL, NULL),
(552, 'تيسان', 'Ticino', 38, 'Tessin', '20', NULL, NULL),
(553, 'لوزيرن', 'Luzern', 38, 'Lucerne', '11', NULL, NULL),
(554, 'أوبوالدن', 'Obwalden', 38, 'Obwalden', '14', NULL, NULL),
(555, 'سولوتورن', 'Solothurn', 38, 'Soleure', '18', NULL, NULL),
(556, 'بازل شتات', 'Basel-Stadt', 38, 'Bâle-Ville', '04', NULL, NULL),
(557, 'الداخلية-رودين', 'Inner-Rhoden', 38, 'Rhodes-Intérieures', '10', NULL, NULL),
(558, 'زوغ', 'Zug', 38, 'Zoug', '24', NULL, NULL),
(559, 'فو', 'Vaud', 38, 'Vaud', '23', NULL, NULL),
(560, 'العصر الجوارسي أو الجوري', 'Jura', 38, 'Jura', '26', NULL, NULL),
(561, 'كانتون ريف بازل', 'Basel-Landschaft', 38, 'Bâle-Campagne', '03', NULL, NULL),
(562, 'شفيتس', 'Schwyz', 38, 'Schwyz', '17', NULL, NULL),
(563, 'سانكت غالن', 'Sankt Gallen', 38, 'Saint-Gall', '15', NULL, NULL),
(564, 'شافهاوزن', 'Schaffhausen', 38, 'Schaffhouse', '16', NULL, NULL),
(565, 'جلاروس', 'Glarus', 38, 'Glaris', '08', NULL, NULL),
(566, 'جنيف', 'Geneve', 38, 'Geneve', '07', NULL, NULL),
(567, 'نيوشاتل', 'Neuchatel', 38, 'Neuchâtel', '12', NULL, NULL),
(568, 'نيدوالدن', 'Nidwalden', 38, 'Nidwalden', '13', NULL, NULL),
(579, 'فالي دو بانداما', 'Vallee du Bandama', 39, 'Vallée du Bandama', '90', NULL, NULL),
(581, 'N\'zi كومو', 'N\'zi-Comoe', 39, 'N\'zi-Comoe', '86', NULL, NULL),
(585, 'موين كومو', 'Moyen-Comoe', 39, 'Moyen-Comoe', '85', NULL, NULL),
(587, 'اجونيه', 'Lagunes', 39, 'Lagunes', '82', NULL, NULL),
(588, 'زانزان', 'Zanzan', 39, 'Zanzan', '92', NULL, NULL),
(589, 'سود كومو', 'Sud-Comoe', 39, 'Sud-Comoe', '89', NULL, NULL),
(590, 'البحيرات', 'Lacs', 39, 'Lacs', '81', NULL, NULL),
(598, 'فورماجر', 'Fromager', 39, 'Fromager', '79', NULL, NULL),
(600, 'Agneby', 'Agneby', 39, 'Agneby', '74', NULL, NULL),
(601, 'بس ساساندرا', 'Bas-Sassandra', 39, 'Bas Sassandra', '76', NULL, NULL),
(603, 'مراهو', 'Marahoue', 39, 'Marahoue', '83', NULL, NULL),
(608, 'بافنج', 'Bafing', 39, 'Bafing', '75', NULL, NULL),
(614, 'السافانا', 'Savanes', 39, 'Savanes', '87', NULL, NULL),
(619, 'سود بانداما', 'Sud-Bandama', 39, 'Sud-Bandama', '88', NULL, NULL),
(620, 'أوت ساساندرا', 'Haut-Sassandra', 39, 'Haut-Sassandra', '80', NULL, NULL),
(621, 'موين كافالي', 'Moyen-Cavally', 39, 'Moyen-Cavally', '84', NULL, NULL),
(622, 'ديكس - هويت مونتاجنيس', 'Dix-Huit Montagnes', 39, 'Dix-Huit Montagnes', '78', NULL, NULL),
(623, 'دانغيل', 'Denguele', 39, 'Denguele', '77', NULL, NULL),
(624, 'ورودوجو', 'Worodougou', 39, 'Worodougou', '91', NULL, NULL),
(626, 'بيو بيو', 'Bio-Bio', 41, 'Bio-Bio', '06', NULL, NULL),
(627, 'مولي', 'Maule', 41, 'Maule', '11', NULL, NULL),
(628, 'لوس لاغوس', 'Los Lagos', 41, 'Los Lagos', '09', NULL, NULL),
(629, 'تاراباكا', 'Tarapaca', 41, 'Tarapaca', '13', NULL, NULL),
(630, 'فالبارايسو', 'Valparaiso', 41, 'Valparaiso', '01', NULL, NULL),
(631, 'أتاكاما', 'Atacama', 41, 'Atacama', '05', NULL, NULL),
(632, 'كوكيمبو', 'Coquimbo', 41, 'Coquimbo', '07', NULL, NULL),
(633, 'Libertador General Bernardo O\'Higgins', 'Libertador General Bernardo O\'Higgins', 41, 'Libertador Général Bernardo O\'Higgins', '08', NULL, NULL),
(634, 'أنتوفاغاستا', 'Antofagasta', 41, 'Antofagasta', '03', NULL, NULL),
(635, 'أراوكاريا', 'Araucania', 41, 'Araucanie', '04', NULL, NULL),
(636, 'Aisen del General Carlos Ibanez del Campo', 'Aisen del General Carlos Ibanez del Campo', 41, 'Aisen del General Carlos Ibanez del Campo', '02', NULL, NULL),
(637, 'منطقة متروبوليتانا', 'Region Metropolitana', 41, 'Région métropolitaine', '12', NULL, NULL),
(638, 'Magallanes y de la Antartica Chilena', 'Magallanes y de la Antartica Chilena', 41, 'Magallanes et de l\'Antarctique Chilena', '10', NULL, NULL),
(639, 'EST', 'Est', 42, 'Est', '04', NULL, NULL),
(640, 'أداماوا', 'Adamaoua', 42, 'Adamaoua', '10', NULL, NULL),
(641, 'مركز', 'Centre', 42, 'Centre', '11', NULL, NULL),
(642, 'سود', 'Sud', 42, 'Sud', '14', NULL, NULL),
(643, 'الإقليم الشمالي الغربي', 'Nord-Ouest', 42, 'Nord-Ouest', '07', NULL, NULL),
(644, 'المتطرف نور', 'Extreme-Nord', 42, 'Extreme-Nord', '12', NULL, NULL),
(645, 'الإقليم الجنوبي الغربي', 'Sud-Ouest', 42, 'Sud-Ouest', '09', NULL, NULL),
(646, 'ساحلي', 'Littoral', 42, 'Littoral', '05', NULL, NULL),
(647, 'نورد', 'Nord', 42, 'Nord', '13', NULL, NULL),
(648, 'كويست', 'Ouest', 42, 'Ouest', '08', NULL, NULL),
(649, 'سيتشوان', 'Sichuan', 43, 'Sichuan', '32', NULL, NULL),
(650, 'شينجيانغ', 'Xinjiang', 43, 'Xinjiang', '13', NULL, NULL),
(651, 'ني المغول', 'Nei Mongol', 43, 'Nei Mongol', '20', NULL, NULL),
(652, 'يونان', 'Yunnan', 43, 'Yunnan', '29', NULL, NULL),
(653, 'قويتشو', 'Guizhou', 43, 'Guizhou', '18', NULL, NULL),
(654, 'هيلونغجيانغ', 'Heilongjiang', 43, 'Heilongjiang', '08', NULL, NULL),
(655, 'شاندونغ', 'Shandong', 43, 'Shandong', '25', NULL, NULL),
(656, 'لياونينغ', 'Liaoning', 43, 'Liaoning', '19', NULL, NULL),
(657, 'شنشى', 'Shaanxi', 43, 'Shaanxi', '26', NULL, NULL),
(658, 'تشينغهاي', 'Qinghai', 43, 'Qinghai', '06', NULL, NULL),
(659, 'قانسو', 'Gansu', 43, 'Gansu', '15', NULL, NULL),
(660, 'جيانغسو', 'Jiangsu', 43, 'Jiangsu', '04', NULL, NULL),
(661, 'فوجيان', 'Fujian', 43, 'Fujian', '07', NULL, NULL),
(662, 'هونان', 'Hunan', 43, 'Hunan', '11', NULL, NULL),
(663, 'جيانغشى', 'Jiangxi', 43, 'Jiangxi', '03', NULL, NULL),
(664, 'قوانغشى', 'Guangxi', 43, 'Guangxi', '16', NULL, NULL),
(665, 'تشجيانغ', 'Zhejiang', 43, 'Zhejiang', '02', NULL, NULL),
(666, 'خبى', 'Hebei', 43, 'Hebei', '10', NULL, NULL),
(667, 'هوبى', 'Hubei', 43, 'Hubei', '12', NULL, NULL),
(668, 'انهوى', 'Anhui', 43, 'Anhui', '01', NULL, NULL),
(669, 'تيانجين', 'Tianjin', 43, 'Tianjin', '28', NULL, NULL),
(670, 'هاينان', 'Hainan', 43, 'Hainan', '31', NULL, NULL),
(671, 'قوانغدونغ', 'Guangdong', 43, 'Guangdong', '30', NULL, NULL),
(672, 'زيزانغ', 'Xizang', 43, 'Xizang', '14', NULL, NULL),
(673, 'جيلين', 'Jilin', 43, 'Jilin', '05', NULL, NULL),
(674, 'تشونغتشينغ', 'Chongqing', 43, 'Chongqing', '33', NULL, NULL),
(675, 'بكين', 'Beijing', 43, 'Pékin', '22', NULL, NULL),
(676, 'شانشى', 'Shanxi', 43, 'Shanxi', '24', NULL, NULL),
(677, 'شنغهاي', 'Shanghai', 43, 'Shanghai', '23', NULL, NULL),
(678, 'خنان', 'Henan', 43, 'Henan', '09', NULL, NULL),
(679, 'نينغشيا', 'Ningxia', 43, 'Ningxia', '21', NULL, NULL),
(680, 'كونديناماركا', 'Cundinamarca', 44, 'Cundinamarca', '33', NULL, NULL),
(681, 'نورتي دي سانتاندر', 'Norte de Santander', 44, 'Norte de Santander', '21', NULL, NULL),
(682, 'نارينو', 'Narino', 44, 'Narino', '20', NULL, NULL),
(684, 'ريزارالدا', 'Risaralda', 44, 'Risaralda', '24', NULL, NULL),
(685, 'أنتيوكيا', 'Antioquia', 44, 'Antioquia', '02', NULL, NULL),
(686, 'أمازوناس', 'Amazonas', 44, 'Amazonas', '01', NULL, NULL),
(687, 'لا غواخيرا', 'La Guajira', 44, 'La Guajira', '17', NULL, NULL),
(688, 'شوكو', 'Choco', 44, 'Choco', '11', NULL, NULL),
(689, 'كاوكا', 'Cauca', 44, 'Cauca', '09', NULL, NULL),
(690, 'فالي ديل كاوكا', 'Valle del Cauca', 44, 'Valle del Cauca', '29', NULL, NULL),
(691, 'اروكا', 'Arauca', 44, 'Arauca', '03', NULL, NULL),
(692, 'ميتا', 'Meta', 44, 'Meta', '19', NULL, NULL),
(693, 'كاكويتا', 'Caqueta', 44, 'Caqueta', '08', NULL, NULL),
(694, 'كازاناري', 'Casanare', 44, 'Casanare', '32', NULL, NULL),
(695, 'فاوبيس', 'Vaupes', 44, 'Vaupes', '30', NULL, NULL),
(696, 'توليما', 'Tolima', 44, 'Tolima', '28', NULL, NULL),
(697, 'هويلا', 'Huila', 44, 'Huila', '16', NULL, NULL),
(699, 'اتلانتيكو', 'Atlantico', 44, 'Atlantico', '04', NULL, NULL),
(700, 'قرطبة', 'Cordoba', 44, 'Cordoba', '12', NULL, NULL),
(701, 'سانتاندر', 'Santander', 44, 'Santander', '26', NULL, NULL),
(702, 'سيزار', 'Cesar', 44, 'Cesar', '10', NULL, NULL),
(703, 'سوكري', 'Sucre', 44, 'Sucre', '27', NULL, NULL),
(705, 'بوتومايو', 'Putumayo', 44, 'Putumayo', '22', NULL, NULL),
(707, 'غوابياري', 'Guaviare', 44, 'Guaviare', '14', NULL, NULL),
(708, 'San Andres y Providencia', 'San Andres y Providencia', 44, 'San Andres et Providencia', '25', NULL, NULL),
(709, 'فيتشادا', 'Vichada', 44, 'Vichada', '31', NULL, NULL),
(710, 'كوينديو', 'Quindio', 44, 'Quindio', '23', NULL, NULL),
(711, 'غواينيا', 'Guainia', 44, 'Guainia', '15', NULL, NULL),
(712, 'Distrito Especial', 'Distrito Especial', 44, 'Distrito Especial', '34', NULL, NULL),
(713, 'غواناكاست', 'Guanacaste', 45, 'Guanacaste', '03', NULL, NULL),
(714, 'ليمون', 'Limon', 45, 'Limon', '06', NULL, NULL),
(715, 'بونتاريناس', 'Puntarenas', 45, 'Puntarenas', '07', NULL, NULL),
(716, 'ألاخويلا', 'Alajuela', 45, 'Alajuela', '01', NULL, NULL),
(717, 'هيريديا', 'Heredia', 45, 'Heredia', '04', NULL, NULL),
(718, 'سان خوسيه', 'San Jose', 45, 'San Jose', '08', NULL, NULL),
(719, 'قرطاج', 'Cartago', 45, 'Cartago', '02', NULL, NULL),
(720, 'سيينفويغوس', 'Cienfuegos', 46, 'Cienfuegos', '08', NULL, NULL),
(721, 'لا هافانا', 'La Habana', 46, 'La Habana', '11', NULL, NULL),
(722, 'سانتياغو دي كوبا', 'Santiago de Cuba', 46, 'Santiago de Cuba', '15', NULL, NULL),
(723, 'كاماغواي', 'Camaguey', 46, 'Camaguey', '05', NULL, NULL),
(724, 'سيوداد دي لا هافانا', 'Ciudad de la Habana', 46, 'Ciudad de la Habana', '02', NULL, NULL),
(725, 'فيلا كلارا', 'Villa Clara', 46, 'Villa Clara', '16', NULL, NULL),
(726, 'بينار ديل ريو', 'Pinar del Rio', 46, 'Pinar del Rio', '01', NULL, NULL),
(727, 'ماتانزاس', 'Matanzas', 46, 'Matanzas', '03', NULL, NULL),
(728, 'غوانتانامو', 'Guantanamo', 46, 'Guantanamo', '10', NULL, NULL),
(729, 'لاس توناس', 'Las Tunas', 46, 'Las Tunas', '13', NULL, NULL),
(730, 'سييغو دي أفيلا', 'Ciego de Avila', 46, 'Ciego de Avila', '07', NULL, NULL),
(731, 'سانكتي سبيريتوس', 'Sancti Spiritus', 46, 'Sancti Spiritus', '14', NULL, NULL),
(732, 'هولغوين', 'Holguin', 46, 'Holguin', '12', NULL, NULL),
(733, 'غرانما', 'Granma', 46, 'Granma', '09', NULL, NULL),
(734, 'جزيرة دي لا جوفينتود', 'Isla de la Juventud', 46, 'Isla de la Juventud', '04', NULL, NULL),
(735, 'ساو دومينغوس', 'Sao Domingos', 47, 'Sao Domingos', '17', NULL, NULL),
(738, 'ليماسول', 'Limassol', 49, 'Limassol', '05', NULL, NULL),
(739, 'نيقوسيا', 'Nicosia', 49, 'Nicosie', '04', NULL, NULL),
(740, 'بافوس', 'Paphos', 49, 'Paphos', '06', NULL, NULL),
(741, 'فاماغوستا', 'Famagusta', 49, 'Famagusta', '01', NULL, NULL),
(742, 'لارنكا', 'Larnaca', 49, 'Larnaca', '03', NULL, NULL),
(743, 'كيرينيا', 'Kyrenia', 49, 'Kyrenia', '02', NULL, NULL),
(744, 'كارلوفارسكي كراج', 'Karlovarsky kraj', 50, 'Karlovarsky kraj', '81', NULL, NULL),
(745, 'بردوبيكي كراج', 'Pardubicky kraj', 50, 'Pardubicky kraj', '86', NULL, NULL),
(747, 'Jihomoravsky كراج', 'Jihomoravsky kraj', 50, 'Jihomoravsky kraj', '78', NULL, NULL),
(748, 'Jihocesky kraj', 'Jihocesky kraj', 50, 'Jihocesky kraj', '79', NULL, NULL),
(749, 'أولوموكي كراج', 'Olomoucky kraj', 50, 'Olomoucky kraj', '84', NULL, NULL),
(750, 'Moravskoslezsky كراج', 'Moravskoslezsky kraj', 50, 'Moravskoslezsky kraj', '85', NULL, NULL),
(752, 'Kralovehradecky كراج', 'Kralovehradecky kraj', 50, 'Kralovehradecky kraj', '82', NULL, NULL),
(753, 'أوستيكي كراج', 'Ustecky kraj', 50, 'Ustecky kraj', '89', NULL, NULL),
(754, 'Stredocesky كراج', 'Stredocesky kraj', 50, 'Stredocesky kraj', '88', NULL, NULL),
(755, 'فيسوسينا', 'Vysocina', 50, 'Vysocina', '80', NULL, NULL),
(756, 'Plzensky كراج', 'Plzensky kraj', 50, 'Kraj Plzensky', '87', NULL, NULL),
(760, 'زلينسكي كراج', 'Zlinsky kraj', 50, 'Zlinsky kraj', '90', NULL, NULL),
(761, 'هلفني ميستو براها', 'Hlavni mesto Praha', 50, 'Hlavni mesto Praha', '52', NULL, NULL),
(763, 'Liberecky كراج', 'Liberecky kraj', 50, 'Liberecky kraj', '83', NULL, NULL),
(773, 'نوردراين فيستفالن', 'Nordrhein-Westfalen', 51, 'Nordrhein-Westfalen', '07', NULL, NULL),
(774, 'بادن فورتمبيرغ', 'Baden-Wurttemberg', 51, 'Bade-Wurtemberg', '01', NULL, NULL),
(775, 'بايرن ميونيخ', 'Bayern', 51, 'Bayern', '02', NULL, NULL),
(776, 'راينلاند-بفالز', 'Rheinland-Pfalz', 51, 'Rheinland-Pfalz', '08', NULL, NULL),
(777, 'Niedersachsen', 'Niedersachsen', 51, 'Niedersachsen', '06', NULL, NULL),
(778, 'شليسفيغ هولشتاين', 'Schleswig-Holstein', 51, 'Schleswig-Holstein', '10', NULL, NULL),
(779, 'براندنبورغ', 'Brandenburg', 51, 'Brandebourg', '11', NULL, NULL),
(780, 'سكسونيا أنهالت', 'Sachsen-Anhalt', 51, 'Sachsen-Anhalt', '14', NULL, NULL),
(781, 'ساكسن', 'Sachsen', 51, 'Sachsen', '13', NULL, NULL),
(782, 'THÜRINGEN', 'Thuringen', 51, 'Thuringen', '15', NULL, NULL),
(783, 'هيسن', 'Hessen', 51, 'Hesse', '05', NULL, NULL),
(784, 'مكلنبورغ-فوربومرن', 'Mecklenburg-Vorpommern', 51, 'Mecklembourg-Poméranie-Occidentale', '12', NULL, NULL),
(785, 'هامبورغ', 'Hamburg', 51, 'Hambourg', '04', NULL, NULL),
(786, 'البرلينية', 'Berlin', 51, 'Berlin', '16', NULL, NULL),
(787, 'سارلاند', 'Saarland', 51, 'Sarre', '09', NULL, NULL),
(788, 'بريمن', 'Bremen', 51, 'Brême', '03', NULL, NULL),
(789, 'علي صبيح', 'Ali Sabieh', 52, 'Ali Sabieh', '01', NULL, NULL),
(790, 'تاجورا', 'Tadjoura', 52, 'Tadjoura', '05', NULL, NULL),
(792, 'أوبوك', 'Obock', 52, 'Obock', '04', NULL, NULL),
(794, 'أرتا', 'Arta', 52, 'Arta', '08', NULL, NULL),
(795, 'دخيل', 'Dikhil', 52, 'Dikhil', '06', NULL, NULL),
(796, 'سيدانمارك', 'Syddanmark', 53, 'Syddanmark', '21', NULL, NULL),
(797, 'ميتجيلاند', 'Midtjylland', 53, 'Midtjylland', '18', NULL, NULL),
(798, 'نوردلاند', 'Nordjylland', 53, 'Nordjylland', '19', NULL, NULL),
(799, 'Sjelland', 'Sjelland', 53, 'Sjelland', '20', NULL, NULL),
(800, 'هوفدستادين', 'Hovedstaden', 53, 'Hovedstaden', '17', NULL, NULL),
(801, 'القديس أندرو', 'Saint Andrew', 54, 'Saint andrew', '02', NULL, NULL),
(802, 'القديس داود', 'Saint David', 54, 'Saint David', '03', NULL, NULL),
(803, 'القديس يوسف', 'Saint Joseph', 54, 'Saint Joseph', '06', NULL, NULL),
(804, 'القديس جورج', 'Saint George', 54, 'Saint George', '04', NULL, NULL),
(805, 'سانت باتريك', 'Saint Patrick', 54, 'Saint Patrick', '09', NULL, NULL),
(806, 'القديس بطرس', 'Saint Peter', 54, 'Saint Pierre', '11', NULL, NULL),
(807, 'القديس يوحنا', 'Saint John', 54, 'Saint Jean', '05', NULL, NULL),
(808, 'سان مارك', 'Saint Mark', 54, 'Saint mark', '08', NULL, NULL),
(809, 'القديس بول', 'Saint Paul', 54, 'Saint Paul', '10', NULL, NULL),
(810, 'القديس لوقا', 'Saint Luke', 54, 'Saint Luc', '07', NULL, NULL),
(811, 'سانشيز راميريز', 'Sanchez Ramirez', 55, 'Sanchez Ramirez', '21', NULL, NULL),
(812, 'إسبايلات', 'Espaillat', 55, 'Espaillat', '08', NULL, NULL),
(813, 'دوارتي', 'Duarte', 55, 'Duarte', '06', NULL, NULL),
(814, 'سمانا', 'Samana', 55, 'Samana', '20', NULL, NULL),
(815, 'ماريا ترينيداد سانشيز', 'Maria Trinidad Sanchez', 55, 'Maria Trinidad Sanchez', '14', NULL, NULL),
(816, 'لا رومانا', 'La Romana', 55, 'La Romana', '12', NULL, NULL),
(817, 'ازوا', 'Azua', 55, 'Azua', '01', NULL, NULL),
(818, 'سان كريستوبال', 'San Cristobal', 55, 'San Cristobal', '33', NULL, NULL),
(819, 'الصيبو', 'El Seibo', 55, 'El Seibo', '28', NULL, NULL),
(820, 'مونت بلاتا', 'Monte Plata', 55, 'Monte Plata', '32', NULL, NULL),
(821, 'Distrito Nacional', 'Distrito Nacional', 55, 'Distrito Nacional', '05', NULL, NULL),
(822, 'إلياس بينا', 'Elias Pina', 55, 'Elias Pina', '11', NULL, NULL),
(823, 'سانتياغو', 'Santiago', 55, 'Santiago', '25', NULL, NULL),
(824, 'سانتياغو رودريجيز', 'Santiago Rodriguez', 55, 'Santiago Rodriguez', '26', NULL, NULL),
(825, 'بيرافيا', 'Peravia', 55, 'Peravia', '17', NULL, NULL),
(826, 'مونت كريستي', 'Monte Cristi', 55, 'Monte Cristi', '15', NULL, NULL),
(827, 'سالسيدو', 'Salcedo', 55, 'Salcedo', '19', NULL, NULL),
(828, 'بويرتو بلاتا', 'Puerto Plata', 55, 'Puerto Plata', '18', NULL, NULL),
(829, 'سان بيدرو دي ماكوريس', 'San Pedro De Macoris', 55, 'San Pedro De Macoris', '24', NULL, NULL),
(830, 'بدرنالس', 'Pedernales', 55, 'Pedernales', '16', NULL, NULL),
(831, 'الاستقلال', 'Independencia', 55, 'Independencia', '09', NULL, NULL),
(832, 'لا فيغا', 'La Vega', 55, 'La Vega', '30', NULL, NULL),
(833, 'داجابون', 'Dajabon', 55, 'Dajabon', '04', NULL, NULL),
(834, 'حاتو العمدة', 'Hato Mayor', 55, 'Hato Mayor', '29', NULL, NULL),
(835, 'باراهونا', 'Barahona', 55, 'Barahona', '03', NULL, NULL),
(836, 'سان خوان', 'San Juan', 55, 'San Juan', '23', NULL, NULL),
(837, 'لا التاغراسيا', 'La Altagracia', 55, 'La Altagracia', '10', NULL, NULL),
(838, 'فالفيردي', 'Valverde', 55, 'Valverde', '27', NULL, NULL),
(839, 'Baoruco', 'Baoruco', 55, 'Baoruco', '02', NULL, NULL),
(840, 'مونسنور نويل', 'Monsenor Nouel', 55, 'Mgr Nouel', '31', NULL, NULL),
(841, 'عين تموشنت', 'Ain Temouchent', 56, 'Ain Temouchent', '36', NULL, NULL),
(842, 'وهران', 'Oran', 56, 'Oran', '09', NULL, NULL),
(843, 'المدية', 'Medea', 56, 'Médée', '06', NULL, NULL),
(844, 'الشلف', 'Chlef', 56, 'Chlef', '41', NULL, NULL),
(845, 'بشار', 'Bechar', 56, 'Béchar', '38', NULL, NULL),
(846, 'تمنراست', 'Tamanghasset', 56, 'Tamanghasset', '53', NULL, NULL),
(847, 'بجاية', 'Bejaia', 56, 'Bejaia', '18', NULL, NULL),
(848, 'تيزي وزو', 'Tizi Ouzou', 56, 'Tizi Ouzou', '14', NULL, NULL),
(849, 'بومرداس', 'Boumerdes', 56, 'Boumerdes', '40', NULL, NULL),
(850, 'عين الدفلة', 'Ain Defla', 56, 'Ain Defla', '35', NULL, NULL),
(851, 'عنابة', 'Annaba', 56, 'Annaba', '37', NULL, NULL),
(852, 'سطيف', 'Setif', 56, 'Sétif', '12', NULL, NULL),
(853, 'غليزان', 'Relizane', 56, 'Relizane', '51', NULL, NULL),
(854, 'ماسكارا', 'Mascara', 56, 'Mascara', '26', NULL, NULL),
(855, 'مستغانم', 'Mostaganem', 56, 'Mostaganem', '07', NULL, NULL),
(856, 'تيارت', 'Tiaret', 56, 'Tiaret', '13', NULL, NULL),
(857, 'برج بوعريريج', 'Bordj Bou Arreridj', 56, 'Bordj Bou Arreridj', '39', NULL, NULL),
(858, 'تيبازة', 'Tipaza', 56, 'Tipaza', '55', NULL, NULL),
(860, 'البويرة', 'Bouira', 56, 'Bouira', '21', NULL, NULL),
(861, 'تيسمسيلت', 'Tissemsilt', 56, 'Tissemsilt', '56', NULL, NULL),
(862, 'جيجل', 'Jijel', 56, 'Jijel', '24', NULL, NULL),
(863, 'صيدا', 'Saida', 56, 'Saida', '10', NULL, NULL),
(864, 'إليزي', 'Illizi', 56, 'Illizi', '46', NULL, NULL),
(865, 'تلمسان', 'Tlemcen', 56, 'Tlemcen', '15', NULL, NULL),
(866, 'أدرار', 'Adrar', 56, 'Adrar', '34', NULL, NULL),
(867, 'الأغواط', 'Laghouat', 56, 'Laghouat', '25', NULL, NULL),
(868, 'قسنطينة', 'Constantine', 56, 'Constantine', '04', NULL, NULL),
(869, 'خنشلة', 'Khenchela', 56, 'Khenchela', '47', NULL, NULL),
(870, 'باتنة', 'Batna', 56, 'Batna', '03', NULL, NULL),
(871, 'الجزائر', 'Alger', 56, 'Alger', '01', NULL, NULL),
(872, 'مسيلة', 'M\'sila', 56, 'M\'sila', '27', NULL, NULL),
(873, 'سكيكدة', 'Skikda', 56, 'Skikda', '31', NULL, NULL),
(874, 'ام البواقي', 'Oum el Bouaghi', 56, 'Oum el Bouaghi', '29', NULL, NULL),
(875, 'نعمة', 'Naama', 56, 'Naama', '49', NULL, NULL),
(876, 'سيدي بلعباس', 'Sidi Bel Abbes', 56, 'Sidi Bel Abbes', '30', NULL, NULL),
(877, 'ميلة', 'Mila', 56, 'Mila', '48', NULL, NULL),
(878, 'ورقلة', 'Ouargla', 56, 'Ouargla', '50', NULL, NULL),
(879, 'الجلفة', 'Djelfa', 56, 'Djelfa', '22', NULL, NULL),
(880, 'البيض', 'El Bayadh', 56, 'El Bayadh', '42', NULL, NULL),
(881, 'سوق أهراس', 'Souk Ahras', 56, 'Souk Ahras', '52', NULL, NULL),
(882, 'الواد', 'El Oued', 56, 'El Oued', '43', NULL, NULL),
(883, 'البليدة', 'Blida', 56, 'Blida', '20', NULL, NULL);
INSERT INTO `cities` (`id`, `name_ar`, `name_en`, `country_id`, `name_fr`, `code`, `created_at`, `updated_at`) VALUES
(884, 'بسكرة', 'Biskra', 56, 'Biskra', '19', NULL, NULL),
(885, 'تبسة', 'Tebessa', 56, 'Tebessa', '33', NULL, NULL),
(886, 'قالمة', 'Guelma', 56, 'Guelma', '23', NULL, NULL),
(887, 'تندوف', 'Tindouf', 56, 'Tindouf', '54', NULL, NULL),
(888, 'غرداية', 'Ghardaia', 56, 'Ghardaia', '45', NULL, NULL),
(889, 'مانابي', 'Manabi', 57, 'Manabi', '14', NULL, NULL),
(890, 'زامورا-شينشيب', 'Zamora-Chinchipe', 57, 'Zamora-Chinchipe', '20', NULL, NULL),
(891, 'مورونا سانتياغو', 'Morona-Santiago', 57, 'Morona-Santiago', '15', NULL, NULL),
(892, 'اورو', 'El Oro', 57, 'El Oro', '08', NULL, NULL),
(893, 'ازواي', 'Azuay', 57, 'Azuay', '02', NULL, NULL),
(894, 'سوكومبيوس', 'Sucumbios', 57, 'Sucumbios', '22', NULL, NULL),
(895, 'غواياس', 'Guayas', 57, 'Guayas', '10', NULL, NULL),
(896, 'لوس ريوس', 'Los Rios', 57, 'Los Rios', '13', NULL, NULL),
(897, 'وخا', 'Loja', 57, 'Loja', '12', NULL, NULL),
(898, 'شيمبورازو', 'Chimborazo', 57, 'Chimborazo', '06', NULL, NULL),
(899, 'تونغوراهوا', 'Tungurahua', 57, 'Tungurahua', '19', NULL, NULL),
(900, 'ازميرالدا', 'Esmeraldas', 57, 'Esmeraldas', '09', NULL, NULL),
(901, 'بيشينشا', 'Pichincha', 57, 'Pichincha', '18', NULL, NULL),
(902, 'إمبابورا', 'Imbabura', 57, 'Imbabura', '11', NULL, NULL),
(903, 'كوتوباكسي', 'Cotopaxi', 57, 'Cotopaxi', '07', NULL, NULL),
(904, 'كارشي', 'Carchi', 57, 'Carchi', '05', NULL, NULL),
(905, 'نابو', 'Napo', 57, 'Napo', '23', NULL, NULL),
(906, 'كنار', 'Canar', 57, 'Canar', '04', NULL, NULL),
(907, 'باستازا', 'Pastaza', 57, 'Pastaza', '17', NULL, NULL),
(908, 'أوريانا', 'Orellana', 57, 'Orellana', '24', NULL, NULL),
(909, 'بوليفار', 'Bolivar', 57, 'Bolivar', '03', NULL, NULL),
(910, 'غالاباغوس', 'Galapagos', 57, 'Galapagos', '01', NULL, NULL),
(911, 'Harjumaa', 'Harjumaa', 58, 'Harjumaa', '01', NULL, NULL),
(912, 'تارتوما', 'Tartumaa', 58, 'Tartumaa', '18', NULL, NULL),
(913, 'هيوما', 'Hiiumaa', 58, 'Hiiumaa', '02', NULL, NULL),
(914, 'رابلاما', 'Raplamaa', 58, 'Raplamaa', '13', NULL, NULL),
(915, 'فلغما', 'Valgamaa', 58, 'Valgamaa', '19', NULL, NULL),
(916, 'انيما', 'Laanemaa', 58, 'Laanemaa', '07', NULL, NULL),
(917, 'بولفاما', 'Polvamaa', 58, 'Polvamaa', '12', NULL, NULL),
(918, 'بارنوما', 'Parnumaa', 58, 'Parnumaa', '11', NULL, NULL),
(919, 'اني فيريوما', 'Laane-Virumaa', 58, 'Laane-Virumaa', '08', NULL, NULL),
(920, 'يارفا', 'Jarvamaa', 58, 'Jarvamaa', '04', NULL, NULL),
(921, 'فيلجاندي', 'Viljandimaa', 58, 'Viljandimaa', '20', NULL, NULL),
(922, 'ساريما', 'Saaremaa', 58, 'Saaremaa', '14', NULL, NULL),
(923, 'جوغفما', 'Jogevamaa', 58, 'Jogevamaa', '05', NULL, NULL),
(924, 'المؤسسة الدولية للتنمية فيروما', 'Ida-Virumaa', 58, 'Ida-Virumaa', '03', NULL, NULL),
(925, 'فوروما', 'Vorumaa', 58, 'Vorumaa', '21', NULL, NULL),
(926, 'الشرقية', 'Ash Sharqiyah', 59, 'Ash Sharqiyah', '14', NULL, NULL),
(927, 'الغربية', 'Al Gharbiyah', 59, 'Al Gharbiyah', '05', NULL, NULL),
(928, 'الدقهلية', 'Ad Daqahliyah', 59, 'Ad Daqahliyah', '01', NULL, NULL),
(929, 'الجيزة', 'Al Jizah', 59, 'Al Jizah', '08', NULL, NULL),
(930, 'المنيا', 'Al Minya', 59, 'Al Minya', '10', NULL, NULL),
(931, 'كفر الشيخ', 'Kafr ash Shaykh', 59, 'Kafr ash Shaykh', '21', NULL, NULL),
(932, 'البحيرة', 'Al Buhayrah', 59, 'Al Buhayrah', '03', NULL, NULL),
(933, 'قنا', 'Qina', 59, 'Qina', '23', NULL, NULL),
(934, 'القاهره', 'Al Qahirah', 59, 'Al Qahirah', '11', NULL, NULL),
(935, 'الاسكندرية', 'Al Iskandariyah', 59, 'Al Iskandariyah', '06', NULL, NULL),
(936, 'الفيوم', 'Al Fayyum', 59, 'Al Fayyum', '04', NULL, NULL),
(937, 'أسيوط', 'Asyut', 59, 'Asyut', '17', NULL, NULL),
(938, 'المنوفية', 'Al Minufiyah', 59, 'Al Minufiyah', '09', NULL, NULL),
(939, 'بني سويف', 'Bani Suwayf', 59, 'Bani Suwayf', '18', NULL, NULL),
(940, 'القليوبية', 'Al Qalyubiyah', 59, 'Al Qalyubiyah', '12', NULL, NULL),
(941, 'أسوان', 'Aswan', 59, 'Assouan', '16', NULL, NULL),
(942, 'شمال سينا', 'Shamal Sina\'', 59, 'Shamal Sina \'', '27', NULL, NULL),
(943, 'سوهاج', 'Suhaj', 59, 'Suhaj', '24', NULL, NULL),
(944, 'جنب سينا', 'Janub Sina\'', 59, 'Janub Sina \'', '26', NULL, NULL),
(945, 'البحر الاحمر', 'Al Bahr al Ahmar', 59, 'Al Bahr al Ahmar', '02', NULL, NULL),
(946, 'الاسماعيلية', 'Al Isma\'iliyah', 59, 'Al Isma\'iliyah', '07', NULL, NULL),
(947, 'دمياط', 'Dumyat', 59, 'Dumyat', '20', NULL, NULL),
(948, 'مطروح', 'Matruh', 59, 'Matruh', '22', NULL, NULL),
(949, 'كما سوايز', 'As Suways', 59, 'Comme suways', '15', NULL, NULL),
(950, 'الوادي الجديد', 'Al Wadi al Jadid', 59, 'Al Wadi al Jadid', '13', NULL, NULL),
(951, 'بور سعيد', 'Bur Sa\'id', 59, 'Bur Sa\'id', '19', NULL, NULL),
(954, 'أراغون', 'Aragon', 62, 'Aragon', '52', NULL, NULL),
(955, 'غاليسيا', 'Galicia', 62, 'Galice', '58', NULL, NULL),
(956, 'كاستيا ي ليون', 'Castilla y Leon', 62, 'Castille et Leon', '55', NULL, NULL),
(957, 'إكستريمادورا', 'Extremadura', 62, 'Estrémadure', '57', NULL, NULL),
(958, 'بايس فاسكو', 'Pais Vasco', 62, 'Pais Vasco', '59', NULL, NULL),
(959, 'كانتابريا', 'Cantabria', 62, 'Cantabrie', '39', NULL, NULL),
(960, 'نافارا', 'Navarra', 62, 'Navarre', '32', NULL, NULL),
(961, 'أستورياس', 'Asturias', 62, 'Asturies', '34', NULL, NULL),
(962, 'لا ريوخا', 'La Rioja', 62, 'La Rioja', '27', NULL, NULL),
(963, 'كاستيا لا مانشا', 'Castilla-La Mancha', 62, 'Castilla-La Mancha', '54', NULL, NULL),
(964, 'مورسيا', 'Murcia', 62, 'Murcie', '31', NULL, NULL),
(965, 'الأندلس', 'Andalucia', 62, 'Andalousie', '51', NULL, NULL),
(966, 'Comunidad فالنسيانا', 'Comunidad Valenciana', 62, 'Comunidad Valenciana', '60', NULL, NULL),
(967, 'كاتالونيا', 'Catalonia', 62, 'Catalogne', '56', NULL, NULL),
(968, 'جزر الكناري', 'Canarias', 62, 'Canarias', '53', NULL, NULL),
(969, 'مدريد', 'Madrid', 62, 'Madrid', '29', NULL, NULL),
(970, 'ايسلاس باليريس', 'Islas Baleares', 62, 'Islas Baleares', '07', NULL, NULL),
(984, 'أولو', 'Oulu', 64, 'Oulu', '08', NULL, NULL),
(985, 'فنلندا الغربية', 'Western Finland', 64, 'Finlande occidentale', '15', NULL, NULL),
(986, 'ابلاند', 'Lapland', 64, 'Laponie', '06', NULL, NULL),
(987, 'شرق فنلندا', 'Eastern Finland', 64, 'Finlande orientale', '14', NULL, NULL),
(988, 'جنوب فنلندا', 'Southern Finland', 64, 'Finlande méridionale', '13', NULL, NULL),
(989, 'أرض', 'Aland', 64, 'Un terrain', '01', NULL, NULL),
(992, 'شمالي', 'Northern', 65, 'Nord', '03', NULL, NULL),
(993, 'الغربي', 'Western', 65, 'Occidental', '05', NULL, NULL),
(994, 'وسط', 'Central', 65, 'Central', '01', NULL, NULL),
(995, 'الشرقية', 'Eastern', 65, 'Est', '02', NULL, NULL),
(997, 'ثرثرة', 'Yap', 67, 'Japper', '04', NULL, NULL),
(998, 'بوهنباي', 'Pohnpei', 67, 'Pohnpei', '02', NULL, NULL),
(999, 'شوك', 'Chuuk', 67, 'Chuuk', '03', NULL, NULL),
(1000, 'كوسراي', 'Kosrae', 67, 'Kosrae', '01', NULL, NULL),
(1002, 'آكيتن', 'Aquitaine', 69, 'Aquitaine', '97', NULL, NULL),
(1003, 'نور-با-دو-كاليه', 'Nord-Pas-de-Calais', 69, 'Nord-Pas-de-Calais', 'B4', NULL, NULL),
(1004, 'لورين', 'Lorraine', 69, 'Lorraine', 'B2', NULL, NULL),
(1005, 'هوت نورماندي', 'Haute-Normandie', 69, 'Haute-Normandie', 'A7', NULL, NULL),
(1006, 'بيكاردي', 'Picardie', 69, 'Picardie', 'B6', NULL, NULL),
(1007, 'فرانش-كونت', 'Franche-Comte', 69, 'Franche-Comté', 'A6', NULL, NULL),
(1008, 'باي دو لا لوار', 'Pays de la Loire', 69, 'Pays de la Loire', 'B5', NULL, NULL),
(1009, 'الشمبانيا اردين', 'Champagne-Ardenne', 69, 'Champagne-Ardenne', 'A4', NULL, NULL),
(1010, 'مركز', 'Centre', 69, 'Centre', 'A3', NULL, NULL),
(1011, 'لانغدوك روسيون', 'Languedoc-Roussillon', 69, 'Languedoc-Roussillon', 'A9', NULL, NULL),
(1012, 'بواتو-شارانت', 'Poitou-Charentes', 69, 'Poitou-Charentes', 'B7', NULL, NULL),
(1013, 'رون ألب', 'Rhone-Alpes', 69, 'Rhône-Alpes', 'B9', NULL, NULL),
(1014, 'باس نورماندي', 'Basse-Normandie', 69, 'Basse-Normandie', '99', NULL, NULL),
(1015, 'إيل دو فرانس', 'Ile-de-France', 69, 'Ile de France', 'A8', NULL, NULL),
(1016, 'بورغون', 'Bourgogne', 69, 'Bourgogne', 'A1', NULL, NULL),
(1017, 'أوفيرني', 'Auvergne', 69, 'Auvergne', '98', NULL, NULL),
(1018, 'بروفانس ألب كوت دازور', 'Provence-Alpes-Cote d\'Azur', 69, 'Provence-Alpes-Côte d\'Azur', 'B8', NULL, NULL),
(1019, 'كورس', 'Corse', 69, 'Corse', 'A5', NULL, NULL),
(1020, 'الألزاس', 'Alsace', 69, 'Alsace', 'C1', NULL, NULL),
(1021, 'بريتان', 'Bretagne', 69, 'Bretagne', 'A2', NULL, NULL),
(1022, 'ميدي-بيرينيه', 'Midi-Pyrenees', 69, 'Midi-Pyrénées', 'B3', NULL, NULL),
(1023, 'ليموزين', 'Limousin', 69, 'Limousin', 'B1', NULL, NULL),
(1024, 'إيستوير', 'Estuaire', 70, 'Estuaire', '01', NULL, NULL),
(1025, 'ليو نتيم', 'Woleu-Ntem', 70, 'Woleu-Ntem', '09', NULL, NULL),
(1026, 'موين-أوغوي', 'Moyen-Ogooue', 70, 'Moyen-Ogooué', '03', NULL, NULL),
(1027, 'أوغوي البحرية', 'Ogooue-Maritime', 70, 'Ogooue-Maritime', '08', NULL, NULL),
(1028, 'أوغوي لولو', 'Ogooue-Lolo', 70, 'Ogooué-Lolo', '07', NULL, NULL),
(1029, 'أوجوي إيفندو', 'Ogooue-Ivindo', 70, 'Ogooué-Ivindo', '06', NULL, NULL),
(1030, 'أوت أوغوي', 'Haut-Ogooue', 70, 'Haut-Ogooué', '02', NULL, NULL),
(1031, 'نغوني', 'Ngounie', 70, 'Ngounie', '04', NULL, NULL),
(1032, 'النيانغا', 'Nyanga', 70, 'Nyanga', '05', NULL, NULL),
(1033, 'رسيستيرشاير', 'Worcestershire', 71, 'Worcestershire', 'Q4', NULL, NULL),
(1034, 'هامبشاير', 'Hampshire', 71, 'Hampshire', 'F2', NULL, NULL),
(1035, 'هرفوردشير', 'Herefordshire', 71, 'Herefordshire', 'F7', NULL, NULL),
(1036, 'إسيكس', 'Essex', 71, 'Essex', 'E4', NULL, NULL),
(1037, 'بوويز', 'Powys', 71, 'Powys', 'Y8', NULL, NULL),
(1038, 'مونماوثشاير', 'Monmouthshire', 71, 'Monmouthshire', 'Y4', NULL, NULL),
(1039, 'الحدود الاسكتلندية', 'Scottish Borders', 71, 'Scottish Borders', 'T9', NULL, NULL),
(1040, 'كمبريا', 'Cumbria', 71, 'Cumbria', 'C9', NULL, NULL),
(1041, 'ديفون', 'Devon', 71, 'Devon', 'D4', NULL, NULL),
(1042, 'ستافوردشاير', 'Staffordshire', 71, 'Staffordshire', 'M9', NULL, NULL),
(1043, 'دورست', 'Dorset', 71, 'Dorset', 'D6', NULL, NULL),
(1044, 'هيرتفورد', 'Hertford', 71, 'Hertford', 'F8', NULL, NULL),
(1045, 'كامبريدج', 'Cambridgeshire', 71, 'Cambridgeshire', 'C3', NULL, NULL),
(1046, 'لانكشاير', 'Lancashire', 71, 'Lancashire', 'H2', NULL, NULL),
(1047, 'كونوي', 'Conwy', 71, 'Conwy', 'X8', NULL, NULL),
(1048, 'سرديجون', 'Ceredigion', 71, 'Ceredigion', 'X6', NULL, NULL),
(1049, 'روندا سينون تاف', 'Rhondda Cynon Taff', 71, 'Rhondda Cynon Taff', 'Y9', NULL, NULL),
(1050, 'هضبة', 'Highland', 71, 'Montagnes', 'V3', NULL, NULL),
(1051, 'بيرث و كينروس', 'Perth and Kinross', 71, 'Perth et Kinross', 'W1', NULL, NULL),
(1052, 'كيرفيلي', 'Caerphilly', 71, 'Caerphilly', 'X4', NULL, NULL),
(1053, 'Blaenau Gwent', 'Blaenau Gwent', 71, 'Blaenau Gwent', 'X2', NULL, NULL),
(1054, 'ميرثير تيدفيل', 'Merthyr Tydfil', 71, 'Merthyr Tydfil', 'Y3', NULL, NULL),
(1055, 'بيمبروكشاير', 'Pembrokeshire', 71, 'Pembrokeshire', 'Y7', NULL, NULL),
(1056, 'أبردينشاير', 'Aberdeenshire', 71, 'Aberdeenshire', 'T6', NULL, NULL),
(1057, 'جويند', 'Gwynedd', 71, 'Gwynedd', 'Y2', NULL, NULL),
(1058, 'مدينة أبردين', 'Aberdeen City', 71, 'Aberdeen City', 'T5', NULL, NULL),
(1059, 'ناي آلة موسيقية', 'Fife', 71, 'Fifre', 'V1', NULL, NULL),
(1060, 'نيث بورت تالبوت', 'Neath Port Talbot', 71, 'Neath Port Talbot', 'Y5', NULL, NULL),
(1061, 'جزيرة انجلسي', 'Isle of Anglesey', 71, 'Île d\'Anglesey', 'X1', NULL, NULL),
(1062, 'ووكينغهام', 'Wokingham', 71, 'Wokingham', 'Q2', NULL, NULL),
(1063, 'يورك', 'York', 71, 'York', 'Q5', NULL, NULL),
(1064, 'ستيرلينغ', 'Stirling', 71, 'Stirling', 'W6', NULL, NULL),
(1065, 'كرمرثنشير', 'Carmarthenshire', 71, 'Carmarthenshire', 'X7', NULL, NULL),
(1066, 'كارديف', 'Bridgend', 71, 'Bridgend', 'X3', NULL, NULL),
(1067, 'شرق لوثيان', 'East Lothian', 71, 'East Lothian', 'U6', NULL, NULL),
(1068, 'انجوس', 'Angus', 71, 'Angus', 'T7', NULL, NULL),
(1069, 'موراي', 'Moray', 71, 'Moray', 'V6', NULL, NULL),
(1070, 'تورفين', 'Torfaen', 71, 'Torfaen', 'Z2', NULL, NULL),
(1071, 'سوانسي', 'Swansea', 71, 'Swansea', 'Z1', NULL, NULL),
(1072, 'فيل غلامورغان', 'Vale of Glamorgan', 71, 'Vallée de Glamorgan', 'Z3', NULL, NULL),
(1073, 'أوكسفوردشاير', 'Oxfordshire', 71, 'Oxfordshire', 'K2', NULL, NULL),
(1074, 'سيارة بمقعدين', 'Surrey', 71, 'Surrey', 'N7', NULL, NULL),
(1075, 'جنوب لاناركشاير', 'South Lanarkshire', 71, 'Lanarkshire du sud', 'W5', NULL, NULL),
(1076, 'يسترشير', 'Leicestershire', 71, 'Leicestershire', 'H5', NULL, NULL),
(1077, 'ويجان', 'Wigan', 71, 'Wigan', 'P7', NULL, NULL),
(1078, 'نورثهامبتونشاير', 'Northamptonshire', 71, 'Northamptonshire', 'J1', NULL, NULL),
(1079, 'لينكولنشاير', 'Lincolnshire', 71, 'Lincolnshire', 'H7', NULL, NULL),
(1080, 'أرغيل وبوت', 'Argyll and Bute', 71, 'Argyll et Bute', 'T8', NULL, NULL),
(1081, 'نورثمبرلاند', 'Northumberland', 71, 'Northumberland', 'J6', NULL, NULL),
(1082, 'نورفولك', 'Norfolk', 71, 'Norfolk', 'I9', NULL, NULL),
(1083, 'سوليهال', 'Solihull', 71, 'Solihull', 'M2', NULL, NULL),
(1084, 'ريكسهام', 'Wrexham', 71, 'Wrexham', 'Z4', NULL, NULL),
(1085, 'شيشاير', 'Cheshire', 71, 'Cheshire', 'C5', NULL, NULL),
(1086, 'شروبشاير', 'Shropshire', 71, 'Shropshire', 'L6', NULL, NULL),
(1087, 'بانبريدج', 'Banbridge', 71, 'Banbridge', 'R2', NULL, NULL),
(1088, 'جنوب جلوسيسترشاير', 'South Gloucestershire', 71, 'Gloucestershire du sud', 'M6', NULL, NULL),
(1089, 'لوثيان الغربية', 'West Lothian', 71, 'West Lothian', 'W9', NULL, NULL),
(1091, 'كينت', 'Kent', 71, 'Kent', 'G5', NULL, NULL),
(1092, 'ليدز', 'Leeds', 71, 'Leeds', 'H3', NULL, NULL),
(1093, 'سومرست', 'Somerset', 71, 'Somerset', 'M3', NULL, NULL),
(1094, 'جلوسيسترشاير', 'Gloucestershire', 71, 'Gloucestershire', 'E6', NULL, NULL),
(1095, 'باكينجهامشير', 'Buckinghamshire', 71, 'Buckinghamshire', 'B9', NULL, NULL),
(1096, 'كوليرين', 'Coleraine', 71, 'Coleraine', 'R6', NULL, NULL),
(1097, 'كريجافون', 'Craigavon', 71, 'Craigavon', 'R8', NULL, NULL),
(1098, 'أنتريم', 'Antrim', 71, 'Antrim', 'Q6', NULL, NULL),
(1099, 'يمافادي', 'Limavady', 71, 'Limavady', 'S4', NULL, NULL),
(1100, 'أرما', 'Armagh', 71, 'Armagh', 'Q8', NULL, NULL),
(1101, 'بلايميندا', 'Ballymena', 71, 'Ballymena', 'Q9', NULL, NULL),
(1102, 'شمال يوركشاير', 'North Yorkshire', 71, 'Yorkshire du Nord', 'J7', NULL, NULL),
(1103, 'سيفتون', 'Sefton', 71, 'Sefton', 'L8', NULL, NULL),
(1104, 'وارويكشاير', 'Warwickshire', 71, 'Warwickshire', 'P3', NULL, NULL),
(1105, 'ديري', 'Derry', 71, 'Derry', 'S6', NULL, NULL),
(1106, 'ايلين سيار', 'Eilean Siar', 71, 'Eilean Siar', 'W8', NULL, NULL),
(1107, 'شمال لاناركشاير', 'North Lanarkshire', 71, 'North Lanarkshire', 'V8', NULL, NULL),
(1108, 'فالكيرك', 'Falkirk', 71, 'Falkirk', 'U9', NULL, NULL),
(1109, 'جزر شتلاند', 'Shetland Islands', 71, 'Îles Shetland', 'W3', NULL, NULL),
(1110, 'ويلتشير', 'Wiltshire', 71, 'Wiltshire', 'P8', NULL, NULL),
(1111, 'دورهام', 'Durham', 71, 'Durham', 'D8', NULL, NULL),
(1112, 'دارلينجتون', 'Darlington', 71, 'Darlington', 'D1', NULL, NULL),
(1113, 'سوفولك', 'Suffolk', 71, 'Suffolk', 'N5', NULL, NULL),
(1114, 'ديربيشاير', 'Derbyshire', 71, 'Derbyshire', 'D3', NULL, NULL),
(1115, 'والسال', 'Walsall', 71, 'Walsall', 'O8', NULL, NULL),
(1116, 'روثرهام', 'Rotherham', 71, 'Rotherham', 'L3', NULL, NULL),
(1117, 'غرب دنبارتنشير', 'West Dunbartonshire', 71, 'West Dunbartonshire', 'W7', NULL, NULL),
(1118, 'شرق ساسكس', 'East Sussex', 71, 'Sussex de l\'Est', 'E2', NULL, NULL),
(1119, 'كوفنتري', 'Coventry', 71, 'Coventry', 'C7', NULL, NULL),
(1120, 'دربي', 'Derby', 71, 'Derby', 'D2', NULL, NULL),
(1121, 'ساوثيند على البحر', 'Southend-on-Sea', 71, 'Southend-on-Sea', 'M5', NULL, NULL),
(1122, 'كلاكمانشاير', 'Clackmannanshire', 71, 'Clackmannanshire', 'U1', NULL, NULL),
(1123, 'كركليس', 'Kirklees', 71, 'Kirklees', 'G8', NULL, NULL),
(1124, 'سانت هيلينز', 'St. Helens', 71, 'St. Helens', 'N1', NULL, NULL),
(1125, 'أوما', 'Omagh', 71, 'Omagh', 'T3', NULL, NULL),
(1126, 'كورنوال', 'Cornwall', 71, 'Cornouailles', 'C6', NULL, NULL),
(1127, 'شمال لينكولنشاير', 'North Lincolnshire', 71, 'Lincolnshire du Nord', 'J3', NULL, NULL),
(1128, 'نيوري ومورن', 'Newry and Mourne', 71, 'Newry et Morne', 'S9', NULL, NULL),
(1129, 'جنوب ايرشاير', 'South Ayrshire', 71, 'Ayrshire du sud', 'W4', NULL, NULL),
(1130, 'جزيرة وايت', 'Isle of Wight', 71, 'l\'île de Wight', 'G2', NULL, NULL),
(1132, 'دومفريز وجالاوي', 'Dumfries and Galloway', 71, 'Dumfries et Galloway', 'U2', NULL, NULL),
(1133, 'بيدفوردشير', 'Bedfordshire', 71, 'Bedfordshire', 'A5', NULL, NULL),
(1134, 'أسفل', 'Down', 71, 'Vers le bas', 'R9', NULL, NULL),
(1135, 'دونجانون', 'Dungannon', 71, 'Dungannon', 'S1', NULL, NULL),
(1136, 'رينفروشاير', 'Renfrewshire', 71, 'Renfrewshire', 'W2', NULL, NULL),
(1137, 'ليستر', 'Leicester', 71, 'Leicester', 'H4', NULL, NULL),
(1138, 'مدينة غلاسكو', 'Glasgow City', 71, 'Glasgow City', 'V2', NULL, NULL),
(1139, 'غرب ساسكس', 'West Sussex', 71, 'West Sussex', 'P6', NULL, NULL),
(1140, 'وارينغتون', 'Warrington', 71, 'Warrington', 'P2', NULL, NULL),
(1141, 'كوكستاون', 'Cookstown', 71, 'Cookstown', 'R7', NULL, NULL),
(1142, 'شمال ايرشاير', 'North Ayrshire', 71, 'Ayrshire du Nord', 'V7', NULL, NULL),
(1143, 'بارنسلي', 'Barnsley', 71, 'Barnsley', 'A3', NULL, NULL),
(1144, 'استربان', 'Strabane', 71, 'Strabane', 'T4', NULL, NULL),
(1145, 'دونكاستر', 'Doncaster', 71, 'Doncaster', 'D5', NULL, NULL),
(1146, 'بلموني', 'Ballymoney', 71, 'Ballymoney', 'R1', NULL, NULL),
(1147, 'فيرماناغ', 'Fermanagh', 71, 'Fermanagh', 'S2', NULL, NULL),
(1149, 'نوتنغهام', 'Nottingham', 71, 'Nottingham', 'J8', NULL, NULL),
(1151, 'تامسايد', 'Tameside', 71, 'Tameside', 'O1', NULL, NULL),
(1152, 'روتلاند', 'Rutland', 71, 'Rutland', 'L4', NULL, NULL),
(1153, 'نوتينغمشير', 'Nottinghamshire', 71, 'Nottinghamshire', 'J9', NULL, NULL),
(1154, 'ميدلوثيان', 'Midlothian', 71, 'Midlothian', 'V5', NULL, NULL),
(1155, 'شرق ايرشاير', 'East Ayrshire', 71, 'East Ayrshire', 'U4', NULL, NULL),
(1156, 'ستوك أون ترينت', 'Stoke-on-Trent', 71, 'Stoke-on-Trent', 'N4', NULL, NULL),
(1157, 'بريستول', 'Bristol', 71, 'Bristol', 'B7', NULL, NULL),
(1158, 'فلينتشير', 'Flintshire', 71, 'Flintshire', 'Y1', NULL, NULL),
(1159, 'بلاكبيرن مع داروين', 'Blackburn with Darwen', 71, 'Blackburn avec Darwen', 'A8', NULL, NULL),
(1160, 'مويلي', 'Moyle', 71, 'Moyle', 'S8', NULL, NULL),
(1161, 'كاريكفرجس', 'Carrickfergus', 71, 'Carrickfergus', 'R4', NULL, NULL),
(1162, 'كاسلرا', 'Castlereagh', 71, 'Castlereagh', 'R5', NULL, NULL),
(1163, 'ليرن', 'Larne', 71, 'Larne', 'S3', NULL, NULL),
(1164, 'بلفاست', 'Belfast', 71, 'Belfast', 'R3', NULL, NULL),
(1165, 'مايرافلت', 'Magherafelt', 71, 'Magherafelt', 'S7', NULL, NULL),
(1166, 'شمال داون', 'North Down', 71, 'Nord en bas', 'T2', NULL, NULL),
(1167, 'شمال سومرست', 'North Somerset', 71, 'North Somerset', 'J4', NULL, NULL),
(1168, 'شرق رينفروشاير', 'East Renfrewshire', 71, 'East Renfrewshire', 'U7', NULL, NULL),
(1169, 'نيوبورت', 'Newport', 71, 'Newport', 'Y6', NULL, NULL),
(1170, 'باث وشمال شرق سومرست', 'Bath and North East Somerset', 71, 'Bath et North East Somerset', 'A4', NULL, NULL),
(1173, 'نيوهام', 'Newham', 71, 'Newham', 'I8', NULL, NULL),
(1175, 'دنبيشير', 'Denbighshire', 71, 'Denbighshire', 'X9', NULL, NULL),
(1176, 'شرق ركوب يوركشاير', 'East Riding of Yorkshire', 71, 'East Riding of Yorkshire', 'E1', NULL, NULL),
(1177, 'بيكسلي', 'Bexley', 71, 'Bexley', 'A6', NULL, NULL),
(1178, 'بروملي', 'Bromley', 71, 'Bromley', 'B8', NULL, NULL),
(1179, 'برادفورد', 'Bradford', 71, 'Bradford', 'B4', NULL, NULL),
(1180, 'غابة براكنيل', 'Bracknell Forest', 71, 'Forêt de Bracknell', 'B3', NULL, NULL),
(1181, 'كارديف', 'Cardiff', 71, 'Cardiff', 'X5', NULL, NULL),
(1182, 'برمنغهام', 'Birmingham', 71, 'Birmingham', 'A7', NULL, NULL),
(1183, 'أوركني', 'Orkney', 71, 'Orkney', 'V9', NULL, NULL),
(1184, 'شرق دانبارتونشاير', 'East Dunbartonshire', 71, 'East Dunbartonshire', 'U5', NULL, NULL),
(1185, 'بلاكبول', 'Blackpool', 71, 'Blackpool', 'A9', NULL, NULL),
(1186, 'ساوثامبتون', 'Southampton', 71, 'Southampton', 'M4', NULL, NULL),
(1187, 'نيوكاسل أبون تاين', 'Newcastle upon Tyne', 71, 'Newcastle upon Tyne', 'I7', NULL, NULL),
(1188, 'بولتون', 'Bolton', 71, 'Boulonner', 'B1', NULL, NULL),
(1189, 'ريدكار وكليفلاند', 'Redcar and Cleveland', 71, 'Redcar et Cleveland', 'K9', NULL, NULL),
(1190, 'بورنموث', 'Bournemouth', 71, 'Bournemouth', 'B2', NULL, NULL),
(1191, 'سويندون', 'Swindon', 71, 'Swindon', 'N9', NULL, NULL),
(1192, 'ستوكبورت', 'Stockport', 71, 'Stockport', 'N2', NULL, NULL),
(1193, 'وندسور ومايدنهيد', 'Windsor and Maidenhead', 71, 'Windsor et Maidenhead', 'P9', NULL, NULL),
(1194, 'إنفركلايد', 'Inverclyde', 71, 'Inverclyde', 'V4', NULL, NULL),
(1195, 'ميدواي', 'Medway', 71, 'Medway', 'I3', NULL, NULL),
(1196, 'ميلتون كينز', 'Milton Keynes', 71, 'Milton Keynes', 'I6', NULL, NULL),
(1197, 'دندي سيتي', 'Dundee City', 71, 'Dundee City', 'U3', NULL, NULL),
(1198, 'تيلفورد وركين', 'Telford and Wrekin', 71, 'Telford et Wrekin', 'O2', NULL, NULL),
(1199, 'قراءة', 'Reading', 71, 'En train de lire', 'K7', NULL, NULL),
(1200, 'دفن', 'Bury', 71, 'Enterrer', 'C1', NULL, NULL),
(1201, 'ولفرهامبتون', 'Wolverhampton', 71, 'Wolverhampton', 'Q3', NULL, NULL),
(1202, 'ساوثوورك', 'Southwark', 71, 'Southwark', 'M8', NULL, NULL),
(1203, 'كامدن', 'Camden', 71, 'Camden', 'C4', NULL, NULL),
(1204, 'مستنقع', 'Slough', 71, 'Bourbier', 'M1', NULL, NULL),
(1205, 'ميدلسبره', 'Middlesbrough', 71, 'Middlesbrough', 'I5', NULL, NULL),
(1206, 'ستوكتون أون تيز', 'Stockton-on-Tees', 71, 'Stockton-on-Tees', 'N3', NULL, NULL),
(1207, 'نيوتاونبي', 'Newtownabbey', 71, 'Newtownabbey', 'T1', NULL, NULL),
(1208, 'يسبورن', 'Lisburn', 71, 'Lisburn', 'S5', NULL, NULL),
(1210, 'ويشام', 'Lewisham', 71, 'Lewisham', 'H6', NULL, NULL),
(1211, 'غرب بيركشاير', 'West Berkshire', 71, 'West Berkshire', 'P4', NULL, NULL),
(1212, 'مانشستر', 'Manchester', 71, 'Manchester', 'I2', NULL, NULL),
(1213, 'وستمنستر', 'Westminster', 71, 'Westminster', 'P5', NULL, NULL),
(1214, 'أردز', 'Ards', 71, 'Ards', 'Q7', NULL, NULL),
(1215, 'بليموث', 'Plymouth', 71, 'Plymouth', 'K4', NULL, NULL),
(1216, 'كرويدون', 'Croydon', 71, 'Croydon', 'C8', NULL, NULL),
(1217, 'باركينج وداجنهام', 'Barking and Dagenham', 71, 'Barking et Dagenham', 'A1', NULL, NULL),
(1218, 'هارتلبول', 'Hartlepool', 71, 'Hartlepool', 'F5', NULL, NULL),
(1219, 'شيفيلد', 'Sheffield', 71, 'Sheffield', 'L9', NULL, NULL),
(1220, 'أولدهام', 'Oldham', 71, 'Oldham', 'K1', NULL, NULL),
(1221, 'نوزلي', 'Knowsley', 71, 'Knowsley', 'G9', NULL, NULL),
(1222, 'ليفربول', 'Liverpool', 71, 'Liverpool', 'H8', NULL, NULL),
(1223, 'دادلي', 'Dudley', 71, 'Dudley', 'D7', NULL, NULL),
(1224, 'غيتسهيد', 'Gateshead', 71, 'Gateshead', 'E5', NULL, NULL),
(1225, 'إيلينغ', 'Ealing', 71, 'Ealing', 'D9', NULL, NULL),
(1226, 'ادنبره', 'Edinburgh', 71, 'Edinbourg', 'U8', NULL, NULL),
(1227, 'انفيلد', 'Enfield', 71, 'Enfield', 'E3', NULL, NULL),
(1228, 'كلدردل', 'Calderdale', 71, 'Calderdale', 'C2', NULL, NULL),
(1229, 'وقف على', 'Halton', 71, 'Halton', 'E9', NULL, NULL),
(1230, 'شمال تينيسايد', 'North Tyneside', 71, 'North Tyneside', 'J5', NULL, NULL),
(1231, 'ثوروك', 'Thurrock', 71, 'Thurrock', 'O3', NULL, NULL),
(1232, 'شمال شرق لينكولنشاير', 'North East Lincolnshire', 71, 'North East Lincolnshire', 'J2', NULL, NULL),
(1233, 'يرل', 'Wirral', 71, 'Wirral', 'Q1', NULL, NULL),
(1234, 'بتذلل', 'Hackney', 71, 'Hackney', 'E8', NULL, NULL),
(1235, 'هامرسميث وفولهام', 'Hammersmith and Fulham', 71, 'Hammersmith et Fulham', 'F1', NULL, NULL),
(1236, 'هافرينج', 'Havering', 71, 'Havering', 'F6', NULL, NULL),
(1237, 'مسلفة', 'Harrow', 71, 'Herse', 'F4', NULL, NULL),
(1238, 'بارنيت', 'Barnet', 71, 'Barnet', 'A2', NULL, NULL),
(1239, 'هونسلو', 'Hounslow', 71, 'Hounslow', 'G1', NULL, NULL),
(1240, 'برايتون وهوف', 'Brighton and Hove', 71, 'Brighton et Hove', 'B6', NULL, NULL),
(1241, 'كينغستون على هال', 'Kingston upon Hull', 71, 'Kingston upon Hull', 'G6', NULL, NULL),
(1242, 'ريدبريدج', 'Redbridge', 71, 'Redbridge', 'K8', NULL, NULL),
(1243, 'إزلينغتون', 'Islington', 71, 'Islington', 'G3', NULL, NULL),
(1244, 'كنسينغتون وتشيلسي', 'Kensington and Chelsea', 71, 'Kensington et Chelsea', 'G4', NULL, NULL),
(1245, 'كينغستون أبون تيمز', 'Kingston upon Thames', 71, 'Kingston upon Thames', 'G7', NULL, NULL),
(1246, 'لامبث', 'Lambeth', 71, 'Lambeth', 'H1', NULL, NULL),
(1247, 'لندن', 'London', 71, 'Londres', 'H9', NULL, NULL),
(1248, 'لوتون', 'Luton', 71, 'Luton', 'I1', NULL, NULL),
(1249, 'سندرلاند', 'Sunderland', 71, 'Sunderland', 'N6', NULL, NULL),
(1250, 'ميرتون', 'Merton', 71, 'Merton', 'I4', NULL, NULL),
(1251, 'ساندويل', 'Sandwell', 71, 'Sandwell', 'L7', NULL, NULL),
(1252, 'سالفورد', 'Salford', 71, 'Salford', 'L5', NULL, NULL),
(1253, 'بيتربورو', 'Peterborough', 71, 'Peterborough', 'K3', NULL, NULL),
(1254, 'بول', 'Poole', 71, 'Poole', 'K5', NULL, NULL),
(1255, 'برج هامليتس', 'Tower Hamlets', 71, 'Tour des hameaux', 'O5', NULL, NULL),
(1256, 'بورتسموث', 'Portsmouth', 71, 'Portsmouth', 'K6', NULL, NULL),
(1257, 'روتشديل', 'Rochdale', 71, 'Rochdale', 'L2', NULL, NULL),
(1258, 'غرينتش', 'Greenwich', 71, 'Greenwich', 'E7', NULL, NULL),
(1259, 'جنوب تينيسايد', 'South Tyneside', 71, 'South Tyneside', 'M7', NULL, NULL),
(1260, 'ترافورد', 'Trafford', 71, 'Trafford', 'O6', NULL, NULL),
(1261, 'ساتون', 'Sutton', 71, 'Sutton', 'N8', NULL, NULL),
(1262, 'تورباي', 'Torbay', 71, 'Torbay', 'O4', NULL, NULL),
(1263, 'ريتشموند على نهر التايمز', 'Richmond upon Thames', 71, 'Richmond sur la Tamise', 'L1', NULL, NULL),
(1264, 'هيلينغدون', 'Hillingdon', 71, 'Hillingdon', 'F9', NULL, NULL),
(1265, 'ويكفيلد', 'Wakefield', 71, 'Wakefield', 'O7', NULL, NULL),
(1266, 'والثام فوريست', 'Waltham Forest', 71, 'Waltham Forest', 'O9', NULL, NULL),
(1267, 'اندسوورث', 'Wandsworth', 71, 'Wandsworth', 'P1', NULL, NULL),
(1268, 'برنت', 'Brent', 71, 'Brent', 'B5', NULL, NULL),
(1269, 'هارينجي', 'Haringey', 71, 'Haringey', 'F3', NULL, NULL),
(1270, 'القديس أندرو', 'Saint Andrew', 72, 'Saint andrew', '01', NULL, NULL),
(1271, 'القديس جورج', 'Saint George', 72, 'Saint George', '03', NULL, NULL),
(1272, 'القديس داود', 'Saint David', 72, 'Saint David', '02', NULL, NULL),
(1273, 'سانت باتريك', 'Saint Patrick', 72, 'Saint Patrick', '06', NULL, NULL),
(1274, 'سان مارك', 'Saint Mark', 72, 'Saint mark', '05', NULL, NULL),
(1275, 'القديس يوحنا', 'Saint John', 72, 'Saint Jean', '04', NULL, NULL),
(1276, 'أبخازيا', 'Abkhazia', 73, 'Abkhazie', '02', NULL, NULL),
(1277, 'Ninotsmindis Raioni', 'Ninotsmindis Raioni', 73, 'Ninotsmindis Raioni', '39', NULL, NULL),
(1278, 'P\'ot\'i', 'P\'ot\'i', 73, 'P\'ot\'i', '42', NULL, NULL),
(1279, 'Ambrolauris Raioni', 'Ambrolauris Raioni', 73, 'Ambrolauris Raioni', '09', NULL, NULL),
(1280, 'اباشي ريوني', 'Abashis Raioni', 73, 'Abashis Raioni', '01', NULL, NULL),
(1281, 'أخالتسميس ريوني', 'Akhalts\'ikhis Raioni', 73, 'Akhalts\'ikhis Raioni', '07', NULL, NULL),
(1282, 'زيستابونيس ريوني', 'Zestap\'onis Raioni', 73, 'Zestap\'onis Raioni', '62', NULL, NULL),
(1283, 'تسالينججيريس ريوني', 'Tsalenjikhis Raioni', 73, 'Tsalenjikhis Raioni', '58', NULL, NULL),
(1284, 'مارنوليس رايوني', 'Marneulis Raioni', 73, 'Marneulis Raioni', '35', NULL, NULL),
(1285, 'جوريس رايوني', 'Goris Raioni', 73, 'Goris Raioni', '22', NULL, NULL),
(1286, 'كاريسليز ريوني', 'K\'arelis Raioni', 73, 'K\'arelis Raioni', '25', NULL, NULL),
(1287, 'خاشوريس رايوني', 'Khashuris Raioni', 73, 'Khashuris Raioni', '28', NULL, NULL),
(1288, 'كاسبيس رايونى', 'Kaspis Raioni', 73, 'Kaspis Raioni', '26', NULL, NULL),
(1289, 'أجاريا', 'Ajaria', 73, 'Ajaria', '04', NULL, NULL),
(1290, 'متخيسيس ريوني', 'Mts\'khet\'is Raioni', 73, 'Mts\'khet\'is Raioni', '38', NULL, NULL),
(1291, 'Ch\'okhatauris Raioni', 'Ch\'okhatauris Raioni', 73, 'Ch\'okhatauris Raioni', '16', NULL, NULL),
(1292, 'Akhalk\'alak\'is Raioni', 'Akhalk\'alak\'is Raioni', 73, 'Akhalk\'alak\'is Raioni', '06', NULL, NULL),
(1293, 'Samtrediis Raioni', 'Samtrediis Raioni', 73, 'Samtrediis Raioni', '48', NULL, NULL),
(1294, 'Tqibuli', 'Tqibuli', 73, 'Tqibuli', '56', NULL, NULL),
(1295, 'Dushet\'is Raioni', 'Dushet\'is Raioni', 73, 'Dushet\'is Raioni', '19', NULL, NULL),
(1296, 'أونيس رايوني', 'Onis Raioni', 73, 'Onis Raioni', '40', NULL, NULL),
(1297, 'Lentekhis Raioni', 'Lentekhis Raioni', 73, 'Lentekhis Raioni', '34', NULL, NULL),
(1298, 'مارتفيليز ريوني', 'Martvilis Raioni', 73, 'Martvilis Raioni', '36', NULL, NULL),
(1299, 'K\'ut\'aisi', 'K\'ut\'aisi', 73, 'K\'ut\'aisi', '31', NULL, NULL),
(1300, 'أخالورجيس رايوني', 'Akhalgoris Raioni', 73, 'Akhalgoris Raioni', '05', NULL, NULL),
(1301, 'Aspindzis Raioni', 'Aspindzis Raioni', 73, 'Aspindzis Raioni', '10', NULL, NULL),
(1302, 'احمدى ريونى', 'Akhmetis Raioni', 73, 'Akhmetis Raioni', '08', NULL, NULL),
(1303, 'Lagodekhis Raioni', 'Lagodekhis Raioni', 73, 'Lagodekhis Raioni', '32', NULL, NULL),
(1304, 'Zugdidis Raioni', 'Zugdidis Raioni', 73, 'Zugdidis Raioni', '64', NULL, NULL),
(1305, 'بورجوميس رايوني', 'Borjomis Raioni', 73, 'Borjomis Raioni', '13', NULL, NULL),
(1306, 'T\'ianet\'is Raioni', 'T\'ianet\'is Raioni', 73, 'T\'ianet\'is Raioni', '55', NULL, NULL),
(1307, 'خبيص الريوني', 'Khobis Raioni', 73, 'Khobis Raioni', '29', NULL, NULL),
(1308, 'Kharagaulis Raioni', 'Kharagaulis Raioni', 73, 'Kharagaulis Raioni', '27', NULL, NULL),
(1309, 'فانيس ريوني', 'Vanis Raioni', 73, 'Vanis Raioni', '61', NULL, NULL),
(1310, 'تيلافيس ريوني', 'T\'elavis Raioni', 73, 'T\'elavis Raioni', '52', NULL, NULL),
(1311, 'تسالكيس رايوني', 'Tsalkis Raioni', 73, 'Tsalkis Raioni', '59', NULL, NULL),
(1312, 'قزبيجايز ريوني', 'Qazbegis Raioni', 73, 'Qazbegis Raioni', '43', NULL, NULL),
(1313, 'ساجاريجوس رايوني', 'Sagarejos Raioni', 73, 'Sagarejos Raioni', '47', NULL, NULL),
(1314, 'تيريتسقاروس ريوني', 'T\'et\'ritsqaros Raioni', 73, 'T\'et\'ritsqaros Raioni', '54', NULL, NULL),
(1315, 'Dedop\'listsqaros Raioni', 'Dedop\'listsqaros Raioni', 73, 'Dedop\'listsqaros Raioni', '17', NULL, NULL),
(1316, 'جافي ريوني', 'Javis Raioni', 73, 'Javis Raioni', '24', NULL, NULL),
(1317, 'Ch\'khorotsqus Raioni', 'Ch\'khorotsqus Raioni', 73, 'Ch\'khorotsqus Raioni', '15', NULL, NULL),
(1318, 'Tsqaltubo', 'Tsqaltubo', 73, 'Tsqaltubo', '60', NULL, NULL),
(1319, 'Rust\'avi', 'Rust\'avi', 73, 'Rust\'avi', '45', NULL, NULL),
(1320, 'تبليسي', 'T\'bilisi', 73, 'T\'bilisi', '51', NULL, NULL),
(1321, 'بغدايس الريوني', 'Baghdat\'is Raioni', 73, 'Baghdat\'is Raioni', '11', NULL, NULL),
(1322, 'Lanch\'khut\'is Raioni', 'Lanch\'khut\'is Raioni', 73, 'Lanch\'khut\'is Raioni', '33', NULL, NULL),
(1323, 'Chiat\'ura', 'Chiat\'ura', 73, 'Chiat\'ura', '14', NULL, NULL),
(1324, 'Ts\'ageris Raioni', 'Ts\'ageris Raioni', 73, 'Ts\'ageris Raioni', '57', NULL, NULL),
(1327, 'وسط', 'Central', 76, 'Central', '04', NULL, NULL),
(1328, 'الغربي', 'Western', 76, 'Occidental', '09', NULL, NULL),
(1329, 'أشانتي', 'Ashanti', 76, 'Ashanti', '02', NULL, NULL),
(1330, 'الشرق الأوسط', 'Upper East', 76, 'Upper East', '10', NULL, NULL),
(1331, 'فولتا', 'Volta', 76, 'Volta', '08', NULL, NULL),
(1332, 'برونغ أهافو', 'Brong-Ahafo', 76, 'Brong-Ahafo', '03', NULL, NULL),
(1333, 'شمالي', 'Northern', 76, 'Nord', '06', NULL, NULL),
(1334, 'أكبر أكرا', 'Greater Accra', 76, 'Grand Accra', '01', NULL, NULL),
(1335, 'أعالي الغرب', 'Upper West', 76, 'Upper West', '11', NULL, NULL),
(1336, 'الشرقية', 'Eastern', 76, 'Est', '05', NULL, NULL),
(1338, 'Vestgronland', 'Vestgronland', 78, 'Vestgronland', '03', NULL, NULL),
(1339, 'Nordgronland', 'Nordgronland', 78, 'Nordgronland', '01', NULL, NULL),
(1340, 'Ostgronland', 'Ostgronland', 78, 'Ostgronland', '02', NULL, NULL),
(1341, 'سنترال ريفر', 'Central River', 79, 'Central River', '03', NULL, NULL),
(1342, 'الغربي', 'Western', 79, 'Occidental', '05', NULL, NULL),
(1343, 'الضفة الشمالية', 'North Bank', 79, 'La Banque du nord', '07', NULL, NULL),
(1344, 'أعالي النهر', 'Upper River', 79, 'Upper River', '04', NULL, NULL),
(1345, 'نهر سفلي', 'Lower River', 79, 'Lower River', '02', NULL, NULL),
(1346, 'بانجول', 'Banjul', 79, 'Banjul', '01', NULL, NULL),
(1347, 'كوروسا', 'Kouroussa', 80, 'Kouroussa', '19', NULL, NULL),
(1348, 'بيلا', 'Beyla', 80, 'Beyla', '01', NULL, NULL),
(1349, 'كوندارا', 'Koundara', 80, 'Koundara', '18', NULL, NULL),
(1350, 'دنجواياري', 'Dinguiraye', 80, 'Dinguiraye', '07', NULL, NULL),
(1351, 'مالي', 'Mali', 80, 'Mali', '22', NULL, NULL),
(1352, 'ماكنتا', 'Macenta', 80, 'Macenta', '21', NULL, NULL),
(1355, 'كيسيدوغو', 'Kissidougou', 80, 'Kissidougou', '17', NULL, NULL),
(1356, 'فوريكاريا', 'Forecariah', 80, 'Forecariah', '10', NULL, NULL),
(1357, 'بيتا', 'Pita', 80, 'Pita', '25', NULL, NULL),
(1361, 'دابولا', 'Dabola', 80, 'Dabola', '05', NULL, NULL),
(1362, 'بوكي', 'Boke', 80, 'Boke', '03', NULL, NULL),
(1363, 'مامو', 'Mamou', 80, 'Mamou', '23', NULL, NULL),
(1364, 'فاراناه', 'Faranah', 80, 'Faranah', '09', NULL, NULL),
(1365, 'تليملي', 'Telimele', 80, 'Telimele', '27', NULL, NULL),
(1366, 'بوفا', 'Boffa', 80, 'Boffa', '02', NULL, NULL),
(1367, 'جوكيدو', 'Gueckedou', 80, 'Gueckedou', '13', NULL, NULL),
(1368, 'كنديا', 'Kindia', 80, 'Kindia', '16', NULL, NULL),
(1369, 'فريا', 'Fria', 80, 'Fria', '11', NULL, NULL),
(1370, 'تواج', 'Tougue', 80, 'Tougue', '28', NULL, NULL),
(1371, 'يومو', 'Yomou', 80, 'Yomou', '29', NULL, NULL),
(1372, 'جاوال', 'Gaoual', 80, 'Gaoual', '12', NULL, NULL),
(1373, 'كيروان', 'Kerouane', 80, 'Kerouane', '15', NULL, NULL),
(1374, 'دالابا', 'Dalaba', 80, 'Dalaba', '06', NULL, NULL),
(1375, 'كوناكري', 'Conakry', 80, 'Conakry', '04', NULL, NULL),
(1376, 'كويا', 'Coyah', 80, 'Coyah', '30', NULL, NULL),
(1377, 'دوبريكا', 'Dubreka', 80, 'Dubreka', '31', NULL, NULL),
(1378, 'كانكان', 'Kankan', 80, 'Kankan', '32', NULL, NULL),
(1379, 'كوبيا', 'Koubia', 80, 'Koubia', '33', NULL, NULL),
(1380, 'ابي', 'Labe', 80, 'Labe', '34', NULL, NULL),
(1381, 'يلوما', 'Lelouma', 80, 'Lelouma', '35', NULL, NULL),
(1382, 'لولا', 'Lola', 80, 'Lola', '36', NULL, NULL),
(1383, 'مانديانا', 'Mandiana', 80, 'Mandiana', '37', NULL, NULL),
(1384, 'نزيريكوري', 'Nzerekore', 80, 'Nzerekore', '38', NULL, NULL),
(1385, 'سيجويري', 'Siguiri', 80, 'Siguiri', '39', NULL, NULL),
(1387, 'سنترو سور', 'Centro Sur', 82, 'Centro Sur', '06', NULL, NULL),
(1388, 'ويلي-نزاس', 'Wele-Nzas', 82, 'Wele-Nzas', '09', NULL, NULL),
(1389, 'كي نتيم', 'Kie-Ntem', 82, 'Kie-Ntem', '07', NULL, NULL),
(1390, 'الساحلي', 'Litoral', 82, 'Litoral', '08', NULL, NULL),
(1391, 'أنوبون', 'Annobon', 82, 'Annobon', '03', NULL, NULL),
(1392, 'بيوكو نورتي', 'Bioko Norte', 82, 'Bioko Norte', '04', NULL, NULL),
(1393, 'بيوكو سور', 'Bioko Sur', 82, 'Bioko Sur', '05', NULL, NULL),
(1395, 'كيلكيس', 'Kilkis', 83, 'Kilkis', '06', NULL, NULL),
(1396, 'لاريسا', 'Larisa', 83, 'Larisa', '21', NULL, NULL),
(1397, 'أتيكي', 'Attiki', 83, 'Attiki', '35', NULL, NULL),
(1398, 'تريكالا', 'Trikala', 83, 'Trikala', '22', NULL, NULL),
(1399, 'بريفيزا', 'Preveza', 83, 'Preveza', '19', NULL, NULL),
(1400, 'Kerkira', 'Kerkira', 83, 'Kerkira', '25', NULL, NULL),
(1401, 'وانينا', 'Ioannina', 83, 'Ioannina', '17', NULL, NULL),
(1402, 'بيلا', 'Pella', 83, 'Pella', '07', NULL, NULL),
(1403, 'سالونيك', 'Thessaloniki', 83, 'Thessalonique', '13', NULL, NULL),
(1404, 'Voiotia', 'Voiotia', 83, 'Voiotia', '33', NULL, NULL),
(1405, 'Kikladhes', 'Kikladhes', 83, 'Kikladhes', '49', NULL, NULL),
(1406, 'كافالا', 'Kavala', 83, 'Kavala', '14', NULL, NULL),
(1407, 'أرغوليس', 'Argolis', 83, 'Argolide', '36', NULL, NULL),
(1408, 'Rethimni', 'Rethimni', 83, 'Rethimni', '44', NULL, NULL),
(1409, 'سيراي', 'Serrai', 83, 'Serrai', '05', NULL, NULL),
(1410, 'اكونيا', 'Lakonia', 83, 'Lakonia', '42', NULL, NULL),
(1411, 'ايراكليون', 'Iraklion', 83, 'Iraklion', '45', NULL, NULL),
(1412, 'اسيتي', 'Lasithi', 83, 'Lasithi', '46', NULL, NULL),
(1413, 'Rodhopi', 'Rodhopi', 83, 'Rodhopi', '02', NULL, NULL),
(1414, 'دراما', 'Drama', 83, 'Drame', '04', NULL, NULL),
(1415, 'ميسينيا', 'Messinia', 83, 'Messinia', '40', NULL, NULL),
(1416, 'إيفويا', 'Evvoia', 83, 'Evia', '34', NULL, NULL),
(1417, 'Akhaia', 'Akhaia', 83, 'Akhaia', '38', NULL, NULL),
(1418, 'ماغنيزيا', 'Magnisia', 83, 'Magnisia', '24', NULL, NULL),
(1419, 'خانيا', 'Khania', 83, 'Khania', '43', NULL, NULL),
(1420, 'Kardhitsa', 'Kardhitsa', 83, 'Kardhitsa', '23', NULL, NULL),
(1421, 'إفروس', 'Evros', 83, 'Evros', '01', NULL, NULL),
(1422, 'Arkadhia', 'Arkadhia', 83, 'Arkadhia', '41', NULL, NULL),
(1423, 'أيتوليا كاي Akarnania', 'Aitolia kai Akarnania', 83, 'Aitolia kai Akarnania', '31', NULL, NULL),
(1424, 'كوزاني', 'Kozani', 83, 'Kozani', '11', NULL, NULL),
(1425, 'ثريبروتيا', 'Thesprotia', 83, 'Thesprotia', '18', NULL, NULL),
(1426, 'يسفوس', 'Lesvos', 83, 'Lesvos', '51', NULL, NULL),
(1427, 'Dhodhekanisos', 'Dhodhekanisos', 83, 'Dhodhekanisos', '47', NULL, NULL),
(1428, 'كيفالونيا', 'Kefallinia', 83, 'Kefallinia', '27', NULL, NULL),
(1429, 'Khios', 'Khios', 83, 'Khios', '50', NULL, NULL),
(1430, 'أرتا', 'Arta', 83, 'Arta', '20', NULL, NULL),
(1431, 'غريفينا', 'Grevena', 83, 'Grevena', '10', NULL, NULL),
(1432, 'زاكينثوس', 'Zakinthos', 83, 'Zakinthos', '28', NULL, NULL),
(1433, 'Evritania', 'Evritania', 83, 'Evritania', '30', NULL, NULL),
(1434, 'فثيوتيس', 'Fthiotis', 83, 'Fthiotis', '29', NULL, NULL),
(1435, 'كاستوريا', 'Kastoria', 83, 'Kastoria', '09', NULL, NULL),
(1436, 'ساموس', 'Samos', 83, 'Samos', '48', NULL, NULL),
(1437, 'إيماثيا', 'Imathia', 83, 'Imathia', '12', NULL, NULL),
(1438, 'فلورينا', 'Florina', 83, 'Florina', '08', NULL, NULL),
(1439, 'بييريا', 'Pieria', 83, 'Pieria', '16', NULL, NULL),
(1440, 'Levkas', 'Levkas', 83, 'Levkas', '26', NULL, NULL),
(1441, 'فوكيس', 'Fokis', 83, 'Fokis', '32', NULL, NULL),
(1442, 'إليا', 'Ilia', 83, 'Ilia', '39', NULL, NULL),
(1443, 'كورينثيا', 'Korinthia', 83, 'Korinthia', '37', NULL, NULL),
(1444, 'كسانتي', 'Xanthi', 83, 'Xanthi', '03', NULL, NULL),
(1445, 'Khalkidhiki', 'Khalkidhiki', 83, 'Khalkidhiki', '15', NULL, NULL),
(1448, 'ايزابال', 'Izabal', 85, 'Izabal', '09', NULL, NULL),
(1449, 'ألتا فيراباس', 'Alta Verapaz', 85, 'Alta Verapaz', '01', NULL, NULL),
(1450, 'ريتالهوليو', 'Retalhuleu', 85, 'Retalhuleu', '15', NULL, NULL),
(1451, 'البروغريسو', 'El Progreso', 85, 'El Progreso', '05', NULL, NULL),
(1452, 'غواتيمالا', 'Guatemala', 85, 'Guatemala', '07', NULL, NULL),
(1453, 'جوتيابا', 'Jutiapa', 85, 'Jutiapa', '11', NULL, NULL),
(1454, 'تشيمالتنانغو', 'Chimaltenango', 85, 'Chimaltenango', '03', NULL, NULL),
(1455, 'شيكيمولا', 'Chiquimula', 85, 'Chiquimula', '04', NULL, NULL),
(1456, 'زاكابا', 'Zacapa', 85, 'Zacapa', '22', NULL, NULL),
(1457, 'جالابا', 'Jalapa', 85, 'Jalapa', '10', NULL, NULL),
(1458, 'سان ماركوس', 'San Marcos', 85, 'San Marcos', '17', NULL, NULL),
(1459, 'كيشي', 'Quiche', 85, 'Quiche', '14', NULL, NULL),
(1460, 'هوهوتنانغو', 'Huehuetenango', 85, 'Huehuetenango', '08', NULL, NULL),
(1461, 'كويتزالتنانغو', 'Quetzaltenango', 85, 'Quetzaltenango', '13', NULL, NULL),
(1462, 'باجا فيراباز', 'Baja Verapaz', 85, 'Baja Verapaz', '02', NULL, NULL),
(1463, 'سانتا روزا', 'Santa Rosa', 85, 'Santa Rosa', '18', NULL, NULL),
(1464, 'سولولا', 'Solola', 85, 'Solola', '19', NULL, NULL),
(1465, 'بيتين', 'Peten', 85, 'Peten', '12', NULL, NULL),
(1466, 'ايسكوينتلا', 'Escuintla', 85, 'Escuintla', '06', NULL, NULL),
(1467, 'سكاتيبيكيز', 'Sacatepequez', 85, 'Sacatepequez', '16', NULL, NULL),
(1468, 'توتونيكابان', 'Totonicapan', 85, 'Totonicapan', '21', NULL, NULL),
(1469, 'سوشيتبيكيز', 'Suchitepequez', 85, 'Suchitepequez', '20', NULL, NULL),
(1470, 'كاشيو', 'Cacheu', 86, 'Cacheu', '06', NULL, NULL),
(1471, 'بومبو', 'Biombo', 86, 'Biombo', '12', NULL, NULL),
(1472, 'أويو', 'Oio', 86, 'Oio', '04', NULL, NULL),
(1473, 'بيساو', 'Bissau', 86, 'Bissau', '11', NULL, NULL),
(1474, 'بافاتا', 'Bafata', 86, 'Bafata', '01', NULL, NULL),
(1475, 'تومبالي', 'Tombali', 86, 'Tombali', '07', NULL, NULL),
(1476, 'غابو', 'Gabu', 86, 'Gabu', '10', NULL, NULL),
(1477, 'بولاما', 'Bolama', 86, 'Bolama', '05', NULL, NULL),
(1478, 'كينارا', 'Quinara', 86, 'Quinara', '02', NULL, NULL),
(1479, 'ماهايكا بيبريس', 'Mahaica-Berbice', 87, 'Mahaica-Berbice', '15', NULL, NULL),
(1480, 'Upper Takutu-Upper Essequibo', 'Upper Takutu-Upper Essequibo', 87, 'Upper Takutu-Upper Essequibo', '19', NULL, NULL),
(1481, 'باريما وايني', 'Barima-Waini', 87, 'Barima-Waini', '10', NULL, NULL),
(1482, 'بومرون سوبينام', 'Pomeroon-Supenaam', 87, 'Pomeroon-Supenaam', '16', NULL, NULL),
(1483, 'ديميرارا ماهايكا', 'Demerara-Mahaica', 87, 'Demerara-Mahaica', '12', NULL, NULL),
(1484, 'جويوني مزروني', 'Cuyuni-Mazaruni', 87, 'Cuyuni-Mazaruni', '11', NULL, NULL),
(1485, 'شرق بيربيس-كورنتي', 'East Berbice-Corentyne', 87, 'Berbice Est-Corentyne', '13', NULL, NULL),
(1486, 'Essequibo Islands-West Demerara', 'Essequibo Islands-West Demerara', 87, 'Essequibo Islands-West Demerara', '14', NULL, NULL),
(1487, 'بوتارو سيباروني', 'Potaro-Siparuni', 87, 'Potaro-Siparuni', '17', NULL, NULL),
(1488, 'Upper Demerara-Berbice', 'Upper Demerara-Berbice', 87, 'Upper Demerara-Berbice', '18', NULL, NULL),
(1490, 'القولون', 'Colon', 89, 'Côlon', '03', NULL, NULL),
(1491, 'تشولوتيكا', 'Choluteca', 89, 'Choluteca', '02', NULL, NULL),
(1492, 'كوماياغوا', 'Comayagua', 89, 'Comayagua', '04', NULL, NULL),
(1493, 'فالي', 'Valle', 89, 'Valle', '17', NULL, NULL),
(1494, 'سانتا باربارا', 'Santa Barbara', 89, 'Santa Barbara', '16', NULL, NULL),
(1495, 'فرانسيسكو مورازان', 'Francisco Morazan', 89, 'Francisco Morazan', '08', NULL, NULL),
(1496, 'الباريسو', 'El Paraiso', 89, 'El Paraiso', '07', NULL, NULL),
(1497, 'هندوراسي', 'Lempira', 89, 'Lempira', '13', NULL, NULL),
(1498, 'كوبان', 'Copan', 89, 'Copan', '05', NULL, NULL),
(1499, 'اولانجو', 'Olancho', 89, 'Olancho', '15', NULL, NULL),
(1500, 'كورتيس', 'Cortes', 89, 'Cortes', '06', NULL, NULL),
(1501, 'يورو', 'Yoro', 89, 'Yoro', '18', NULL, NULL),
(1502, 'أتلانتيدا', 'Atlantida', 89, 'Atlantida', '01', NULL, NULL),
(1503, 'Intibuca', 'Intibuca', 89, 'Intibuca', '10', NULL, NULL),
(1504, 'لاباز', 'La Paz', 89, 'La paz', '12', NULL, NULL),
(1505, 'أوكوتبيك', 'Ocotepeque', 89, 'Ocotepeque', '14', NULL, NULL),
(1506, 'جراسياس ديوس', 'Gracias a Dios', 89, 'Gracias a Dios', '09', NULL, NULL),
(1507, 'ايسلاس دي لا باهيا', 'Islas de la Bahia', 89, 'Islas de la Bahia', '11', NULL, NULL),
(1508, 'بريمورسكو غورانسكا', 'Primorsko-Goranska', 90, 'Primorsko-Goranska', '12', NULL, NULL),
(1509, 'سبليتسكو دالماتينسكا', 'Splitsko-Dalmatinska', 90, 'Splitsko-Dalmatinska', '15', NULL, NULL),
(1510, 'Istarska', 'Istarska', 90, 'Istarska', '04', NULL, NULL),
(1511, 'أوسيجيكو', 'Osjecko-Baranjska', 90, 'Osjecko-Baranjska', '10', NULL, NULL),
(1512, 'فيروفيتيكو-بودرافسكا', 'Viroviticko-Podravska', 90, 'Viroviticko-Podravska', '17', NULL, NULL),
(1513, 'غراد زغرب', 'Grad Zagreb', 90, 'Grad Zagreb', '21', NULL, NULL),
(1514, 'سيساكو موسلافاكا', 'Sisacko-Moslavacka', 90, 'Sisacko-Moslavacka', '14', NULL, NULL),
(1515, 'ليكو سنجسكا', 'Licko-Senjska', 90, 'Licko-Senjska', '08', NULL, NULL),
(1516, 'برودسكو بوسافسكا', 'Brodsko-Posavska', 90, 'Brodsko-Posavska', '02', NULL, NULL),
(1517, 'دوبروفنيك نيريتفا', 'Dubrovacko-Neretvanska', 90, 'Dubrovacko-Neretvanska', '03', NULL, NULL),
(1518, 'بوزيسكو-سلافونسكا', 'Pozesko-Slavonska', 90, 'Pozesko-Slavonska', '11', NULL, NULL),
(1519, 'زاجريباكا', 'Zagrebacka', 90, 'Zagrebacka', '20', NULL, NULL),
(1520, 'بجيلوفارسكو بيلوجوورسكا', 'Bjelovarsko-Bilogorska', 90, 'Bjelovarsko-Bilogorska', '01', NULL, NULL),
(1521, 'فارازدينسكا', 'Varazdinska', 90, 'Varazdinska', '16', NULL, NULL),
(1522, 'فوكوفارسكو سريمسكا', 'Vukovarsko-Srijemska', 90, 'Vukovarsko-Srijemska', '18', NULL, NULL),
(1523, 'كاربينسكو زاجورسكا', 'Krapinsko-Zagorska', 90, 'Krapinsko-Zagorska', '07', NULL, NULL),
(1524, 'كوبرفنيكو كريزفاكا', 'Koprivnicko-Krizevacka', 90, 'Koprivnicko-Krizevacka', '06', NULL, NULL),
(1525, 'كارلوفاكا', 'Karlovacka', 90, 'Karlovacka', '05', NULL, NULL),
(1526, 'سيبينسكو كنينسكا', 'Sibensko-Kninska', 90, 'Sibensko-Kninska', '13', NULL, NULL),
(1527, 'ميديمرسكا', 'Medimurska', 90, 'Medimurska', '09', NULL, NULL),
(1529, 'سود', 'Sud', 91, 'Sud', '12', NULL, NULL),
(1530, 'مركز', 'Centre', 91, 'Centre', '07', NULL, NULL),
(1532, 'كويست', 'Ouest', 91, 'Ouest', '11', NULL, NULL),
(1533, 'نورد', 'Nord', 91, 'Nord', '09', NULL, NULL),
(1534, 'الإقليم الشمالي الغربي', 'Nord-Ouest', 91, 'Nord-Ouest', '03', NULL, NULL),
(1535, 'الشمال الشرقي', 'Nord-Est', 91, 'Nord-Est', '10', NULL, NULL),
(1536, 'الجنوب الشرقي', 'Sud-Est', 91, 'Sud-Est', '13', NULL, NULL),
(1537, 'أرتيبونيت', 'Artibonite', 91, 'Artibonite', '06', NULL, NULL),
(1538, 'كومارم إسترجم', 'Komarom-Esztergom', 92, 'Komarom-Esztergom', '12', NULL, NULL),
(1539, 'فيجر', 'Fejer', 92, 'Fejer', '08', NULL, NULL),
(1540, 'جاز ناجيكن سزولنوك', 'Jasz-Nagykun-Szolnok', 92, 'Jasz-Nagykun-Szolnok', '20', NULL, NULL),
(1541, 'بارانيا', 'Baranya', 92, 'Baranya', '02', NULL, NULL),
(1542, 'سزابولكس زاتمار بيريج', 'Szabolcs-Szatmar-Bereg', 92, 'Szabolcs-Szatmar-Bereg', '18', NULL, NULL),
(1543, 'هيفيز', 'Heves', 92, 'Heves', '11', NULL, NULL),
(1544, 'بورسود أباوج زمبلين', 'Borsod-Abauj-Zemplen', 92, 'Borsod-Abauj-Zemplen', '04', NULL, NULL),
(1545, 'جيور موسون سوبرون', 'Gyor-Moson-Sopron', 92, 'Gyor-Moson-Sopron', '09', NULL, NULL),
(1546, 'الآفات', 'Pest', 92, 'Ravageur', '16', NULL, NULL),
(1547, 'فيزبرم', 'Veszprem', 92, 'Veszprem', '23', NULL, NULL),
(1548, 'البكالوريا كيسكون', 'Bacs-Kiskun', 92, 'Bacs-Kiskun', '01', NULL, NULL),
(1549, 'خدمات القيمة المضافة', 'Vas', 92, 'Vas', '22', NULL, NULL),
(1550, 'هاجدو بيهار', 'Hajdu-Bihar', 92, 'Hajdu-Bihar', '10', NULL, NULL),
(1551, 'زالة', 'Zala', 92, 'Zala', '24', NULL, NULL),
(1552, 'سوموغي', 'Somogy', 92, 'Somogy', '17', NULL, NULL),
(1553, 'تولنا', 'Tolna', 92, 'Tolna', '21', NULL, NULL),
(1554, 'نوجراد', 'Nograd', 92, 'Nograd', '14', NULL, NULL),
(1555, 'بودابست', 'Budapest', 92, 'Budapest', '05', NULL, NULL),
(1556, 'ميشكولتس', 'Miskolc', 92, 'Miskolc', '13', NULL, NULL),
(1557, 'كسونجراد', 'Csongrad', 92, 'Csongrad', '06', NULL, NULL),
(1558, 'ديبريسين', 'Debrecen', 92, 'Debrecen', '07', NULL, NULL),
(1559, 'بيكيس', 'Bekes', 92, 'Bekes', '03', NULL, NULL),
(1560, 'سيجد', 'Szeged', 92, 'Szeged', '19', NULL, NULL),
(1561, 'بيكس', 'Pecs', 92, 'Pécs', '15', NULL, NULL),
(1562, 'جيور', 'Gyor', 92, 'Gyor', '25', NULL, NULL),
(1563, 'جاوا تيمور', 'Jawa Timur', 93, 'Jawa Timur', '08', NULL, NULL),
(1565, 'سولاويزي تينجارا', 'Sulawesi Tenggara', 93, 'Sulawesi Tenggara', '22', NULL, NULL),
(1567, 'نوسا تينجارا تيمور', 'Nusa Tenggara Timur', 93, 'Nusa Tenggara Timur', '18', NULL, NULL),
(1568, 'سولاويسي اوتارا', 'Sulawesi Utara', 93, 'Sulawesi Utara', '31', NULL, NULL),
(1569, 'سومطرة بارات', 'Sumatera Barat', 93, 'Sumatera Barat', '24', NULL, NULL),
(1570, 'اتشيه', 'Aceh', 93, 'Aceh', '01', NULL, NULL),
(1571, 'سولاويزي تنجاه', 'Sulawesi Tengah', 93, 'Sulawesi Tengah', '21', NULL, NULL),
(1575, 'جاوا تينغاه', 'Jawa Tengah', 93, 'Jawa Tengah', '07', NULL, NULL),
(1576, 'جاوا بارات', 'Jawa Barat', 93, 'Jawa Barat', '30', NULL, NULL),
(1577, 'بالي', 'Bali', 93, 'Bali', '02', NULL, NULL),
(1579, 'بانتين', 'Banten', 93, 'Banten', '33', NULL, NULL),
(1580, 'سومطرة اوتارا', 'Sumatera Utara', 93, 'Sumatra Utara', '26', NULL, NULL),
(1581, 'كاليمانتان تيمور', 'Kalimantan Timur', 93, 'Kalimantan Timur', '14', NULL, NULL),
(1582, 'لامبونج', 'Lampung', 93, 'Lampung', '15', NULL, NULL),
(1583, 'نوسا تينجارا بارات', 'Nusa Tenggara Barat', 93, 'Nusa Tenggara Barat', '17', NULL, NULL),
(1584, 'كاليمانتان بارات', 'Kalimantan Barat', 93, 'Kalimantan Barat', '11', NULL, NULL),
(1585, 'كاليمنتان Tengah', 'Kalimantan Tengah', 93, 'Kalimantan Tengah', '13', NULL, NULL),
(1587, 'بنجكولو', 'Bengkulu', 93, 'Bengkulu', '03', NULL, NULL),
(1588, 'جامبي', 'Jambi', 93, 'Jambi', '05', NULL, NULL),
(1589, 'كاليمانتان سيلاتان', 'Kalimantan Selatan', 93, 'Kalimantan Selatan', '12', NULL, NULL),
(1590, 'يوجياكرتا', 'Yogyakarta', 93, 'Yogyakarta', '10', NULL, NULL),
(1591, 'جاكرتا رايا', 'Jakarta Raya', 93, 'Jakarta Raya', '04', NULL, NULL),
(1593, 'مالوكو', 'Maluku', 93, 'Maluku', '28', NULL, NULL),
(1594, 'غالواي', 'Galway', 94, 'Galway', '10', NULL, NULL),
(1595, 'فلين', 'Cork', 94, 'Liège', '04', NULL, NULL),
(1596, 'كيري', 'Kerry', 94, 'Kerry', '11', NULL, NULL),
(1597, 'اللمريكية قصيدة خماسية فكاهية', 'Limerick', 94, 'Limerick', '16', NULL, NULL),
(1598, 'لونجفورد', 'Longford', 94, 'Longford', '18', NULL, NULL),
(1599, 'اويس', 'Laois', 94, 'Laois', '15', NULL, NULL),
(1600, 'وترفورد', 'Waterford', 94, 'Waterford', '27', NULL, NULL),
(1601, 'مايو', 'Mayo', 94, 'Mayo', '20', NULL, NULL),
(1602, 'سليغو', 'Sligo', 94, 'Sligo', '25', NULL, NULL),
(1603, 'كيلدير', 'Kildare', 94, 'Kildare', '12', NULL, NULL),
(1604, 'دبلن', 'Dublin', 94, 'Dublin', '07', NULL, NULL),
(1605, 'ويكلو', 'Wicklow', 94, 'Wicklow', '31', NULL, NULL),
(1606, 'كافان', 'Cavan', 94, 'Cavan', '02', NULL, NULL),
(1607, 'كيلكيني', 'Kilkenny', 94, 'Kilkenny', '13', NULL, NULL),
(1608, 'ويكسفورد', 'Wexford', 94, 'Wexford', '30', NULL, NULL),
(1609, 'كارلو', 'Carlow', 94, 'Carlow', '01', NULL, NULL),
(1610, 'أوفالي', 'Offaly', 94, 'Offaly', '23', NULL, NULL),
(1611, 'موناغان', 'Monaghan', 94, 'Monaghan', '22', NULL, NULL),
(1612, 'يتريم', 'Leitrim', 94, 'Leitrim', '14', NULL, NULL),
(1613, 'كلير', 'Clare', 94, 'Clare', '03', NULL, NULL),
(1614, 'دونيجال', 'Donegal', 94, 'Donegal', '06', NULL, NULL),
(1615, 'لاوث', 'Louth', 94, 'Louth', '19', NULL, NULL),
(1616, 'روسكومون', 'Roscommon', 94, 'Roscommon', '24', NULL, NULL),
(1617, 'تيبيراري', 'Tipperary', 94, 'Tipperary', '26', NULL, NULL),
(1618, 'ستميث', 'Westmeath', 94, 'Westmeath', '29', NULL, NULL),
(1619, 'ميث', 'Meath', 94, 'Meath', '21', NULL, NULL),
(1627, 'ولاية البنغال الغربية', 'West Bengal', 96, 'Bengale de l\'ouest', '28', NULL, NULL),
(1628, 'أوتار براديش', 'Uttar Pradesh', 96, 'Uttar Pradesh', '36', NULL, NULL),
(1629, 'البنجاب', 'Punjab', 96, 'Punjab', '23', NULL, NULL),
(1630, 'ماديا براديش', 'Madhya Pradesh', 96, 'Madhya Pradesh', '35', NULL, NULL),
(1631, 'كارناتاكا', 'Karnataka', 96, 'Karnataka', '19', NULL, NULL),
(1632, 'ماهاراشترا', 'Maharashtra', 96, 'Maharashtra', '16', NULL, NULL),
(1633, 'هاريانا', 'Haryana', 96, 'Haryana', '10', NULL, NULL),
(1634, 'أوتارانتشال', 'Uttarakhand', 96, 'Uttarakhand', '39', NULL, NULL),
(1635, 'ولاية اندرا براديش', 'Andhra Pradesh', 96, 'Andhra Pradesh', '02', NULL, NULL),
(1636, 'تريبورا', 'Tripura', 96, 'Tripura', '26', NULL, NULL),
(1637, 'تاميل نادو', 'Tamil Nadu', 96, 'Tamil Nadu', '25', NULL, NULL),
(1638, 'جامو وكشمير', 'Jammu and Kashmir', 96, 'Jammu et Cachemire', '12', NULL, NULL),
(1639, 'جزر أندامان ونيكوبار', 'Andaman and Nicobar Islands', 96, 'Iles Andaman et Nicobar', '01', NULL, NULL),
(1640, 'أسام', 'Assam', 96, 'Assam', '03', NULL, NULL),
(1641, 'تشهاتيسجاره', 'Chhattisgarh', 96, 'Chhattisgarh', '37', NULL, NULL),
(1642, 'راجستان', 'Rajasthan', 96, 'Rajasthan', '24', NULL, NULL),
(1643, 'غوا', 'Goa', 96, 'Goa', '33', NULL, NULL),
(1644, 'بودوتشيري', 'Puducherry', 96, 'Puducherry', '22', NULL, NULL),
(1645, 'غوجارات', 'Gujarat', 96, 'Gujarat', '09', NULL, NULL),
(1646, 'ولاية كيرالا', 'Kerala', 96, 'Kerala', '13', NULL, NULL),
(1647, 'اروناتشال براديش', 'Arunachal Pradesh', 96, 'Arunachal Pradesh', '30', NULL, NULL),
(1648, 'أوريسا', 'Orissa', 96, 'Orissa', '21', NULL, NULL),
(1649, 'هيماشال براديش', 'Himachal Pradesh', 96, 'Himachal Pradesh', '11', NULL, NULL),
(1650, 'بيهار', 'Bihar', 96, 'Bihar', '34', NULL, NULL),
(1651, 'ميغالايا', 'Meghalaya', 96, 'Meghalaya', '18', NULL, NULL),
(1652, 'ناجالاند', 'Nagaland', 96, 'Nagaland', '20', NULL, NULL),
(1653, 'مانيبور', 'Manipur', 96, 'Manipur', '17', NULL, NULL),
(1654, 'ميزورام', 'Mizoram', 96, 'Mizoram', '31', NULL, NULL),
(1655, 'جهارخاند', 'Jharkhand', 96, 'Jharkhand', '38', NULL, NULL),
(1657, 'دلهي', 'Delhi', 96, 'Delhi', '07', NULL, NULL),
(1658, 'دادرا وناغار هافيلي', 'Dadra and Nagar Haveli', 96, 'Dadra et Nagar Haveli', '06', NULL, NULL),
(1660, 'دامان وديو', 'Daman and Diu', 96, 'Daman et Diu', '32', NULL, NULL);
INSERT INTO `cities` (`id`, `name_ar`, `name_en`, `country_id`, `name_fr`, `code`, `created_at`, `updated_at`) VALUES
(1661, 'سيكيم', 'Sikkim', 96, 'Sikkim', '29', NULL, NULL),
(1662, 'شانديغار', 'Chandigarh', 96, 'Chandigarh', '05', NULL, NULL),
(1663, 'اكشادويب', 'Lakshadweep', 96, 'Lakshadweep', '14', NULL, NULL),
(1664, 'السليمانية', 'As Sulaymaniyah', 97, 'Comme Sulaymaniyah', '05', NULL, NULL),
(1665, 'ذي قار', 'Dhi Qar', 97, 'Dhi Qar', '09', NULL, NULL),
(1666, 'ميسان', 'Maysan', 97, 'Maysan', '14', NULL, NULL),
(1667, 'ديالى', 'Diyala', 97, 'Diyala', '10', NULL, NULL),
(1668, 'بغداد', 'Baghdad', 97, 'Bagdad', '07', NULL, NULL),
(1669, 'أكانت', 'Wasit', 97, 'Était-ce', '16', NULL, NULL),
(1670, 'صلاح الدين', 'Salah ad Din', 97, 'Salah ad Din', '18', NULL, NULL),
(1671, 'القادسية', 'Al Qadisiyah', 97, 'Al Qadisiyah', '04', NULL, NULL),
(1672, 'بابل', 'Babil', 97, 'Babil', '06', NULL, NULL),
(1673, 'كربلاء', 'Karbala\'', 97, 'Karbala \'', '12', NULL, NULL),
(1674, 'النجف', 'An Najaf', 97, 'Un najaf', '17', NULL, NULL),
(1675, 'المثنى', 'Al Muthanna', 97, 'Al Muthanna', '03', NULL, NULL),
(1676, 'الانبار', 'Al Anbar', 97, 'Al anbar', '01', NULL, NULL),
(1677, 'دهوك', 'Dahuk', 97, 'Dahuk', '08', NULL, NULL),
(1678, 'نينوى', 'Ninawa', 97, 'Ninawa', '15', NULL, NULL),
(1679, 'اربيل', 'Arbil', 97, 'Arbil', '11', NULL, NULL),
(1680, 'البصرة', 'Al Basrah', 97, 'Al Basrah', '02', NULL, NULL),
(1681, 'في التميم', 'At Ta\'mim', 97, 'Chez ta\'mim', '13', NULL, NULL),
(1682, 'زنجان', 'Zanjan', 98, 'Zanjan', '27', NULL, NULL),
(1683, 'أزربايجان بختاري', 'Azarbayjan-e Bakhtari', 98, 'Azarbayjan-e Bakhtari', '01', NULL, NULL),
(1684, 'يزد', 'Yazd', 98, 'Yazd', '31', NULL, NULL),
(1685, 'خوزستان', 'Khuzestan', 98, 'Khuzestan', '15', NULL, NULL),
(1686, 'أصفهان', 'Esfahan', 98, 'Esfahan', '28', NULL, NULL),
(1687, 'أردبيل', 'Ardabil', 98, 'Ardabil', '32', NULL, NULL),
(1688, 'طهران', 'Tehran', 98, 'Téhéran', '26', NULL, NULL),
(1689, 'شرق ازربايجان', 'East Azarbaijan', 98, 'Azarbaijan Est', '33', NULL, NULL),
(1690, 'بوشهر', 'Bushehr', 98, 'Bushehr', '22', NULL, NULL),
(1691, 'هرمزكان', 'Hormozgan', 98, 'Hormozgan', '11', NULL, NULL),
(1692, 'مازندران', 'Mazandaran', 98, 'Mazandaran', '17', NULL, NULL),
(1693, 'كرمان', 'Kerman', 98, 'Kerman', '29', NULL, NULL),
(1694, 'فارس', 'Fars', 98, 'Fars', '07', NULL, NULL),
(1695, 'Kohkiluyeh va Buyer Ahmadi', 'Kohkiluyeh va Buyer Ahmadi', 98, 'Kohkiluyeh va Acheteur Ahmadi', '05', NULL, NULL),
(1696, 'خراسان', 'Khorasan', 98, 'Khorasan', '30', NULL, NULL),
(1697, 'سيستان وبلوتشستان', 'Sistan va Baluchestan', 98, 'Sistan va Baluchestan', '04', NULL, NULL),
(1698, 'Chahar Mahall va Bakhtiari', 'Chahar Mahall va Bakhtiari', 98, 'Chahar Mahall va Bakhtiari', '03', NULL, NULL),
(1699, 'كرمان', 'Kerman', 98, 'Kerman', '12', NULL, NULL),
(1700, 'مازندران', 'Mazandaran', 98, 'Mazandaran', '35', NULL, NULL),
(1701, 'قزوين', 'Qazvin', 98, 'Qazvin', '38', NULL, NULL),
(1702, 'زنجان', 'Zanjan', 98, 'Zanjan', '36', NULL, NULL),
(1703, 'المركزي', 'Markazi', 98, 'Markazi', '24', NULL, NULL),
(1704, 'المركزي', 'Markazi', 98, 'Markazi', '19', NULL, NULL),
(1705, 'ورستان', 'Lorestan', 98, 'Lorestan', '23', NULL, NULL),
(1706, 'المركزي', 'Markazi', 98, 'Markazi', '34', NULL, NULL),
(1707, 'خراسان رضوي', 'Khorasan-e Razavi', 98, 'Khorasan-e Razavi', '42', NULL, NULL),
(1708, 'همدان', 'Hamadan', 98, 'Hamadan', '09', NULL, NULL),
(1709, 'سمنان', 'Semnan', 98, 'Semnan', '25', NULL, NULL),
(1710, 'جيلان', 'Gilan', 98, 'Gilan', '08', NULL, NULL),
(1711, 'كردستان', 'Kordestan', 98, 'Kordestan', '16', NULL, NULL),
(1712, 'Bakhtaran', 'Bakhtaran', 98, 'Bakhtaran', '13', NULL, NULL),
(1713, 'إيلام', 'Ilam', 98, 'Ilam', '10', NULL, NULL),
(1714, 'مقاطعة سمنان', 'Semnan Province', 98, 'Province de Semnan', '18', NULL, NULL),
(1715, 'كلستان', 'Golestan', 98, 'Golestan', '37', NULL, NULL),
(1716, 'قم', 'Qom', 98, 'Qom', '39', NULL, NULL),
(1718, 'زنجان', 'Zanjan', 98, 'Zanjan', '21', NULL, NULL),
(1720, 'Skagafjardarsysla', 'Skagafjardarsysla', 99, 'Skagafjardarsysla', '28', NULL, NULL),
(1721, 'Borgarfjardarsysla', 'Borgarfjardarsysla', 99, 'Borgarfjardarsysla', '07', NULL, NULL),
(1722, 'Myrasysla', 'Myrasysla', 99, 'Myrasysla', '17', NULL, NULL),
(1723, 'Rangarvallasysla', 'Rangarvallasysla', 99, 'Rangarvallasysla', '23', NULL, NULL),
(1724, 'Eyjafjardarsysla', 'Eyjafjardarsysla', 99, 'Eyjafjardarsysla', '09', NULL, NULL),
(1725, 'Kjosarsysla', 'Kjosarsysla', 99, 'Kjosarsysla', '15', NULL, NULL),
(1726, 'Vestur-Isafjardarsysla', 'Vestur-Isafjardarsysla', 99, 'Vestur-Isafjardarsysla', '36', NULL, NULL),
(1728, 'Strandasysla', 'Strandasysla', 99, 'Strandasysla', '30', NULL, NULL),
(1729, 'Gullbringusysla', 'Gullbringusysla', 99, 'Gullbringusysla', '10', NULL, NULL),
(1730, 'Austur-Hunavatnssysla', 'Austur-Hunavatnssysla', 99, 'Austur-Hunavatnssysla', '05', NULL, NULL),
(1731, 'Austur-Skaftafellssysla', 'Austur-Skaftafellssysla', 99, 'Austur-Skaftafellssysla', '06', NULL, NULL),
(1732, 'Nordur-Mulasysla', 'Nordur-Mulasysla', 99, 'Nordur-Mulasysla', '20', NULL, NULL),
(1733, 'Sudur-Mulasysla', 'Sudur-Mulasysla', 99, 'Sudur-Mulasysla', '31', NULL, NULL),
(1734, 'Vestur-Bardastrandarsysla', 'Vestur-Bardastrandarsysla', 99, 'Vestur-Bardastrandarsysla', '34', NULL, NULL),
(1735, 'Snafellsnes- og Hnappadalssysla', 'Snafellsnes- og Hnappadalssysla', 99, 'Snafellsnes- og Hnappadalssysla', '29', NULL, NULL),
(1736, 'Arnessysla', 'Arnessysla', 99, 'Arnessysla', '03', NULL, NULL),
(1737, 'Vestur-Hunavatnssysla', 'Vestur-Hunavatnssysla', 99, 'Vestur-Hunavatnssysla', '35', NULL, NULL),
(1738, 'Sudur-Tingeyjarsysla', 'Sudur-Tingeyjarsysla', 99, 'Sudur-Tingeyjarsysla', '32', NULL, NULL),
(1740, 'Vestur-Skaftafellssysla', 'Vestur-Skaftafellssysla', 99, 'Vestur-Skaftafellssysla', '37', NULL, NULL),
(1742, 'Nordur-Tingeyjarsysla', 'Nordur-Tingeyjarsysla', 99, 'Nordur-Tingeyjarsysla', '21', NULL, NULL),
(1743, 'توسكانا', 'Toscana', 100, 'Toscana', '16', NULL, NULL),
(1744, 'فينيتو', 'Veneto', 100, 'Vénétie', '20', NULL, NULL),
(1745, 'كامبانيا', 'Campania', 100, 'Campanie', '04', NULL, NULL),
(1746, 'مارتش', 'Marche', 100, 'Marches', '10', NULL, NULL),
(1747, 'بيمونتي', 'Piemonte', 100, 'Piemonte', '12', NULL, NULL),
(1748, 'لومبارديا', 'Lombardia', 100, 'Lombardie', '09', NULL, NULL),
(1749, 'ساردينيا', 'Sardegna', 100, 'Sardegna', '14', NULL, NULL),
(1750, 'أبروتسو', 'Abruzzi', 100, 'Abruzzes', '01', NULL, NULL),
(1751, 'إيميليا-رومانيا', 'Emilia-Romagna', 100, 'Emilie-Romagne', '05', NULL, NULL),
(1752, 'ترينتينو ألتو أديجي', 'Trentino-Alto Adige', 100, 'Trentin-Haut-Adige', '17', NULL, NULL),
(1753, 'أومبريا', 'Umbria', 100, 'Ombrie', '18', NULL, NULL),
(1754, 'باسيليكاتا', 'Basilicata', 100, 'Basilicate', '02', NULL, NULL),
(1755, 'بوليا', 'Puglia', 100, 'Pouilles', '13', NULL, NULL),
(1756, 'صقلية', 'Sicilia', 100, 'Sicilia', '15', NULL, NULL),
(1757, 'لاتسيو', 'Lazio', 100, 'Lazio', '07', NULL, NULL),
(1758, 'ليغوريا', 'Liguria', 100, 'Ligurie', '08', NULL, NULL),
(1759, 'كالابريا', 'Calabria', 100, 'Calabre', '03', NULL, NULL),
(1760, 'موليز', 'Molise', 100, 'Molise', '11', NULL, NULL),
(1761, 'فريولي فينيتسيا جوليا', 'Friuli-Venezia Giulia', 100, 'Frioul-Vénétie Julienne', '06', NULL, NULL),
(1762, 'فالي أوستا', 'Valle d\'Aosta', 100, 'Valle d\'Aosta', '19', NULL, NULL),
(1764, 'سانت آن', 'Saint Ann', 101, 'Sainte ann', '09', NULL, NULL),
(1765, 'سانت إليزابيث', 'Saint Elizabeth', 101, 'Saint elizabeth', '11', NULL, NULL),
(1766, 'هانوفر', 'Hanover', 101, 'Hanovre', '02', NULL, NULL),
(1767, 'يستمورلاند', 'Westmoreland', 101, 'Westmoreland', '16', NULL, NULL),
(1768, 'تريلاوني', 'Trelawny', 101, 'Trelawny', '15', NULL, NULL),
(1769, 'مانشستر', 'Manchester', 101, 'Manchester', '04', NULL, NULL),
(1770, 'جيمس قديس', 'Saint James', 101, 'Saint James', '12', NULL, NULL),
(1771, 'القديس أندرو', 'Saint Andrew', 101, 'Saint andrew', '08', NULL, NULL),
(1772, 'سانت توماس', 'Saint Thomas', 101, 'Saint thomas', '14', NULL, NULL),
(1773, 'القديس ماري', 'Saint Mary', 101, 'Sainte Marie', '13', NULL, NULL),
(1774, 'بورتلاند', 'Portland', 101, 'Portland', '07', NULL, NULL),
(1775, 'كلارندون', 'Clarendon', 101, 'Clarendon', '01', NULL, NULL),
(1776, 'سانت كاترين', 'Saint Catherine', 101, 'Sainte catherine', '10', NULL, NULL),
(1777, 'كينغستون', 'Kingston', 101, 'Kingston', '17', NULL, NULL),
(1779, 'في الطفيلة', 'At Tafilah', 102, 'Chez tafilah', '12', NULL, NULL),
(1782, 'الكرك', 'Al Karak', 102, 'Al Karak', '09', NULL, NULL),
(1784, 'البلقاء', 'Al Balqa\'', 102, 'Al Balqa \'', '02', NULL, NULL),
(1786, 'عمان', 'Amman', 102, 'Amman', '16', NULL, NULL),
(1787, 'العقبة', 'Al Aqabah', 102, 'Al Aqabah', '21', NULL, NULL),
(1788, 'أوكيناوا', 'Okinawa', 103, 'Okinawa', '47', NULL, NULL),
(1789, 'ناغازاكي', 'Nagasaki', 103, 'Nagasaki', '27', NULL, NULL),
(1790, 'هوكايدو', 'Hokkaido', 103, 'Hokkaido', '12', NULL, NULL),
(1791, 'توكوشيما', 'Tokushima', 103, 'Tokushima', '39', NULL, NULL),
(1792, 'مي', 'Mie', 103, 'Mie', '23', NULL, NULL),
(1793, 'كاناغاوا', 'Kanagawa', 103, 'Kanagawa', '19', NULL, NULL),
(1794, 'شيبا', 'Chiba', 103, 'Chiba', '04', NULL, NULL),
(1795, 'هيوغو', 'Hyogo', 103, 'Hyogo', '13', NULL, NULL),
(1796, 'ياماغوتشي', 'Yamaguchi', 103, 'Yamaguchi', '45', NULL, NULL),
(1797, 'أوموري', 'Aomori', 103, 'Aomori', '03', NULL, NULL),
(1798, 'ميازاكي', 'Miyazaki', 103, 'Miyazaki', '25', NULL, NULL),
(1799, 'شيزوكا', 'Shizuoka', 103, 'Shizuoka', '37', NULL, NULL),
(1800, 'شيمان', 'Shimane', 103, 'Shimane', '36', NULL, NULL),
(1801, 'فوكوشيما', 'Fukushima', 103, 'Fukushima', '08', NULL, NULL),
(1802, 'أوكاياما', 'Okayama', 103, 'Okayama', '31', NULL, NULL),
(1803, 'شيجا', 'Shiga', 103, 'Shiga', '35', NULL, NULL),
(1804, 'كاجوشيما', 'Kagoshima', 103, 'Kagoshima', '18', NULL, NULL),
(1805, 'هيروشيما', 'Hiroshima', 103, 'Hiroshima', '11', NULL, NULL),
(1806, 'توتوري', 'Tottori', 103, 'Tottori', '41', NULL, NULL),
(1807, 'اكيتا', 'Akita', 103, 'Akita', '02', NULL, NULL),
(1808, 'ناغانو', 'Nagano', 103, 'Nagano', '26', NULL, NULL),
(1809, 'فوكوي', 'Fukui', 103, 'Fukui', '06', NULL, NULL),
(1810, 'سايتاما', 'Saitama', 103, 'Saitama', '34', NULL, NULL),
(1811, 'واكاياما', 'Wakayama', 103, 'Wakayama', '43', NULL, NULL),
(1812, 'كوتشي', 'Kochi', 103, 'Kochi', '20', NULL, NULL),
(1813, 'ايواتي', 'Iwate', 103, 'Iwate', '16', NULL, NULL),
(1814, 'مياجي', 'Miyagi', 103, 'Miyagi', '24', NULL, NULL),
(1815, 'نيجاتا', 'Niigata', 103, 'Niigata', '29', NULL, NULL),
(1816, 'صمغة', 'Gumma', 103, 'Gumma', '10', NULL, NULL),
(1817, 'أيشي', 'Aichi', 103, 'Aichi', '01', NULL, NULL),
(1818, 'توياما', 'Toyama', 103, 'Toyama', '42', NULL, NULL),
(1819, 'كوماموتو', 'Kumamoto', 103, 'Kumamoto', '21', NULL, NULL),
(1820, 'كاغاوا', 'Kagawa', 103, 'Kagawa', '17', NULL, NULL),
(1821, 'ايمى', 'Ehime', 103, 'Ehime', '05', NULL, NULL),
(1822, 'طوكيو', 'Tokyo', 103, 'Tokyo', '40', NULL, NULL),
(1823, 'فوكوكا', 'Fukuoka', 103, 'Fukuoka', '07', NULL, NULL),
(1824, 'توتشيغي', 'Tochigi', 103, 'Tochigi', '38', NULL, NULL),
(1825, 'ياماغاتا', 'Yamagata', 103, 'Yamagata', '44', NULL, NULL),
(1826, 'قصة طويلة', 'Saga', 103, 'Saga', '33', NULL, NULL),
(1827, 'أويتا', 'Oita', 103, 'Oita', '30', NULL, NULL),
(1828, 'جيفو', 'Gifu', 103, 'Gifu', '09', NULL, NULL),
(1829, 'إيشيكاوا', 'Ishikawa', 103, 'Ishikawa', '15', NULL, NULL),
(1830, 'نارا', 'Nara', 103, 'Nara', '28', NULL, NULL),
(1831, 'ايباراكي', 'Ibaraki', 103, 'Ibaraki', '14', NULL, NULL),
(1832, 'كيوتو', 'Kyoto', 103, 'Kyoto', '22', NULL, NULL),
(1833, 'ياماناشي', 'Yamanashi', 103, 'Yamanashi', '46', NULL, NULL),
(1834, 'أوساكا', 'Osaka', 103, 'Osaka', '32', NULL, NULL),
(1835, 'ساحل', 'Coast', 104, 'Côte', '02', NULL, NULL),
(1836, 'نيانزا', 'Nyanza', 104, 'Nyanza', '07', NULL, NULL),
(1837, 'الوادي المتصدع', 'Rift Valley', 104, 'La vallée du Rift', '08', NULL, NULL),
(1838, 'الغربي', 'Western', 104, 'Occidental', '09', NULL, NULL),
(1839, 'شمال شرق', 'North-Eastern', 104, 'Nord-est', '06', NULL, NULL),
(1840, 'الشرقية', 'Eastern', 104, 'Est', '03', NULL, NULL),
(1841, 'منطقة نيروبي', 'Nairobi Area', 104, 'Région de Nairobi', '05', NULL, NULL),
(1842, 'وسط', 'Central', 104, 'Central', '01', NULL, NULL),
(1843, 'جلال آباد', 'Jalal-Abad', 105, 'Jalal-Abad', '03', NULL, NULL),
(1844, 'نارين', 'Naryn', 105, 'Naryn', '04', NULL, NULL),
(1845, 'أوش', 'Osh', 105, 'Osh', '05', NULL, NULL),
(1846, 'تشوي', 'Chuy', 105, 'Chuy', '02', NULL, NULL),
(1847, 'يسيك-كول', 'Ysyk-Kol', 105, 'Ysyk-Kol', '07', NULL, NULL),
(1848, 'بيشكيك', 'Bishkek', 105, 'Bichkek', '01', NULL, NULL),
(1849, 'تالاس', 'Talas', 105, 'Talas', '06', NULL, NULL),
(1850, 'باتكن', 'Batken', 105, 'Batken', '09', NULL, NULL),
(1852, 'سيم ريب', 'Siem Reap', 106, 'Siem Reap', '16', NULL, NULL),
(1853, 'كراتي', 'Kracheh', 106, 'Kracheh', '09', NULL, NULL),
(1854, 'كامبونغ ثوم', 'Kampong Thum', 106, 'Kampong Thum', '05', NULL, NULL),
(1855, 'كامبونج شنانج', 'Kampong Chhnang', 106, 'Kampong Chhnang', '03', NULL, NULL),
(1857, 'كامبونج تشام', 'Kampong Cham', 106, 'Kampong Cham', '02', NULL, NULL),
(1858, 'كامبونج سبيو', 'Kampong Speu', 106, 'Kampong Speu', '04', NULL, NULL),
(1859, 'اتخاذ س', 'Takeo', 106, 'Takeo', '19', NULL, NULL),
(1860, 'باتامبانغ', 'Batdambang', 106, 'Batdambang', '01', NULL, NULL),
(1861, 'بريى فنج', 'Prey Veng', 106, 'Prey Veng', '14', NULL, NULL),
(1862, 'راتاناكيري كيري', 'Ratanakiri Kiri', 106, 'Ratanakiri Kiri', '15', NULL, NULL),
(1863, 'سفاي رينج', 'Svay Rieng', 106, 'Svay Rieng', '18', NULL, NULL),
(1864, 'كوه كونغ', 'Koh Kong', 106, 'Koh Kong', '08', NULL, NULL),
(1865, 'بورسات', 'Pursat', 106, 'Pursat', '12', NULL, NULL),
(1866, 'بنوم بنه', 'Phnum Penh', 106, 'Phnum Penh', '11', NULL, NULL),
(1867, 'موندولكيري', 'Mondulkiri', 106, 'Mondulkiri', '10', NULL, NULL),
(1868, 'ستونغ ترينغ', 'Stung Treng', 106, 'Stung Treng', '17', NULL, NULL),
(1869, 'كامبوت', 'Kampot', 106, 'Kampot', '06', NULL, NULL),
(1870, 'بانتي ميانشي', 'Banteay Meanchey', 106, 'Banteay Meanchey', '25', NULL, NULL),
(1871, 'برياه فيهيار', 'Preah Vihear', 106, 'Preah Vihear', '13', NULL, NULL),
(1872, 'كاندال', 'Kandal', 106, 'Kandal', '07', NULL, NULL),
(1874, 'أنجوان', 'Anjouan', 108, 'Anjouan', '01', NULL, NULL),
(1875, 'موهيلي', 'Moheli', 108, 'Moheli', '03', NULL, NULL),
(1876, 'القمر الكبرى', 'Grande Comore', 108, 'Grande Comore', '02', NULL, NULL),
(1877, 'سانت جورج جينجيرلاند', 'Saint George Gingerland', 109, 'Saint George Gingerland', '04', NULL, NULL),
(1878, 'سانت جيمس ويندوارد', 'Saint James Windward', 109, 'Saint James Windward', '05', NULL, NULL),
(1879, 'سانت توماس لوولاند', 'Saint Thomas Lowland', 109, 'Saint Thomas Lowland', '12', NULL, NULL),
(1880, 'سانت جورج باسيتير', 'Saint George Basseterre', 109, 'Saint George Basseterre', '03', NULL, NULL),
(1881, 'القديس يوحنا فيجترى', 'Saint John Figtree', 109, 'Saint John Figtree', '07', NULL, NULL),
(1882, 'القديس بطرس باستير', 'Saint Peter Basseterre', 109, 'Saint Peter Basseterre', '11', NULL, NULL),
(1883, 'القديس يوحنا كابيستر', 'Saint John Capisterre', 109, 'Saint Jean Capisterre', '06', NULL, NULL),
(1884, 'كنيسة المسيح نيقولا تاون', 'Christ Church Nichola Town', 109, 'Christ Church Nichola Town', '01', NULL, NULL),
(1885, 'الثالوث بالميتو بوينت', 'Trinity Palmetto Point', 109, 'Trinity Palmetto Point', '15', NULL, NULL),
(1886, 'سانت آن ساندي بوينت', 'Saint Anne Sandy Point', 109, 'Sainte Anne Sandy Point', '02', NULL, NULL),
(1887, 'سانت ماري كايون', 'Saint Mary Cayon', 109, 'Saint Mary Cayon', '08', NULL, NULL),
(1888, 'جزيرة سانت توماس الوسطى', 'Saint Thomas Middle Island', 109, 'Saint Thomas Middle Island', '13', NULL, NULL),
(1889, 'سانت بول كابيستر', 'Saint Paul Capisterre', 109, 'Saint Paul Capisterre', '09', NULL, NULL),
(1890, 'P\'yongan-نامدو', 'P\'yongan-namdo', 110, 'P\'yongan-namdo', '15', NULL, NULL),
(1891, 'P\'yongan-bukto', 'P\'yongan-bukto', 110, 'P\'yongan-bukto', '11', NULL, NULL),
(1892, 'P\'yongyang-سي', 'P\'yongyang-si', 110, 'P\'yongyang-si', '12', NULL, NULL),
(1893, 'كانج وون دو', 'Kangwon-do', 110, 'Kangwon-do', '09', NULL, NULL),
(1894, 'هوانغهاي-bukto', 'Hwanghae-bukto', 110, 'Hwanghae-bukto', '07', NULL, NULL),
(1895, 'هامكيونغ-نامدو', 'Hamgyong-namdo', 110, 'Hamgyong-namdo', '03', NULL, NULL),
(1896, 'تشاغانغ دو', 'Chagang-do', 110, 'Chagang-do', '01', NULL, NULL),
(1897, 'هامكيونغ-bukto', 'Hamgyong-bukto', 110, 'Hamgyong-bukto', '17', NULL, NULL),
(1898, 'هوانغهاي-نامدو', 'Hwanghae-namdo', 110, 'Hwanghae-namdo', '06', NULL, NULL),
(1899, 'Namp\'o-سي', 'Namp\'o-si', 110, 'Namp\'o-si', '14', NULL, NULL),
(1900, 'كايسونج، الاشتراكية', 'Kaesong-si', 110, 'Kaesong-si', '08', NULL, NULL),
(1901, 'يانجانج دو', 'Yanggang-do', 110, 'Yanggang-do', '13', NULL, NULL),
(1902, 'ناجين سونبونج سي', 'Najin Sonbong-si', 110, 'Najin Sonbong-si', '18', NULL, NULL),
(1903, 'Ch\'ungch\'ong-bukto', 'Ch\'ungch\'ong-bukto', 111, 'Ch\'ungch\'ong-bukto', '05', NULL, NULL),
(1904, 'كانج وون دو', 'Kangwon-do', 111, 'Kangwon-do', '06', NULL, NULL),
(1905, 'Ch\'ungch\'ong-نامدو', 'Ch\'ungch\'ong-namdo', 111, 'Ch\'ungch\'ong-namdo', '17', NULL, NULL),
(1906, 'كيونجسانج-bukto', 'Kyongsang-bukto', 111, 'Kyongsang-bukto', '14', NULL, NULL),
(1907, 'تشولا-نامدو', 'Cholla-namdo', 111, 'Cholla-namdo', '16', NULL, NULL),
(1908, 'كيونجي دو', 'Kyonggi-do', 111, 'Kyonggi-do', '13', NULL, NULL),
(1909, 'تشيجو دو', 'Cheju-do', 111, 'Cheju-do', '01', NULL, NULL),
(1910, 'تشولا-bukto', 'Cholla-bukto', 111, 'Cholla-bukto', '03', NULL, NULL),
(1911, 'سول-t\'ukpyolsi', 'Seoul-t\'ukpyolsi', 111, 'Séoul-t\'ukpyolsi', '11', NULL, NULL),
(1912, 'كيونجسانج-نامدو', 'Kyongsang-namdo', 111, 'Kyongsang-namdo', '20', NULL, NULL),
(1913, 'تايجو-jikhalsi', 'Taegu-jikhalsi', 111, 'Taegu-Jikhalsi', '15', NULL, NULL),
(1914, 'بوسان-jikhalsi', 'Pusan-jikhalsi', 111, 'Pusan-Jikhalsi', '10', NULL, NULL),
(1915, 'كوانجو-jikhalsi', 'Kwangju-jikhalsi', 111, 'Kwangju-jikhalsi', '18', NULL, NULL),
(1916, 'أولسان-gwangyoksi', 'Ulsan-gwangyoksi', 111, 'Ulsan-Gwangyoksi', '21', NULL, NULL),
(1917, 'إنشون-jikhalsi', 'Inch\'on-jikhalsi', 111, 'Inch\'on-jikhalsi', '12', NULL, NULL),
(1918, 'تايجون-jikhalsi', 'Taejon-jikhalsi', 111, 'Taejon-jikhalsi', '19', NULL, NULL),
(1919, 'الكوييت', 'Al Kuwayt', 112, 'Al Kuwayt', '02', NULL, NULL),
(1920, 'الجهراء', 'Al Jahra', 112, 'Al Jahra', '05', NULL, NULL),
(1923, 'ألماتي', 'Almaty', 114, 'Almaty', '01', NULL, NULL),
(1924, 'جنوب كازاخستان', 'South Kazakhstan', 114, 'Kazakhstan du sud', '10', NULL, NULL),
(1925, 'شمال كازاخستان', 'North Kazakhstan', 114, 'Kazakhstan du Nord', '16', NULL, NULL),
(1926, 'بافلودار', 'Pavlodar', 114, 'Pavlodar', '11', NULL, NULL),
(1927, 'كاراجهاندي', 'Qaraghandy', 114, 'Qaraghandy', '12', NULL, NULL),
(1928, 'كيزيلورودا', 'Qyzylorda', 114, 'Qyzylorda', '14', NULL, NULL),
(1929, 'شرق كازاخستان', 'East Kazakhstan', 114, 'Kazakhstan oriental', '15', NULL, NULL),
(1930, 'أكمولا', 'Aqmola', 114, 'Aqmola', '03', NULL, NULL),
(1931, 'أكتوب', 'Aqtobe', 114, 'Aqtobe', '04', NULL, NULL),
(1932, 'كوستاناي', 'Qostanay', 114, 'Qostanay', '13', NULL, NULL),
(1933, 'غرب كازاخستان', 'West Kazakhstan', 114, 'Kazakhstan occidental', '07', NULL, NULL),
(1934, 'أتيراو', 'Atyrau', 114, 'Atyrau', '06', NULL, NULL),
(1935, 'Zhambyl', 'Zhambyl', 114, 'Zhambyl', '17', NULL, NULL),
(1936, 'أستانا', 'Astana', 114, 'Astana', '05', NULL, NULL),
(1937, 'مانجهيستاو', 'Mangghystau', 114, 'Mangghystau', '09', NULL, NULL),
(1938, 'مدينة ألماتي', 'Almaty City', 114, 'Almaty City', '02', NULL, NULL),
(1939, 'Bayqonyr', 'Bayqonyr', 114, 'Bayqonyr', '08', NULL, NULL),
(1941, 'سافاناخيت', 'Savannakhet', 115, 'Savannakhet', '10', NULL, NULL),
(1942, 'فونغسالي', 'Phongsali', 115, 'Phongsali', '08', NULL, NULL),
(1943, 'سروان', 'Saravan', 115, 'Saravan', '09', NULL, NULL),
(1946, 'هوافان', 'Houaphan', 115, 'Houaphan', '03', NULL, NULL),
(1947, 'أتابو', 'Attapu', 115, 'Attapu', '01', NULL, NULL),
(1949, 'تشامباساك', 'Champasak', 115, 'Champasak', '02', NULL, NULL),
(1950, 'وانجفرابانج', 'Louangphrabang', 115, 'Louangphrabang', '17', NULL, NULL),
(1951, 'أودومكساي', 'Oudomxai', 115, 'Oudomxai', '07', NULL, NULL),
(1955, 'زيانجكوانج', 'Xiangkhoang', 115, 'Xiangkhoang', '14', NULL, NULL),
(1956, 'فينتيان', 'Vientiane', 115, 'Vientiane', '11', NULL, NULL),
(1960, 'Xaignabouri', 'Xaignabouri', 115, 'Xaignabouri', '13', NULL, NULL),
(1961, 'خاموان', 'Khammouan', 115, 'Khammouan', '04', NULL, NULL),
(1966, 'شمال لبنان', 'Liban-Nord', 116, 'Liban-Nord', '03', NULL, NULL),
(1967, 'الجنوب', 'Al Janub', 116, 'Al Janub', '02', NULL, NULL),
(1968, 'بيروت', 'Beyrouth', 116, 'Beyrouth', '04', NULL, NULL),
(1969, 'جبل لبنان', 'Mont-Liban', 116, 'Mont-Liban', '05', NULL, NULL),
(1970, 'البقاع', 'Beqaa', 116, 'Beqaa', '01', NULL, NULL),
(1971, 'لبنان-سود', 'Liban-Sud', 116, 'Liban-Sud', '06', NULL, NULL),
(1972, 'ميكو', 'Micoud', 117, 'Micoud', '08', NULL, NULL),
(1973, 'لابوري', 'Laborie', 117, 'Laborie', '07', NULL, NULL),
(1974, 'دينيري', 'Dennery', 117, 'Dennery', '05', NULL, NULL),
(1975, 'آنس-لا-راي', 'Anse-la-Raye', 117, 'Anse-la-Raye', '01', NULL, NULL),
(1976, 'فيو فورت', 'Vieux-Fort', 117, 'Vieux-Fort', '10', NULL, NULL),
(1977, 'كاستري', 'Castries', 117, 'Castries', '03', NULL, NULL),
(1978, 'سوفرير', 'Soufriere', 117, 'Soufrière', '09', NULL, NULL),
(1979, 'جروس-جزيرة', 'Gros-Islet', 117, 'Gros-Islet', '06', NULL, NULL),
(1980, 'تشويسيول', 'Choiseul', 117, 'Choiseul', '04', NULL, NULL),
(1981, 'الدوفين الابن البكر لملك فرنسي', 'Dauphin', 117, 'Dauphin', '02', NULL, NULL),
(1982, 'براسلين', 'Praslin', 117, 'Praslin', '11', NULL, NULL),
(1983, 'بلزرس', 'Balzers', 118, 'Balzers', '01', NULL, NULL),
(1984, 'جمبرين', 'Gamprin', 118, 'Gamprin', '03', NULL, NULL),
(1985, 'بلانكن', 'Planken', 118, 'Planken', '05', NULL, NULL),
(1986, 'فادوز', 'Vaduz', 118, 'Vaduz', '11', NULL, NULL),
(1987, 'اشن', 'Eschen', 118, 'Eschen', '02', NULL, NULL),
(1988, 'تريسنبرغ', 'Triesenberg', 118, 'Triesenberg', '10', NULL, NULL),
(1989, 'شلينبرغ', 'Schellenberg', 118, 'Schellenberg', '08', NULL, NULL),
(1990, 'مورن', 'Mauren', 118, 'Mauren', '04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `city_shipping_zone`
--

CREATE TABLE `city_shipping_zone` (
  `id` int(10) UNSIGNED NOT NULL,
  `city_id` int(10) UNSIGNED NOT NULL,
  `zone_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `city_shipping_zone`
--

INSERT INTO `city_shipping_zone` (`id`, `city_id`, `zone_id`, `created_at`, `updated_at`) VALUES
(4, 1, 13, '2019-04-25 08:43:16', '2019-04-25 08:43:16'),
(5, 2, 13, '2019-04-25 08:43:16', '2019-04-25 08:43:16'),
(6, 3, 13, '2019-04-25 08:43:16', '2019-04-25 08:43:16'),
(7, 9, 14, NULL, NULL),
(8, 10, 14, NULL, NULL),
(9, 247, 14, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `rate` int(11) NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `massege` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `fname`, `lname`, `email`, `title`, `massege`, `created_at`, `updated_at`) VALUES
(1, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:55:17', '2019-05-14 06:55:17'),
(2, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:55:49', '2019-05-14 06:55:49'),
(3, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:56:37', '2019-05-14 06:56:37'),
(4, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:58:19', '2019-05-14 06:58:19'),
(5, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:59:14', '2019-05-14 06:59:14'),
(6, 'elsam', 'mohamed', 'sa465827@gmail.com', 'yyyy', 'thi is massege', '2019-05-14 06:59:31', '2019-05-14 06:59:31');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `name_fr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name_ar`, `name_en`, `created_at`, `name_fr`, `code`, `updated_at`) VALUES
(1, 'أندورا', 'Andorra', NULL, 'Andorre', 'ad', '2019-04-24 09:41:57'),
(2, 'الإمارات العربية المتحدة', 'United Arab Emirates', NULL, 'Emirats Arabes Unis', 'ae', NULL),
(3, 'أفغانستان', 'Afghanistan', NULL, 'L\'Afghanistan', 'af', NULL),
(4, 'أنتيغوا وبربودا', 'Antigua and Barbuda', NULL, 'Antigua-et-Barbuda', 'ag', NULL),
(5, 'أنغيلا', 'Anguilla', NULL, 'Anguilla', 'ai', NULL),
(6, 'ألبانيا', 'Albania', NULL, 'Albanie', 'al', NULL),
(7, 'أرمينيا', 'Armenia', NULL, 'Arménie', 'am', NULL),
(8, 'جزر الأنتيل الهولندية', 'Netherlands Antilles', NULL, 'Antilles néerlandaises', 'an', NULL),
(9, 'أنغولا', 'Angola', NULL, 'Angola', 'ao', NULL),
(10, 'الأرجنتين', 'Argentina', NULL, 'Argentine', 'ar', NULL),
(11, 'النمسا', 'Austria', NULL, 'L\'Autriche', 'at', NULL),
(12, 'أستراليا', 'Australia', NULL, 'Australie', 'au', NULL),
(13, 'أروبا', 'Aruba', NULL, 'Aruba', 'aw', NULL),
(14, 'أذربيجان', 'Azerbaijan', NULL, 'Azerbaïdjan', 'az', NULL),
(15, 'البوسنة والهرسك', 'Bosnia and Herzegovina', NULL, 'Bosnie Herzégovine', 'ba', NULL),
(16, 'بربادوس', 'Barbados', NULL, 'La Barbade', 'bb', NULL),
(17, 'بنغلاديش', 'Bangladesh', NULL, 'Bangladesh', 'bd', NULL),
(18, 'بلجيكا', 'Belgium', NULL, 'Belgique', 'be', NULL),
(19, 'بوركينا فاسو', 'Burkina Faso', NULL, 'Burkina Faso', 'bf', NULL),
(20, 'بلغاريا', 'Bulgaria', NULL, 'Bulgarie', 'bg', NULL),
(21, 'البحرين', 'Bahrain', NULL, 'Bahreïn', 'bh', NULL),
(22, 'بوروندي', 'Burundi', NULL, 'Burundi', 'bi', NULL),
(23, 'بنين', 'Benin', NULL, 'Bénin', 'bj', NULL),
(24, 'برمودا', 'Bermuda', NULL, 'Bermudes', 'bm', NULL),
(25, 'بروناي دار السلام', 'Brunei Darussalam', NULL, 'Brunei Darussalam', 'bn', NULL),
(26, 'بوليفيا', 'Bolivia', NULL, 'Bolivie', 'bo', NULL),
(27, 'البرازيل', 'Brazil', NULL, 'Brésil', 'br', NULL),
(28, 'الباهاما', 'Bahamas', NULL, 'Bahamas', 'bs', NULL),
(29, 'بوتان', 'Bhutan', NULL, 'Bhoutan', 'bt', NULL),
(30, 'بوتسوانا', 'Botswana', NULL, 'Botswana', 'bw', NULL),
(31, 'روسيا البيضاء', 'Belarus', NULL, 'Biélorussie', 'by', NULL),
(32, 'بليز', 'Belize', NULL, 'Belize', 'bz', NULL),
(33, 'كندا', 'Canada', NULL, 'Canada', 'ca', NULL),
(34, 'جزر كوكوس (كيلينغ)', 'Cocos (Keeling) Islands', NULL, 'Îles Cocos (Keeling)', 'cc', NULL),
(35, 'جمهورية الكونغو الديموقراطية', 'Democratic Republic of the Congo', NULL, 'République Démocratique du Congo', 'cd', NULL),
(36, 'جمهورية افريقيا الوسطى', 'Central African Republic', NULL, 'République centrafricaine', 'cf', NULL),
(37, 'الكونغو', 'Congo', NULL, 'Congo', 'cg', NULL),
(38, 'سويسرا', 'Switzerland', NULL, 'Suisse', 'ch', NULL),
(39, 'ساحل العاج (ساحل العاج)', 'Cote D\'Ivoire (Ivory Coast)', NULL, 'Cote D\'Ivoire (Côte d\'Ivoire)', 'ci', NULL),
(40, 'جزر كوك', 'Cook Islands', NULL, 'les Îles Cook', 'ck', NULL),
(41, 'تشيلي', 'Chile', NULL, 'Chili', 'cl', NULL),
(42, 'الكاميرون', 'Cameroon', NULL, 'Cameroun', 'cm', NULL),
(43, 'الصين', 'China', NULL, 'Chine', 'cn', NULL),
(44, 'كولومبيا', 'Colombia', NULL, 'Colombie', 'co', NULL),
(45, 'كوستا ريكا', 'Costa Rica', NULL, 'Costa Rica', 'cr', NULL),
(46, 'كوبا', 'Cuba', NULL, 'Cuba', 'cu', NULL),
(47, 'الرأس الأخضر', 'Cape Verde', NULL, 'Cap-Vert', 'cv', NULL),
(48, 'جزيرة الكريسماس', 'Christmas Island', NULL, 'L\'île de noël', 'cx', NULL),
(49, 'قبرص', 'Cyprus', NULL, 'Chypre', 'cy', NULL),
(50, 'جمهورية التشيك', 'Czech Republic', NULL, 'République Tchèque', 'cz', NULL),
(51, 'ألمانيا', 'Germany', NULL, 'Allemagne', 'de', NULL),
(52, 'جيبوتي', 'Djibouti', NULL, 'Djibouti', 'dj', NULL),
(53, 'الدنمارك', 'Denmark', NULL, 'Danemark', 'dk', NULL),
(54, 'دومينيكا', 'Dominica', NULL, 'Dominique', 'dm', NULL),
(55, 'جمهورية الدومنيكان', 'Dominican Republic', NULL, 'République Dominicaine', 'do', NULL),
(56, 'الجزائر', 'Algeria', NULL, 'Algérie', 'dz', NULL),
(57, 'الإكوادور', 'Ecuador', NULL, 'L\'Équateur', 'ec', NULL),
(58, 'استونيا', 'Estonia', NULL, 'Estonie', 'ee', NULL),
(59, 'مصر', 'Egypt', NULL, 'Egypte', 'eg', NULL),
(60, 'الصحراء الغربية', 'Western Sahara', NULL, 'Sahara occidental', 'eh', NULL),
(61, 'إريتريا', 'Eritrea', NULL, 'Erythrée', 'er', NULL),
(62, 'إسبانيا', 'Spain', NULL, 'Espagne', 'es', NULL),
(63, 'أثيوبيا', 'Ethiopia', NULL, 'Ethiopie', 'et', NULL),
(64, 'فنلندا', 'Finland', NULL, 'Finlande', 'fi', NULL),
(65, 'فيجي', 'Fiji', NULL, 'Fidji', 'fj', NULL),
(66, 'جزر فوكلاند (مالفيناس)', 'Falkland Islands (Malvinas)', NULL, 'Iles Malouines (Malouines)', 'fk', NULL),
(67, 'ولايات ميكرونيزيا الموحدة', 'Federated States of Micronesia', NULL, 'États fédérés de Micronésie', 'fm', NULL),
(68, 'جزر صناعية', 'Faroe Islands', NULL, 'Îles Féroé', 'fo', NULL),
(69, 'فرنسا', 'France', NULL, 'France', 'fr', NULL),
(70, 'الغابون', 'Gabon', NULL, 'Gabon', 'ga', NULL),
(71, 'بريطانيا العظمى (المملكة المتحدة)', 'Great Britain (UK)', NULL, 'Grande-Bretagne (UK)', 'gb', NULL),
(72, 'غرينادا', 'Grenada', NULL, 'Grenade', 'gd', NULL),
(73, 'جورجيا', 'Georgia', NULL, 'Géorgie', 'ge', NULL),
(74, 'غيانا الفرنسية', 'French Guiana', NULL, 'Guinée Française', 'gf', NULL),
(75, 'لا شيء', 'NULL', NULL, 'NUL', 'gg', NULL),
(76, 'غانا', 'Ghana', NULL, 'Ghana', 'gh', NULL),
(77, 'جبل طارق', 'Gibraltar', NULL, 'Gibraltar', 'gi', NULL),
(78, 'الأرض الخضراء', 'Greenland', NULL, 'Groenland', 'gl', NULL),
(79, 'غامبيا', 'Gambia', NULL, 'Gambie', 'gm', NULL),
(80, 'غينيا', 'Guinea', NULL, 'Guinée', 'gn', NULL),
(81, 'جوادلوب', 'Guadeloupe', NULL, 'La guadeloupe', 'gp', NULL),
(82, 'غينيا الإستوائية', 'Equatorial Guinea', NULL, 'Guinée Équatoriale', 'gq', NULL),
(83, 'اليونان', 'Greece', NULL, 'Grèce', 'gr', NULL),
(84, 'جورجيا وجزر ساندويتش', 'S. Georgia and S. Sandwich Islands', NULL, 'Géorgie du Sud et les îles Sandwich du Sud', 'gs', NULL),
(85, 'غواتيمالا', 'Guatemala', NULL, 'Guatemala', 'gt', NULL),
(86, 'غينيا بيساو', 'Guinea-Bissau', NULL, 'Guinée-Bissau', 'gw', NULL),
(87, 'غيانا', 'Guyana', NULL, 'Guyane', 'gy', NULL),
(88, 'هونغ كونغ', 'Hong Kong', NULL, 'Hong Kong', 'hk', NULL),
(89, 'هندوراس', 'Honduras', NULL, 'Honduras', 'hn', NULL),
(90, 'كرواتيا (هرفاتسكا)', 'Croatia (Hrvatska)', NULL, 'Croatie (Hrvatska)', 'hr', NULL),
(91, 'هايتي', 'Haiti', NULL, 'Haïti', 'ht', NULL),
(92, 'اليونان', 'Hungary', NULL, 'Hongrie', 'hu', NULL),
(93, 'أندونيسيا', 'Indonesia', NULL, 'Indonésie', 'id', NULL),
(94, 'أيرلندا', 'Ireland', NULL, 'Irlande', 'ie', NULL),
(96, 'الهند', 'India', NULL, 'Inde', 'in', NULL),
(97, 'العراق', 'Iraq', NULL, 'Irak', 'iq', NULL),
(98, 'إيران', 'Iran', NULL, 'Iran', 'ir', NULL),
(99, 'أيسلندا', 'Iceland', NULL, 'Islande', 'is', NULL),
(100, 'إيطاليا', 'Italy', NULL, 'Italie', 'it', NULL),
(101, 'جامايكا', 'Jamaica', NULL, 'Jamaïque', 'jm', NULL),
(102, 'الأردن', 'Jordan', NULL, 'Jordan', 'jo', NULL),
(103, 'اليابان', 'Japan', NULL, 'Japon', 'jp', NULL),
(104, 'كينيا', 'Kenya', NULL, 'Kenya', 'ke', NULL),
(105, 'قرغيزستان', 'Kyrgyzstan', NULL, 'Kirghizistan', 'kg', NULL),
(106, 'كمبوديا', 'Cambodia', NULL, 'Cambodge', 'kh', NULL),
(107, 'كيريباس', 'Kiribati', NULL, 'Kiribati', 'ki', NULL),
(108, 'جزر القمر', 'Comoros', NULL, 'Comores', 'km', NULL),
(109, 'سانت كيتس ونيفيس', 'Saint Kitts and Nevis', NULL, 'Saint-Christophe-et-Niévès', 'kn', NULL),
(110, 'كوريا الشمالية', 'Korea (North)', NULL, 'Corée du Nord', 'kp', NULL),
(111, 'كوريا، جنوب)', 'Korea (South)', NULL, 'COREE DU SUD)', 'kr', NULL),
(112, 'الكويت', 'Kuwait', NULL, 'Koweit', 'kw', NULL),
(113, 'جزر كايمان', 'Cayman Islands', NULL, 'Îles Caïmans', 'ky', NULL),
(114, 'كازاخستان', 'Kazakhstan', NULL, 'Le kazakhstan', 'kz', NULL),
(115, 'لاوس', 'Laos', NULL, 'Laos', 'la', NULL),
(116, 'لبنان', 'Lebanon', NULL, 'Liban', 'lb', NULL),
(117, 'القديسة لوسيا', 'Saint Lucia', NULL, 'Sainte-Lucie', 'lc', NULL),
(118, 'ليختنشتاين', 'Liechtenstein', NULL, 'Le Liechtenstein', 'li', NULL),
(119, 'سيريلانكا', 'Sri Lanka', NULL, 'Sri Lanka', 'lk', NULL),
(120, 'ليبيريا', 'Liberia', NULL, 'Libéria', 'lr', NULL),
(121, 'ليسوتو', 'Lesotho', NULL, 'Lesotho', 'ls', NULL),
(122, 'ليتوانيا', 'Lithuania', NULL, 'Lituanie', 'lt', NULL),
(123, 'لوكسمبورغ', 'Luxembourg', NULL, 'Luxembourg', 'lu', NULL),
(124, 'لاتفيا', 'Latvia', NULL, 'Lettonie', 'lv', NULL),
(125, 'ليبيا', 'Libya', NULL, 'Libye', 'ly', NULL),
(126, 'المغرب', 'Morocco', NULL, 'Maroc', 'ma', NULL),
(127, 'موناكو', 'Monaco', NULL, 'Monaco', 'mc', NULL),
(128, 'مولدوفا', 'Moldova', NULL, 'La Moldavie', 'md', NULL),
(129, 'مدغشقر', 'Madagascar', NULL, 'Madagascar', 'mg', NULL),
(130, 'جزر مارشال', 'Marshall Islands', NULL, 'Iles Marshall', 'mh', NULL),
(131, 'مقدونيا', 'Macedonia', NULL, 'Macédoine', 'mk', NULL),
(132, 'مالي', 'Mali', NULL, 'Mali', 'ml', NULL),
(133, 'ميانمار', 'Myanmar', NULL, 'Myanmar', 'mm', NULL),
(134, 'منغوليا', 'Mongolia', NULL, 'Mongolie', 'mn', NULL),
(135, 'ماكاو', 'Macao', NULL, 'Macao', 'mo', NULL),
(136, 'جزر مريانا الشمالية', 'Northern Mariana Islands', NULL, 'Îles Mariannes du Nord', 'mp', NULL),
(137, 'مارتينيك', 'Martinique', NULL, 'Martinique', 'mq', NULL),
(138, 'موريتانيا', 'Mauritania', NULL, 'Mauritanie', 'mr', NULL),
(139, 'مونتسيرات', 'Montserrat', NULL, 'Montserrat', 'ms', NULL),
(140, 'مالطا', 'Malta', NULL, 'Malte', 'mt', NULL),
(141, 'موريشيوس', 'Mauritius', NULL, 'Maurice', 'mu', NULL),
(142, 'جزر المالديف', 'Maldives', NULL, 'Maldives', 'mv', NULL),
(143, 'مالاوي', 'Malawi', NULL, 'Malawi', 'mw', NULL),
(144, 'المكسيك', 'Mexico', NULL, 'Mexique', 'mx', NULL),
(145, 'ماليزيا', 'Malaysia', NULL, 'Malaisie', 'my', NULL),
(146, 'موزمبيق', 'Mozambique', NULL, 'Mozambique', 'mz', NULL),
(147, 'ناميبيا', 'Namibia', NULL, 'Namibie', 'na', NULL),
(148, 'كاليدونيا الجديدة', 'New Caledonia', NULL, 'Nouvelle Calédonie', 'nc', NULL),
(149, 'النيجر', 'Niger', NULL, 'Niger', 'ne', NULL),
(150, 'جزيرة نورفولك', 'Norfolk Island', NULL, 'l\'ile de Norfolk', 'nf', NULL),
(151, 'نيجيريا', 'Nigeria', NULL, 'Nigeria', 'ng', NULL),
(152, 'نيكاراغوا', 'Nicaragua', NULL, 'Nicaragua', 'ni', NULL),
(153, 'هولندا', 'Netherlands', NULL, 'Pays-Bas', 'nl', NULL),
(154, 'النرويج', 'Norway', NULL, 'Norvège', 'no', NULL),
(155, 'نيبال', 'Nepal', NULL, 'Népal', 'np', NULL),
(156, 'ناورو', 'Nauru', NULL, 'Nauru', 'nr', NULL),
(157, 'نيوي', 'Niue', NULL, 'Niue', 'nu', NULL),
(158, 'نيوزيلندا (اوتياروا)', 'New Zealand (Aotearoa)', NULL, 'Nouvelle-Zélande (Aotearoa)', 'nz', NULL),
(159, 'سلطنة عمان', 'Oman', NULL, 'Oman', 'om', NULL),
(160, 'بناما', 'Panama', NULL, 'Panama', 'pa', NULL),
(161, 'بيرو', 'Peru', NULL, 'Pérou', 'pe', NULL),
(162, 'بولينيزيا الفرنسية', 'French Polynesia', NULL, 'Polynésie française', 'pf', NULL),
(163, 'بابوا غينيا الجديدة', 'Papua New Guinea', NULL, 'Papouasie Nouvelle Guinée', 'pg', NULL),
(164, 'الفلبين', 'Philippines', NULL, 'Philippines', 'ph', NULL),
(165, 'باكستان', 'Pakistan', NULL, 'Pakistan', 'pk', NULL),
(166, 'بولندا', 'Poland', NULL, 'Pologne', 'pl', NULL),
(167, 'سانت بيير وميكلون', 'Saint Pierre and Miquelon', NULL, 'Saint Pierre et Miquelon', 'pm', NULL),
(168, 'بيتكيرن', 'Pitcairn', NULL, 'Pitcairn', 'pn', NULL),
(169, 'الأراضي الفلسطينية', 'Palestinian Territory', NULL, 'Territoire Palestinien', 'ps', NULL),
(170, 'البرتغال', 'Portugal', NULL, 'le Portugal', 'pt', NULL),
(171, 'بالاو', 'Palau', NULL, 'Palau', 'pw', NULL),
(172, 'باراغواي', 'Paraguay', NULL, 'Paraguay', 'py', NULL),
(173, 'دولة قطر', 'Qatar', NULL, 'Qatar', 'qa', NULL),
(174, 'جمع شمل', 'Reunion', NULL, 'Réunion', 're', NULL),
(175, 'رومانيا', 'Romania', NULL, 'Roumanie', 'ro', NULL),
(176, 'الاتحاد الروسي', 'Russian Federation', NULL, 'Fédération Russe', 'ru', NULL),
(177, 'رواندا', 'Rwanda', NULL, 'Rwanda', 'rw', NULL),
(178, 'المملكة العربية السعودية', 'Saudi Arabia', NULL, 'Arabie Saoudite', 'sa', NULL),
(179, 'جزر سليمان', 'Solomon Islands', NULL, 'Les îles Salomon', 'sb', NULL),
(180, 'سيشيل', 'Seychelles', NULL, 'les Seychelles', 'sc', NULL),
(181, 'سودان', 'Sudan', NULL, 'Soudan', 'sd', NULL),
(182, 'السويد', 'Sweden', NULL, 'Suède', 'se', NULL),
(183, 'سنغافورة', 'Singapore', NULL, 'Singapour', 'sg', NULL),
(184, 'سانت هيلانة', 'Saint Helena', NULL, 'Sainte Hélène', 'sh', NULL),
(185, 'سلوفينيا', 'Slovenia', NULL, 'La slovénie', 'si', NULL),
(186, 'سفالبارد وجان مايان', 'Svalbard and Jan Mayen', NULL, 'Svalbard et Jan Mayen', 'sj', NULL),
(187, 'سلوفاكيا', 'Slovakia', NULL, 'La slovaquie', 'sk', NULL),
(188, 'سيرا ليون', 'Sierra Leone', NULL, 'Sierra Leone', 'sl', NULL),
(189, 'سان مارينو', 'San Marino', NULL, 'Saint Marin', 'sm', NULL),
(190, 'السنغال', 'Senegal', NULL, 'Sénégal', 'sn', NULL),
(191, 'الصومال', 'Somalia', NULL, 'Somalie', 'so', NULL),
(192, 'سورينام', 'Suriname', NULL, 'Suriname', 'sr', NULL),
(193, 'ساو تومي وبرنسيبي', 'Sao Tome and Principe', NULL, 'Sao Tomé et Principe', 'st', NULL),
(194, 'السلفادور', 'El Salvador', NULL, 'Le Salvador', 'sv', NULL),
(195, 'سوريا', 'Syria', NULL, 'Syrie', 'sy', NULL),
(196, 'سوازيلاند', 'Swaziland', NULL, 'Swaziland', 'sz', NULL),
(197, 'جزر تركس وكايكوس', 'Turks and Caicos Islands', NULL, 'îles Turques-et-Caïques', 'tc', NULL),
(198, 'تشاد', 'Chad', NULL, 'Le tchad', 'td', NULL),
(199, 'المناطق الجنوبية لفرنسا', 'French Southern Territories', NULL, 'Terres australes françaises', 'tf', NULL),
(200, 'ليذهب', 'Togo', NULL, 'Aller', 'tg', NULL),
(201, 'تايلاند', 'Thailand', NULL, 'Thaïlande', 'th', NULL),
(202, 'طاجيكستان', 'Tajikistan', NULL, 'Tadjikistan', 'tj', NULL),
(203, 'توكيلاو', 'Tokelau', NULL, 'Tokelau', 'tk', NULL),
(204, 'تركمانستان', 'Turkmenistan', NULL, 'Turkménistan', 'tm', NULL),
(205, 'تونس', 'Tunisia', NULL, 'Tunisie', 'tn', NULL),
(206, 'تونغا', 'Tonga', NULL, 'Tonga', 'to', NULL),
(207, 'ديك رومي', 'Turkey', NULL, 'dinde', 'tr', NULL),
(208, 'ترينداد وتوباغو', 'Trinidad and Tobago', NULL, 'Trinité-et-Tobago', 'tt', NULL),
(209, 'توفالو', 'Tuvalu', NULL, 'Tuvalu', 'tv', NULL),
(210, 'تايوان', 'Taiwan', NULL, 'Taïwan', 'tw', NULL),
(211, 'تنزانيا', 'Tanzania', NULL, 'Tanzanie', 'tz', NULL),
(212, 'أوكرانيا', 'Ukraine', NULL, 'Ukraine', 'ua', NULL),
(213, 'أوغندا', 'Uganda', NULL, 'Ouganda', 'ug', NULL),
(214, 'أوروغواي', 'Uruguay', NULL, 'Uruguay', 'uy', NULL),
(215, 'أوزبكستان', 'Uzbekistan', NULL, 'Ouzbékistan', 'uz', NULL),
(216, 'سانت فنسنت وجزر غرينادين', 'Saint Vincent and the Grenadines', NULL, 'Saint-Vincent-et-les-Grenadines', 'vc', NULL),
(217, 'فنزويلا', 'Venezuela', NULL, 'Venezuela', 've', NULL),
(218, 'جزر العذراء البريطانية)', 'Virgin Islands (British)', NULL, 'Îles vierges britanniques', 'vg', NULL),
(219, 'جزر فيرجن (الولايات المتحدة)', 'Virgin Islands (U.S.)', NULL, 'Îles Vierges (États-Unis)', 'vi', NULL),
(220, 'فيتنام', 'Viet Nam', NULL, 'Viet Nam', 'vn', NULL),
(221, 'فانواتو', 'Vanuatu', NULL, 'Vanuatu', 'vu', NULL),
(222, 'واليس وفوتونا', 'Wallis and Futuna', NULL, 'Wallis et Futuna', 'wf', NULL),
(223, 'ساموا', 'Samoa', NULL, 'Samoa', 'ws', NULL),
(224, 'اليمن', 'Yemen', NULL, 'Yémen', 'ye', NULL),
(225, 'مايوت', 'Mayotte', NULL, 'Mayotte', 'yt', NULL),
(226, 'جنوب أفريقيا', 'South Africa', NULL, 'Afrique du Sud', 'za', NULL),
(227, 'زامبيا', 'Zambia', NULL, 'Zambie', 'zm', NULL),
(228, 'زائير (سابقة)', 'Zaire (former)', NULL, 'Zaïre (ancien)', 'zr', NULL),
(229, 'زيمبابوي', 'Zimbabwe', NULL, 'Zimbabwe', 'zw', NULL),
(230, 'الولايات المتحدة', 'United States of America', NULL, 'les États-Unis d\'Amérique', 'us', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `filters`
--

CREATE TABLE `filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `filters`
--

INSERT INTO `filters` (`id`, `name_ar`, `name_en`, `status`, `created_at`, `updated_at`) VALUES
(1, 'juns', 'جينس', '1', '2019-04-25 11:10:50', '2019-05-13 10:19:38'),
(2, 'تيشرت', 'Tchirt', '1', '2019-04-25 11:16:37', '2019-05-13 10:20:04'),
(3, 'موبايل سامسونج', 'mobile samsung', '1', '2019-05-13 10:23:50', '2019-05-13 10:23:50'),
(4, 'ساعات فاخرة', 'Smart Watches', '1', '2019-05-16 04:59:23', '2019-05-16 04:59:23');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `product_id`, `img`, `created_at`, `updated_at`) VALUES
(17, 7, 'product/larg/product_11556792792.jpg', '2019-05-02 08:26:34', '2019-05-02 08:26:34'),
(19, 7, 'product/larg/product_31556792794.jpg', '2019-05-02 08:26:35', '2019-05-02 08:26:35'),
(20, 7, 'product/larg/product_41556792795.jpg', '2019-05-02 08:26:35', '2019-05-02 08:26:35'),
(21, 7, 'product/larg/product_11556806207.jpg', '2019-05-02 12:10:09', '2019-05-02 12:10:09'),
(22, 9, 'product/larg/product_11557907158.jpg', '2019-05-15 05:59:20', '2019-05-15 05:59:20'),
(23, 10, 'product/larg/product_11557997457.jpg', '2019-05-16 07:04:20', '2019-05-16 07:04:20'),
(24, 11, 'product/larg/product_11557997487.jpg', '2019-05-16 07:04:49', '2019-05-16 07:04:49');

-- --------------------------------------------------------

--
-- Table structure for table `manufactors`
--

CREATE TABLE `manufactors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `manufactors`
--

INSERT INTO `manufactors` (`id`, `name_ar`, `name_en`, `img`, `status`, `created_at`, `updated_at`) VALUES
(1, 'أندورا', 'Andorra', 'manufactor/larg/Andorra_1556788664.png', '1', '2019-05-02 07:17:45', '2019-05-02 07:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_03_21_153633_create_categories_table', 1),
(2, '2014_04_21_153141_create_news_table', 1),
(3, '2014_04_21_153238_create_payments_table', 1),
(4, '2014_04_21_153303_create_sliders_table', 1),
(6, '2014_04_21_153339_create_settings_table', 1),
(7, '2014_04_21_153410_create_pages_table', 1),
(8, '2014_04_21_153609_create_filters_table', 1),
(10, '2014_04_21_153654_create_specifications_table', 1),
(11, '2014_04_21_153806_create_manufactors_table', 1),
(12, '2014_04_21_153825_create_contacts_table', 1),
(13, '2014_04_21_154234_create_catergories_news_table', 1),
(14, '2014_04_22_104810_create_specification_details_table', 1),
(15, '2014_09_21_152931_create_countries_table', 1),
(17, '2014_09_22_102232_create_cities_table', 1),
(18, '2014_09_23_153214_create_shipping_zones_table', 1),
(19, '2014_10_12_000000_create_users_table', 1),
(20, '2014_10_12_100000_create_password_resets_table', 1),
(21, '2019_04_21_153855_create_images_table', 1),
(22, '2019_04_22_132424_entrust_setup_tables', 1),
(23, '2019_04_24_135007_create_city_shipping_zone_table', 2),
(24, '2014_04_21_153322_create_ads_table', 3),
(25, '2019_04_29_095806_create_category_new_newsite_table', 4),
(26, '2019_04_30_134821_create_category_filter_table', 5),
(27, '2014_04_21_153653_create_sub__categories_table', 6),
(28, '2014_09_21_153916_create_products_table', 7),
(29, '2019_05_01_124156_create_product_specification_table', 8),
(30, '2019_04_21_153352_create_orders_table', 9),
(31, '2019_04_21_154155_create_orders_product_table', 9),
(32, '2019_05_12_085147_create_social_medias_table', 10),
(33, '2019_05_14_124328_create_wishlists_table', 11),
(34, '2019_05_16_074555_create_comments_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` longtext COLLATE utf8mb4_unicode_ci,
  `description_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description_en` text COLLATE utf8mb4_unicode_ci,
  `meta_description_ar` text COLLATE utf8mb4_unicode_ci,
  `tags` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title_ar`, `title_en`, `description_en`, `description_ar`, `meta_description_en`, `meta_description_ar`, `tags`, `image`, `status`, `slogen_ar`, `slogen_en`, `created_at`, `updated_at`) VALUES
(7, 'الخبر الجديد', NULL, NULL, '<p>هذا تغير رقم 40</p><p>\r\n                                                                    </p>', NULL, 'هذا ميتا 1', 'خبر هام,خبر عاجل', 'news/larg/news_1556543832.jpg', '0', 'الخبر-الجديد', '', '2019-04-29 10:26:37', '2019-04-29 11:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(10) UNSIGNED NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders_product`
--

CREATE TABLE `orders_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` longtext COLLATE utf8mb4_unicode_ci,
  `description_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title_ar`, `title_en`, `description_en`, `description_ar`, `img`, `status`, `slogen_ar`, `slogen_en`, `created_at`, `updated_at`) VALUES
(7, 'من نحن', 'about us', '<p><br></p><p style=\"text-align: center; border: 0px; box-sizing: inherit; margin-right: 0px; margin-bottom: 1em; margin-left: 0px; padding: 0px; vertical-align: baseline; background: 0px 0px rgb(246, 246, 246); color: rgb(34, 41, 47);\"><font face=\"Arial Black\">I had an issue with passing data from mySql database to my view blade.</font></p><p style=\"text-align: center; border: 0px; box-sizing: inherit; margin-right: 0px; margin-bottom: 1em; margin-left: 0px; padding: 0px; vertical-align: baseline; background: 0px 0px rgb(246, 246, 246); color: rgb(34, 41, 47);\"><font face=\"Arial Black\">I have car_categories blade create which it\'s using Form:text to input it to Database, and how can I get the data to my car view using Form:select ?</font></p><p style=\"text-align: center; border: 0px; box-sizing: inherit; margin-right: 0px; margin-bottom: 1em; margin-left: 0px; padding: 0px; vertical-align: baseline; background: 0px 0px rgb(246, 246, 246);\"><font face=\"Arial Black\" style=\"\" color=\"#21104a\">Here\'s my car create blade code</font></p><p>                                                                    </p><p></p>', '<p>من نحن </p><p>                                                                    </p><p></p>', 'page/larg/page_1557736912.png', '1', 'من-نحن', 'about-us', '2019-04-29 07:44:17', '2019-05-13 07:08:50'),
(8, 'معلومات التواصل', 'contact us', NULL, '<p>&#1605;&#1593;&#1604;&#1608;&#1605;&#1575;&#1575;&#1575;&#1575;&#1575;&#1578; &#1575;&#1604;&#1578;&#1608;&#1575;&#1589;&#1604;</p>\n', NULL, '1', 'معلومات-التواصل', 'contact-us', '2019-05-12 09:27:42', '2019-05-12 09:27:42'),
(9, 'الشروط والاحكام', 'terms and condetions', '<p>terms and condetions</p>\n', '<p>&#1575;&#1604;&#1588;&#1585;&#1608;&#1591; &#1608;&#1575;&#1604;&#1575;&#1581;&#1603;&#1575;&#1605;</p>\n', NULL, '1', 'الشروط-والاحكام', 'terms-and-condetions', '2019-05-12 09:28:46', '2019-05-12 09:28:46'),
(10, 'سياسة الخصوصية', 'policy', '<div class=\"row\" style=\"clear: both; position: relative; color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start;\"><p class=\"head1\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; text-align: center; color: rgb(244, 151, 25); font-size: 36px;\">Privacy Policy</p><div style=\"background: rgb(244, 151, 25); width: 1170px; max-width: 1170px; height: 2px;\"></div></div><div class=\"row\" style=\"clear: both; position: relative; color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; line-height: 22px;\"><br>Welcome to the jumia.com.eg website (the \"Site\"). jumia.com.eg is an Egyptian company under establishment and is part of RSC Internet Services Egypt. We respect your privacy and want to protect your personal information. To learn more, please read this Privacy Policy.&nbsp;<br><br>This Privacy Policy explains how we collect, use and (under certain conditions) disclose your personal information. This Privacy Policy also explains the steps we have taken to secure your personal information. Finally, this Privacy Policy explains your options regarding the collection, use and disclosure of your personal information. By visiting the Site directly or through another site, you accept the practices described in this Policy.<br><br>Data protection is a matter of trust and your privacy is important to us. We shall therefore only use your name and other information which relates to you in the manner set out in this Privacy Policy. We will only collect information where it is necessary for us to do so and we will only collect information if it is relevant to our dealings with you.<br><br>We will only keep your information for as long as we are either required to by law or as is relevant for the purposes for which it was collected.<br><br>You can visit the Site and browse without having to provide personal details. During your visit to the Site you remain anonymous and at no time can we identify you unless you have an account on the Site and log on with your user name and password.</div><div class=\"bgbox_grey\" style=\"border: 1px solid rgb(239, 239, 239); border-radius: 2px; background: rgb(248, 248, 248); color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; text-align: start; margin-top: 40px; font-size: 18px; padding: 20px 40px;\">Overview:&nbsp;<br><br><ul style=\"margin-bottom: 8.5px; list-style-type: decimal;\"><li><a href=\"https://www.jumia.com.eg/privacy/#q1\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">Data that we collect</a></li><li><a href=\"https://www.jumia.com.eg/privacy/#q2\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">Cookies</a></li><li><a href=\"https://www.jumia.com.eg/privacy/#q3\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">Security</a></li><li><a href=\"https://www.jumia.com.eg/privacy/#q4\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">Your rights</a></li></ul></div><div id=\"q1\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">1. Data that we collect</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; line-height: 22px; padding: 0px 22px;\">We may collect various pieces of information if you seek to place an order for a product with us on the Site.<br><br>We collect, store and process your data for processing your purchase on the Site and any possible later claims, and to provide you with our services. We may collect personal information including, but not limited to, your title, name, gender, date of birth, email address, postal address, delivery address (if different), telephone number, mobile number, fax number, payment details, payment card details or bank account details.<br><br>We will use the information you provide to enable us to process your orders and to provide you with the services and information offered through our website and which you request. Further, we will use the information you provide to administer your account with us; verify and carry out financial transactions in relation to payments you make online; audit the downloading of data from our website; improve the layout and/or content of the pages of our website and customize them for users; identify visitors on our website; carry out research on our users\' demographics; send you information we think you may find useful or which you have requested from us, including information about our products and services, provided you have indicated that you have not objected to being contacted for these purposes. Subject to obtaining your consent we may contact you by email with details of other products and services. If you prefer not to receive any marketing communications from us, you can opt out at any time.&nbsp;<br><br>We may pass your name and address on to a third party in order to make delivery of the product to you (for example to our courier or supplier).<br><br>Payments that you make through the Site will be processed by our agent Network International. You must only submit to us or our Agent or the Site information which is accurate and not misleading and you must keep it up to date and inform us of changes.&nbsp;<br><br>Your actual order details may be stored with us but for security reasons cannot be retrieved directly by us. However, you may access this information by logging into your account on the Site. Here you can view the details of your orders that have been completed, those which are open and those which are shortly to be dispatched and administer your address details, bank details and any newsletter to which you may have subscribed. You undertake to treat the personal access data confidentially and not make it available to unauthorized third parties. We cannot assume any liability for misuse of passwords unless this misuse is our fault.<br><br><span style=\"font-weight: 700;\">Other uses of your personal information</span><br>We may use your personal information for opinion and market research. Your details are anonymous and will only be used for statistical purposes. You can choose to opt out of this at any time. Any answers to surveys or opinion polls we may ask you to complete will not be forwarded on to third parties. Disclosing your email address is only necessary if you would like to take part in competitions. We save the answers to our surveys separately from your email address.<br><br>We may also send you other information about us, the Site, our other websites, our products, sales promotions, our newsletters, anything relating to other companies in our group or our business partners. If you would prefer not to receive any of this additional information as detailed in this paragraph (or any part of it) please click the \'unsubscribe\' link in any email that we send to you. Within 7 working days (days which are neither (i) a Friday nor Saturday, nor (ii) a public holiday anywhere in Egypt) of receipt of your instruction we will cease to send you information as requested. If your instruction is unclear we will contact you for clarification.<br><br>We may further anonymize data about users of the Site generally and use it for various purposes, including ascertaining the general location of the users and usage of certain aspects of the Site or a link contained in an email to those registered to receive them, and supplying that anonymized data to third parties such as publishers. However, that anonymized data will not be capable of identifying you personally.<br><br>By completing an order or signing up, you agree to receive a) emails associated with finalizing your order, which may contain relevant offers from third parties, and b) emails asking you to review Jumia and your purchase and c) promotional emails, SMS and push notifications from Jumia. You may unsubscribe from promotional emails via a link provided in each email. If you would like us to remove your personal information from our database, unsubscribe from emails and/or SMS, please email Customer Service email address by country.<br><br><span style=\"font-weight: 700;\">Competitions</span><br>For any competition we use the data to notify winners and advertise our offers. You can find more details where applicable in our participation terms for the respective competition.<br><br><span style=\"font-weight: 700;\">Third Parties and Links</span><br>We may pass your details to other companies in our group. We may also pass your details to our agents and subcontractors to help us with any of our uses of your data set out in our Privacy Policy. For example, we may use third parties to assist us with delivering products to you, to help us to collect payments from you, to analyze data and to provide us with marketing or customer service assistance. We may exchange information with third parties for the purposes of fraud protection and credit risk reduction. We may transfer our databases containing your personal information if we sell our business or part of it. Other than as set out in this Privacy Policy, we shall NOT sell or disclose your personal data to third parties without obtaining your prior consent unless this is necessary for the purposes set out in this Privacy Policy or unless we are required to do so by law. The Site may contain advertising of third parties and links to other sites or frames of other sites. Please be aware that we are not responsible for the privacy practices or content of those third parties or other sites, nor for any third party to whom we transfer your data in accordance with our Privacy Policy.</p></div><div id=\"q2\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">2. Cookies</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; line-height: 22px; padding: 0px 22px;\">The acceptance of cookies is not a requirement for visiting the Site. However we would like to point out that the use of the \'basket\' functionality on the Site and ordering is only possible with the activation of cookies. Cookies are tiny text files which identify your computer to our server as a unique user when you visit certain pages on the Site and they are stored by your Internet browser on your computer\'s hard drive. Cookies can be used to recognize your Internet Protocol address, saving you time while you are on, or want to enter, the Site. We only use cookies for your convenience in using the Site (for example to remember who you are when you want to amend your shopping cart without having to re-enter your email address) and not for obtaining or using any other information about you (for example targeted advertising). Your browser can be set to not accept cookies, but this would restrict your use of the Site. Please accept our assurance that our use of cookies does not contain any personal or private details and are free from viruses. If you want to find out more information about cookies, go to http://www.allaboutcookies.org or to find out about removing them from your browser, go to http://www.allaboutcookies.org/manage-cookies/index.html.<br><br>This website uses Google Analytics, a web analytics service provided by Google, Inc. (\"Google\"). Google Analytics uses cookies, which are text files placed on your computer, to help the website analyze how users use the site. The information generated by the cookie about your use of the website (including your IP address) will be transmitted to and stored by Google on servers in the United States. Google will use this information for the purpose of evaluating your use of the website, compiling reports on website activity for website operators and providing other services relating to website activity and internet usage. Google may also transfer this information to third parties where required to do so by law, or where such third parties process the information on Google\'s behalf. Google will not associate your IP address with any other data held by Google. You may refuse the use of cookies by selecting the appropriate settings on your browser, however please note that if you do this you may not be able to use the full functionality of this website. By using this website, you consent to the processing of data about you by Google in the manner and for the purposes set out above.</p></div><div id=\"q3\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">3. Security</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; line-height: 22px; padding: 0px 22px;\">We have in place appropriate technical and security measures to prevent unauthorized or unlawful access to or accidental loss of or destruction or damage to your information. When we collect data through the Site, we collect your personal details on a secure server. We use firewalls on our servers. When we collect payment card details electronically, we use encryption by using Secure Socket Layer (SSL) coding. While we are unable to guarantee 100% security, this makes it hard for a hacker to decrypt your details. You are strongly recommended not to send full credit or debit card details in unencrypted electronic communications with us. We maintain physical, electronic and procedural safeguards in connection with the collection, storage and disclosure of your information. Our security procedures mean that we may occasionally request proof of identity before we disclose personal information to you. You are responsible for protecting against unauthorized access to your password and to your computer.</p></div><div id=\"q4\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">4. Your rights</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; line-height: 22px; padding: 0px 22px;\">If you are concerned about your data you have the right to request access to the personal data which we may hold or process about you. You have the right to require us to correct any inaccuracies in your data free of charge. At any stage you also have the right to ask us to stop using your personal data for direct marketing purposes.</p></div>', '<div class=\"row\" style=\"clear: both; position: relative; color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; line-height: 22px;\">الخصوصيّة والسريّة شكرًا لدخولك إلى موقع jumia.com.eg (\"الموقع\") الذي تديره شركة RSC Internet Services Egypt. إنّ موقعنا يحترم خصوصيّتك ويسعى لحماية بياناتك الشخصية. لمعرفة المزيد، يُرجى قراءة سياسة الخصوصيّة أدناه.&nbsp;<br><br>توضح سياسة الخصوصيّة كيفية جمع واستخدام بياناتك الشخصية (تحت ظروفٍ معينةٍ). كما تذكرُ أيضًا الإجراءات المتبعة لضمان خصوصية معلوماتك. وأخيرًا، تُحدّد هذه السياسة الخيارات المتاحة لكَ فيما يتعلَّق بجمع البيانات الشخصية واستخدامها والكشف عنها. ومن خلال زيارتك للموقع مباشرةً أو عن طريق موقعٍ آخر، فأنتَ توافق على الممارسات الموضحة في هذه السياسة.<br><br>إن حماية بياناتك أمرٌ هامٌ جدًّا بالنسبة إلينا. ومن ثم، يتم استخدام اسمك وغيره من المعلومات التي تتعلّق بك وفقًا للّنحو المبيّن في سياسة الخصوصيّة. وسنقوم بجمع المعلومات عند الضرورة أو إذا كانت ذات صلةٍ ضرورية مباشرةٍ بمعاملاتنا معكَ.<br><br>وسنقوم بالاحتفاظ ببياناتك وفقًا للقانون أو لاستخدامها للأغراض التي جُمعت لأجلها.<br><br>ويمكنك تصفح الموقع دون الحاجة إلى تقديم أيّة بيانات شخصيّة. وتبقى هويّتك الشخصية مجهولة طيلة زيارتك للموقع ولا يتم كشفها إلا إذا كنتَ تملك حسابًا إلكترونياً خاصًا على الموقع تدخل إليه بواسطة اسم المستخدم وكلمة السرّ.</div><div class=\"bgbox_grey\" style=\"border: 1px solid rgb(239, 239, 239); border-radius: 2px; background: rgb(248, 248, 248); color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; text-align: start; margin-top: 40px; font-size: 18px; padding: 20px 40px;\"><ul style=\"margin-bottom: 8.5px; list-style-type: decimal;\"><li><a href=\"https://www.jumia.com.eg/ar/privacy/#q1\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">لبيانات التي نجمعها</a></li><li><a href=\"https://www.jumia.com.eg/ar/privacy/#q2\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">ملفات تعريف الارتباط (Cookies)</a></li><li><a href=\"https://www.jumia.com.eg/ar/privacy/#q3\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">الأمان</a></li><li><a href=\"https://www.jumia.com.eg/ar/privacy/#q4\" class=\"ques\" style=\"color: rgb(0, 0, 0);\">حقوق العميل</a></li></ul></div><div id=\"q1\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">لبيانات التي نجمعها</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; text-align: right; line-height: 22px; padding: 0px 22px;\">قد نحتاج لجمع المعلومات الخاصة بكَ إذا أردت تسجيل طلب شراء لسلعة من موقعنا.<br><br>ونقوم بجمع وتخزين ومعالجة بيانات لازمة لمتابعة شرائك من موقعنا لتأمين أية مطالب محتملة قد تظهر لاحقاً، ولتزويدكَ بالخدمات المتوفرة لدينا. وقد نقوم بجمع معلومات شخصية تتضمَّن، على سبيل المثال وليس الحصر، الاسم والجنس وتاريخ الميلاد وعنوان البريد الإلكتروني والعنوان البريدي وعنوان التسليم (إذا كان مختلفًا) ورقم الهاتف ورقم الهاتف المحمول ورقم الفاكس وتفاصيل الدفع وتفاصيل عن بطاقات الدفع أو تفاصيل عن الحساب المصرفي.<br><br>ونستخدم المعلومات التي تقدِّمها لتمكننا من معالجة طلباتك ولتزويدكَ بخدمات ومعلومات معروضة على موقعنا والتي تطلبها أنت. وعلاوةً على ذلك، سنستخدم المعلومات التي تقدَّمها في إدارة حسابك معنا وللتحقّقَ من المعاملات المالية التي تُجريها على الإنترنت وعمليات تدقيق تحميل البيانات من الموقع وتحديد هويّة زائري الموقع وتطوير تصميمات صفحات الموقع و/أو محتوياته وتخصيصها للمستخدمين. ونقوم بأبحاث عديدة متعلقة بالتركيبة السكانية، ونُرسل المعلومات المفيدة أو المطلوبة إلى المستخدم، على سبيل المثال معلومات حول المنتجات والخدمات، وذلك في حالة عدم اعتراضك على التواصل معك بشأن ذلك. ويتم التواصل عبر البريد الإلكتروني لتزويدك ببعض التفاصيل حول المنتجات والخدمات الأخرى إذا كنت ترغب في ذلك، وإذا كنتَ تفضّل عدم تلقي أية اتصالات ترويجيّة وتسويقيّة، فيُرجى الانسحاب من هذا الخيار في أي وقتٍ من الأوقات.&nbsp;<br><br>وقد نعطي اسمك وعنوانك إلى طرفٍ ثالث بهدف تسليمكَ طلب شرائك (على سبيل المثال، عامل التسليم أو المورِّد).<br><br>ويقوم وكيل شبكتنا الدولية بإدارة المعاملات المالية عبر الإنترنت. وما عليك فعله هو تقديم معلومات دقيقة وغير مضلّلة للوكيل أو الموقع، ويجدر بك تحديثها على الدوام وإبلاغنا بالتغييرات.&nbsp;<br><br>قد نتمكن من تخزين التفاصيل المتعلّقة بطلبك الحالي على موقعنا ولكن لا يمكننا استعادتها مباشرةً لأسبابٍ أمنيّة. وبتسجيل الدخول إلى حسابك على الموقع يمكنك الاطلاع على المعلومات وتفاصيل مشترياتك التي طلبتها أو التي ستتقدَّم بها قريبًا. وبمقدورك أيضاً إدارة تفاصيل عنوانك، والتفاصيل المصرفية وأية نشرةٍ إخباريةٍ قد اشتركت فيها. كما يجدر بك التعهُّد بالتعامل بسريّة تامة عند الدخول إلى بياناتك الشخصيَّة فلا تجعلها متاحة لطرف ثالث غير مصرَّح به. ولا نتحمَّل أية مسؤولية ناتجة عن سوء استخدام كلمات السر إلا إذا كان سوء الاستخدام هذا ناشئ عن خطأ منّا.<br><br><span style=\"font-weight: 700;\">استخدامات أخرى لمعلوماتك الشخصيَّة</span><br>قد نستخدم معلوماتك الشخصيَّة في استطلاعات الرأي وأبحاث التسويق، بناءً على رغبتك، لأغراضٍ إحصائية مع ضمان سريتها التامة، كما يحق لك الانسحاب في أيّ وقت. ولا نقوم بإرسال أي إجابات إلى أي طرف ثالث. ولا يتم الإفصاح عن عنوان بريدك الالكتروني إلا إذا رغبتَ في المشاركة في المسابقات. ونحتفظ بإجابات استطلاعات الرأي في مكانٍ منفصل تمامًا عن بريدك الإلكتروني الخاص.<br><br>وقد نقوم بإرسال معلومات عنَّا، أو عن الموقع أو مواقعنا الأخرى أو عن منتجاتنا أو مبيعاتنا أو عروض بيعنا أو نشراتنا وغير ذلك ممّا له علاقة بالشركات التابعة لمجموعتنا أو شُركائنا. وإذا كنت لا ترغب في الحصول على هذه المعلومات الإضافيّة (أو في أي جزءٍ منها)، فيُرجى الضغط على رابط \"إلغاء الاشتراك\" الموجود في أي بريد إلكتروني مرسل إليك، وسنتوقّف عن إرسال هذه المعلومات لك في غضون سبع أيام عمل (كل يوم عدا أيام الجمعة والسبت والأعياد الوطنيّة في جميع أنحاء جمهورية مصر العربية) من تلقي إخطارك. وسنتواصل معك للاستفسار عن المعلومات في حين عدم وضوحها.<br><br>وقد نستخدم بعض البيانات، مع الحفاظ التام على الخصوصيّة والسريّة على الموقع، لأغراض أخرى بما في ذلك التحقُّق من أماكن تواجد المستخدمين ومتابعة زيارتهم للموقع أو الروابط الواردة في البريد الإلكتروني في حين اشتراكهم لتلقيه، ولتزويد تلك البيانات مجهولة المصدر، التي لا تسمح بتحديد هويّتك الشخصيّة الفعليّة، إلى طرف ثالث كالنّاشرين على سبيل المثال. ومع ذلك، فتلك البيانات لن تؤدي إلى تحديد شخصيتك (لأنها غير محدّدة للهوية).<br><br><span style=\"font-weight: 700;\">المنافسات</span><br>فيما يتعلق بأي منافسة، نستخدم البيانات لإخطار الفائزين وللإعلان عن عروضنا. ويمكنك العثور على مزيد من التفاصيل عن شروط المشاركة في كل منافسة على حدة.<br><br><span style=\"font-weight: 700;\">الأطراف الثالثة وروابط المواقع</span><br>قد ننقل معلوماتك إلى شركات أخرى في مجموعتنا أو إلى وكلائنا والمتعاقدين معنا لمساعدتنا في المعاملات المتعلقة وفقا لبنود سياسة الخصوصية. وقد نلجأ على سبيل المثال إلى طرف ثالث لمعاونتنا في تسليم المنتجات إليك واستلام الدفعات منك واستخدامها لأغراض الإحصاءات وأبحاث التسويق أو لمساعدة فريق خدمة العملاء. وقد نحتاج لتبادل المعلومات مع طرف ثالث بهدف الحماية من الاحتيال والحد من مخاطر الائتمان. و في حال تمّ بيع شركتنا أو جزء منها، فقد نضطر لنقل قواعد بياناتنا التي تشمل معلوماتك الشخصيّة. وبخلاف ما هو منصوص عليه في سياسة الخصوصية، لن نقوم ببيع بياناتك الشخصية أو الإفصاح عنها لطرف ثالث دون الحصول على موافقة مسبقة منك إلّا إذا كان ذلك ضروريًا للأغراض المنصوص عليها في سياسة الخصوصيّة هذه، أو إذا طُلب منّا ذلك بحكم القانون. وقد يحتوي الموقع على إعلانات لطرف ثالث أو روابط تؤدِّي إلى مواقعٍ أخرى أو إطارات لمواقعٍ أخرى. ونحيطك علماً بأننا غير مسؤولين عن سياسة الخصوصيّة الخاصة بأي طرف ثالث أو محتوى تلك السياسات المطبّقة في المواقع الأخرى، فضلًا عن أنّنا غير مسؤولين إزاء أي طرف ثالث ننقل إليه بياناتك بما يتوافق مع سياسة الخصوصيّة.</p></div><div id=\"q2\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">ملفات تعريف الارتباط (Cookies)</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; text-align: right; line-height: 22px; padding: 0px 22px;\">لا يُعتبر قبول ملفات تعريف الارتباط شرطًا أساسيًا لزيارة الموقع. ولكنّنا نشير إلى أنّه لا يمكن استخدام وظائف \"السلّة\" على الموقع وطلب أي غرض من دون تفعيل ملفات تعريف الارتباط. وتُعتبر ملفات تعريف الارتباط ملفات نصيّة صغيرة تسمح لخادمنا بتحديد حاسوبك كمستخدم فريدٍ عند زيارة صفحات معينة من الموقع. ويخزِّن متصفّحك هذه الملفات على قرص حاسوبك الثابت. ويمكن استخدام ملفات تعريف الارتباط لاكتشاف عنوان بروتوكول الإنترنت (IP)، مما يوفّر لك الوقت عندما تكون على الموقع أو تريد زيارته. ونستخدم ملفات تعريف الارتباط لضمان راحتك عندما تتصفّح هذا الموقع (لنتذكر على سبيل المثال هويّتك عندما تريد تعديل سلّة تسوقك بدون الحاجة إلى إعادة إدخال عنوان بريدك الإلكتروني) وليس من أجل الحصول على معلومات أخرى عنك أو استخدامها (مثلاً لأغراض التسويق المستهدف). ويمكنك ضبط متصفحك حتى لا يقبل ملفات تعريف الارتباط ولكن هذا من شأنه أن يحدّ من استخدامك للموقع. ونرجو أن تتأكد من أنّ لجوءنا إلى ملفات تعريف الارتباط لا يحتوي على أية معلومات شخصية أو خاصة ويخلو من الفيروسات. وفي حال تريد معرفة المزيد عن هذه الملفات، راجع موقع http://www.allaboutcookies.org أو في حالة معرفة كيفية حذفها من متصفحك، راجع موقع http://www.allaboutcookies.org/manage-cookies/index.html. ويستخدم هذا الموقع خدمة تحليلات جوجل (Google Analytics) وهي خدمة تقدّمها شركة جوجل لتحليل صفحات شبكة الإنترنت. ولتحليل كيفية استخدام المستخدمين للموقع، ترتكز خدمة تحليلات جوجل على ملفات تعريف الارتباط وهي ملفات نصيّة وُضعت على حاسوبك. وستنقل شركة جوجل المعلومات التي تولّدها ملفات تعريف الارتباط عن استخدامك لهذا الموقع (بما في ذلك عنوان بروتوكول الإنترنت) إلى خوادم في الولايات المتحدة حيث سيتم تخزينها. وسوف تستخدم شركة جوجل هذه المعلومات لتقييم استخدامك للموقع، وإعداد تقارير لمشغلي الموقع عن نشاطه وتوفير خدمات أخرى مرتبطة بنشاط الموقع واستخدام الإنترنت. وقد تنقل جوجل أيضاً هذه المعلومات إلى طرف ثالث في حال طُلب منها ذلك بموجب القانون أو في حال عالج طرف ثالث المعلومات بالنيابة عن شركة جوجل. ولن تربط شركة جوجل عنوان بروتوكول الإنترنت خاصتكَ مع أيّة بيانات أخرى تحتفظ بها. ويمكنك رفض استخدام ملفات تعريف الارتباط وذلك عن طريق اختيار الإعدادات المناسبة على متصفحك ولكن ترجو أن تأخذ بعين الاعتبار أنّك عندئذ لن تستطيع الاستفادة من وظيفة الموقع الكاملة. ومن خلال استخدامك هذا الموقع، فأنت توافق على أن تستخدم شركة جوجل بياناتك على النحو المبين والأغراض المفصَّلة أعلاه.</p></div><div id=\"q3\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">الأمان</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; text-align: right; line-height: 22px; padding: 0px 22px;\">نستخدم تقنيات وإجراءات أمان ملائمة لمنع أي وصول غير مصرَّح به أو غير قانوني لمعلوماتك أو فقدانها أو تدميرها. فعندما نجمع البيانات من خلال الموقع، نقوم بتخزين معلوماتك الشخصية على قاعدة بيانات ضمن خادم إلكتروني آمن. فنستخدم أنظمة جدار الحماية على خوادمنا. وعندما نقوم بجمع تفاصيل بطاقات الدفع إلكترونيًا، فإننا نحميها من خلال استخدام التشفير، مثل طبقة مآخذ التوصيل الآمنة (SSL). فيصعب بالتّالي على أيّ متسلّلٍ فكّ تشفير معلوماتك بما أنّنا لا نستطيع ضمان الحماية بنسبة مئة في المئة. وننصحك بشدَّة بعدم إرسال كل تفاصيل بطاقة الائتمان أو بطاقة السحب الآلي عندما تتواصل معنا إلكترونيًا ومن دون تشفير. ونضع ضمانات ماديّة وإلكترونية وإجرائيّة مباشرة على عملية جمع معلوماتك وتخزينها والإفصاح عنها. وتتطلّب إجراءاتنا الأمنية أن نطلب منك أحياناً إثبات هويتك قبل أن نُفصِح لك عن معلوماتك الشخصية. وتقع على عاتقك مسؤولية حماية كلمتك السريّة وحاسوبك من أيّ استخدام غير مصرَّح به.</p></div><div id=\"q4\" style=\"color: rgb(85, 85, 85); font-family: Tahoma, Geneva, sans-serif; font-size: 12px; text-align: start; margin: 30px 0px;\"><div class=\"question listformat\" style=\"font-size: 18px; color: rgb(244, 151, 25); margin: 20px 0px;\">حقوق العميل</div><p class=\"txt\" style=\"margin-right: 0px; margin-bottom: 8.5px; margin-left: 0px; text-align: right; line-height: 22px; padding: 0px 22px;\">في حال شعورك بالقلق على بياناتك، يحق لك طلب الوصول إلى البيانات الشخصيّة التي نحملها عنك أو سبق ونقلتها إلينا. ويحق لك أن تطلب منَّا تصحيح أي أخطاء في بياناتك الشخصيّة ويتم ذلك مجانًا. ولك الحق أيضًا في مطالبتنا، في أي وقت، بالتوقُّف عن استخدام بياناتك الشخصية لأغراض تسويقيّة مباشرة.</p></div>', NULL, '1', 'سياسة-الخصوصية', 'policy', '2019-05-12 09:29:28', '2019-05-13 09:39:27');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('sara@admin.com', '$2y$10$PdmTouB.y4C.Lwcw4ilYTupMceq7hynBIMZddfdSCpcrzlH2GET/i', '2019-05-13 04:32:48');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `name_ar`, `name_en`, `status`, `created_at`, `updated_at`) VALUES
(2, 'البنك الاهلي', NULL, '1', '2019-04-25 11:57:40', '2019-04-25 11:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Create Record', 'Allow user to create a new DB record', '2019-04-23 07:30:41', '2019-04-23 07:30:41'),
(2, 'edit', 'Edit Record', 'Allow user to edit an existing DB record', '2019-04-23 07:30:42', '2019-04-23 07:30:42'),
(3, 'delete', 'Delete Record', 'Allow user to delete an existing DB record', '2019-04-23 07:30:42', '2019-04-23 07:30:42'),
(4, 'user', 'Manage User', 'Allow user to manage system user', '2019-04-23 07:30:42', '2019-05-02 12:42:29');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 10),
(2, 10),
(3, 10),
(4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_ar` longtext COLLATE utf8mb4_unicode_ci,
  `description_en` longtext COLLATE utf8mb4_unicode_ci,
  `tag_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double NOT NULL,
  `discount_price` double DEFAULT NULL,
  `discount_from` datetime DEFAULT NULL,
  `discount_to` datetime DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `subcategory_id` int(10) UNSIGNED NOT NULL,
  `manufactor_id` int(10) UNSIGNED DEFAULT NULL,
  `texes` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name_ar`, `name_en`, `description_ar`, `description_en`, `tag_ar`, `tag_en`, `image`, `price`, `discount_price`, `discount_from`, `discount_to`, `quantity`, `slogen_ar`, `slogen_en`, `status`, `subcategory_id`, `manufactor_id`, `texes`, `created_at`, `updated_at`) VALUES
(7, 'اتصالات كاش', 'etislat cashe', 'hgh', 'gh', 'jk,lk', 'ddf,dfd', 'product/larg/product_11556792792.jpg', 110, 98, '2019-05-08 00:00:00', '2019-05-22 00:00:00', 5, 'اتصالات-كاش', 'etislat-cashe', '1', 2, 1, '1', '2019-05-02 08:26:32', '2019-05-02 12:10:07'),
(8, 'كاش', 'cashe', 'hgh', 'gh', 'jk,lk', 'ddf,dfd', 'product/larg/product_11556792792.jpg', 100, NULL, '2019-05-08 00:00:00', '2019-05-22 00:00:00', 5, 'اتصالات-كاش', 'etislat-cashe', '1', 2, 1, '1', '2019-05-15 08:26:32', '2019-05-15 18:10:07'),
(9, 'منتج 3', 'product 3', 'منتج 3', NULL, NULL, NULL, NULL, 150, NULL, NULL, NULL, 5, 'منتج-3', 'product-3', '1', 1, 1, '1', '2019-05-15 05:59:18', '2019-05-15 05:59:18'),
(10, 'تيشرت زارا', 'T-chert', 'تيشرت من ماركة زارا', 'T-chert', 'hg ,fgg', NULL, NULL, 100, NULL, NULL, NULL, 50, 'تيشرت-زارا', 't-chert', '1', 1, 1, '1', '2019-05-16 07:04:17', '2019-05-16 07:04:17'),
(11, 'تيشرت زارا', 'T-chert', 'تيشرت من ماركة زارا', 'T-chert', 'hg ,fgg', NULL, NULL, 100, NULL, NULL, NULL, 50, 'تيشرت-زارا', 't-chert', '1', 1, 1, '1', '2019-05-16 07:04:47', '2019-05-16 07:04:47');

-- --------------------------------------------------------

--
-- Table structure for table `product_specification`
--

CREATE TABLE `product_specification` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `specification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specification_deltails` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_specification`
--

INSERT INTO `product_specification` (`id`, `product_id`, `specification`, `specification_deltails`, `created_at`, `updated_at`) VALUES
(14, 11, 'لون', 'اسود,ازرق', '2019-05-16 07:04:49', '2019-05-16 07:04:49');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(2, 'user', 'User', 'User can Show  data in the system and order any Thing', '2019-04-23 07:31:03', '2019-04-23 07:31:03'),
(10, 'Admin', 'Admin', 'Full Permission', '2019-04-23 08:59:15', '2019-04-23 08:59:15'),
(14, 'superAdmin', 'Admin', 'Full Permission', '2019-04-23 09:42:40', '2019-04-23 09:42:40');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `taxes_parst` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description_ar` text COLLATE utf8mb4_unicode_ci,
  `meta_description_en` text COLLATE utf8mb4_unicode_ci,
  `meta_tags` text COLLATE utf8mb4_unicode_ci,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `store_name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `head_code` text COLLATE utf8mb4_unicode_ci,
  `maintans_status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `taxes_parst`, `meta_description_ar`, `meta_description_en`, `meta_tags`, `meta_title`, `store_name_ar`, `owner_name_ar`, `phone`, `address`, `whatsapp`, `email`, `store_img`, `logo_img`, `icon_img`, `head_code`, `maintans_status`, `notes`, `created_at`, `updated_at`) VALUES
(1, '20', NULL, NULL, 'موقع الكتروني', NULL, 'زارا', NULL, '+4 1234 - 4567 - 67', '300 شارع الهرم الرئيسي و الطالبية', NULL, 'info@admin.com', 'setting/store_img_1556553560.jpg', 'setting/store_img_1557656144.png', NULL, NULL, '0', NULL, NULL, '2019-05-13 10:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_zones`
--

CREATE TABLE `shipping_zones` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `type` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping_zones`
--

INSERT INTO `shipping_zones` (`id`, `name_ar`, `name_en`, `status`, `type`, `price`, `created_at`, `updated_at`) VALUES
(12, 'dd', 'df', '1', '1', NULL, '2019-04-25 08:42:59', '2019-04-25 08:42:59'),
(13, 'dd', 'df', '1', '1', NULL, '2019-04-25 08:43:16', '2019-04-25 08:43:16'),
(14, 'zone2', NULL, '1', '0', 45, '2019-05-09 08:26:47', '2019-05-09 08:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci,
  `title_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_desc_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_desc_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_ar` text COLLATE utf8mb4_unicode_ci,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `img`, `link`, `title_ar`, `title_en`, `short_desc_ar`, `short_desc_en`, `description_ar`, `description_en`, `status`, `created_at`, `updated_at`) VALUES
(2, 'slider/larg/news_1557316348.jpg', NULL, 'الصورة الاولي', NULL, NULL, NULL, NULL, NULL, '1', '2019-05-08 09:52:28', '2019-05-08 09:52:28');

-- --------------------------------------------------------

--
-- Table structure for table `social_medias`
--

CREATE TABLE `social_medias` (
  `id` int(10) UNSIGNED NOT NULL,
  `fb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tw` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instegram` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinterest` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rss` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_medias`
--

INSERT INTO `social_medias` (`id`, `fb`, `tw`, `instegram`, `linkedin`, `youtube`, `pinterest`, `rss`, `created_at`, `updated_at`) VALUES
(1, 'www.facebook.com', 'twitter.com', NULL, NULL, NULL, NULL, 'rss.com', NULL, '2019-05-12 08:03:26');

-- --------------------------------------------------------

--
-- Table structure for table `specifications`
--

CREATE TABLE `specifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `type` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `filter_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `specifications`
--

INSERT INTO `specifications` (`id`, `name_ar`, `name_en`, `tag_ar`, `tag_en`, `order`, `status`, `type`, `filter_id`, `created_at`, `updated_at`) VALUES
(3, 'لون', 'color', 'اسود,ازرق,اخضر', 'black,blue,green', 1, '1', '0', 2, '2019-04-30 08:43:44', '2019-05-15 05:51:42'),
(4, 'الموديل', 'model', 'جلاكسي', 'Glaxy', 1, '1', '0', 2, '2019-04-30 08:44:56', '2019-05-16 05:18:20'),
(5, 'شاشة', 'screen', 'x,y', 'y,b', 2, '1', '1', NULL, '2019-05-16 08:42:08', '2019-05-16 08:42:08');

-- --------------------------------------------------------

--
-- Table structure for table `specification_details`
--

CREATE TABLE `specification_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `specification_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `specification_details`
--

INSERT INTO `specification_details` (`id`, `name_ar`, `name_en`, `status`, `specification_id`, `created_at`, `updated_at`) VALUES
(9, 'احمر', 'red', '1', 3, '2019-05-13 10:21:51', '2019-05-13 10:21:51'),
(12, 'اسود', 'black', '1', 3, '2019-05-13 10:21:51', '2019-05-13 10:21:51'),
(13, 'ازرق', 'blue', '1', 3, '2019-05-13 10:21:51', '2019-05-13 10:21:51'),
(14, 'اخضر', 'green', '1', 3, '2019-05-13 10:21:51', '2019-05-13 10:21:51'),
(16, 'جلاكسي', 'Glaxy', '1', 4, '2019-05-16 05:18:20', '2019-05-16 05:18:20'),
(17, 'x', 'y', '1', 5, '2019-05-16 08:42:08', '2019-05-16 08:42:08'),
(18, 'y', 'b', '1', 5, '2019-05-16 08:42:08', '2019-05-16 08:42:08');

-- --------------------------------------------------------

--
-- Table structure for table `sub__categories`
--

CREATE TABLE `sub__categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` longtext COLLATE utf8mb4_unicode_ci,
  `tag_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `slogen_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slogen_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub__categories`
--

INSERT INTO `sub__categories` (`id`, `name_ar`, `name_en`, `description_ar`, `description_en`, `tag_ar`, `tag_en`, `image`, `status`, `created_at`, `updated_at`, `category_id`, `slogen_ar`, `slogen_en`) VALUES
(1, 'ملابس رجالي', 'man clothes', 'sda', NULL, 'dd,\'kjk', NULL, 'subcategory/larg/Category_1556644807.jpg', '1', '2019-04-30 15:20:09', '2019-05-13 10:18:48', 4, 'ملابس-رجالي', 'man-clothes'),
(2, 'موبيل', 'mobile', 'dsd', NULL, NULL, NULL, NULL, '1', '2019-04-30 15:21:52', '2019-05-13 10:25:59', 5, 'موبيل', 'mobile'),
(3, 'يسسي', 'a', 'بلبييلبي', NULL, NULL, NULL, NULL, '1', '2019-05-01 07:37:51', '2019-05-01 07:37:51', 3, 'يسسي', 'a'),
(4, 'بللبلب', 'b', 'يبل', NULL, NULL, NULL, NULL, '1', '2019-05-01 07:39:34', '2019-05-01 07:39:34', 3, 'بللبلب', 'b'),
(5, 'يب', 'c', 'يب', NULL, NULL, NULL, NULL, '1', '2019-05-01 07:40:11', '2019-05-01 07:40:11', 3, 'يب', 'c');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` int(10) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `phone`, `address`, `zipcode`, `notes`, `email`, `password`, `city_id`, `country_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'sara', 'admin', '01221292134', 'giza fisal', NULL, NULL, 'sara@admin.com', '$2y$10$gtvAJyOWFlmd4tzov3O4z.zu0DQ/iYkxg3d7Q4UDI.DFO9fBEkFqi', 934, 59, 'LwqV1A2bDq7ASNeyYJT5Xft7QHLz9dL2kNl3Xs51B0bcKBoHwQcDXPwGX844', NULL, '2019-05-14 10:33:30'),
(2, 'sara', 'adel', '01221292134', 'abcd', NULL, NULL, 'saraadelalshora@yahoo.com', '$2y$10$gtvAJyOWFlmd4tzov3O4z.zu0DQ/iYkxg3d7Q4UDI.DFO9fBEkFqi', 934, 59, 'IWjUk4TMNIF34WF8Ka9hXR7RCYbd8kDmi4bSChMchNSGxGHAhzf06nXvYoRI', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_filter`
--
ALTER TABLE `category_filter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_filter_category_id_foreign` (`category_id`),
  ADD KEY `category_filter_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `category_new_newsite`
--
ALTER TABLE `category_new_newsite`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_new_newsite_category_id_foreign` (`category_id`),
  ADD KEY `category_new_newsite_newsite_id_foreign` (`newsite_id`);

--
-- Indexes for table `catergories_news`
--
ALTER TABLE `catergories_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cities_country_id_index` (`country_id`);

--
-- Indexes for table `city_shipping_zone`
--
ALTER TABLE `city_shipping_zone`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `city_shipping_zone_city_id_unique` (`city_id`),
  ADD KEY `city_shipping_zone_zone_id_foreign` (`zone_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_product_id_foreign` (`product_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filters`
--
ALTER TABLE `filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_product_id_index` (`product_id`);

--
-- Indexes for table `manufactors`
--
ALTER TABLE `manufactors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `orders_product`
--
ALTER TABLE `orders_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_product_order_id_foreign` (`order_id`),
  ADD KEY `orders_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_subcategory_id_index` (`subcategory_id`),
  ADD KEY `products_manufactor_id_index` (`manufactor_id`);

--
-- Indexes for table `product_specification`
--
ALTER TABLE `product_specification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_specification_product_id_foreign` (`product_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_zones`
--
ALTER TABLE `shipping_zones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_medias`
--
ALTER TABLE `social_medias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specifications`
--
ALTER TABLE `specifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `specifications_filter_id_index` (`filter_id`);

--
-- Indexes for table `specification_details`
--
ALTER TABLE `specification_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `specification_details_specification_id_index` (`specification_id`);

--
-- Indexes for table `sub__categories`
--
ALTER TABLE `sub__categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub__categories_category_id_index` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_city_id_index` (`city_id`),
  ADD KEY `users_country_id_index` (`country_id`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlists_product_id_foreign` (`product_id`),
  ADD KEY `wishlists_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category_filter`
--
ALTER TABLE `category_filter`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category_new_newsite`
--
ALTER TABLE `category_new_newsite`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `catergories_news`
--
ALTER TABLE `catergories_news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1991;

--
-- AUTO_INCREMENT for table `city_shipping_zone`
--
ALTER TABLE `city_shipping_zone`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `filters`
--
ALTER TABLE `filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `manufactors`
--
ALTER TABLE `manufactors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders_product`
--
ALTER TABLE `orders_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product_specification`
--
ALTER TABLE `product_specification`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shipping_zones`
--
ALTER TABLE `shipping_zones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `social_medias`
--
ALTER TABLE `social_medias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `specifications`
--
ALTER TABLE `specifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `specification_details`
--
ALTER TABLE `specification_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `sub__categories`
--
ALTER TABLE `sub__categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_filter`
--
ALTER TABLE `category_filter`
  ADD CONSTRAINT `category_filter_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `sub__categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `category_filter_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `filters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `category_new_newsite`
--
ALTER TABLE `category_new_newsite`
  ADD CONSTRAINT `category_new_newsite_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `catergories_news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `category_new_newsite_newsite_id_foreign` FOREIGN KEY (`newsite_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `city_shipping_zone`
--
ALTER TABLE `city_shipping_zone`
  ADD CONSTRAINT `city_shipping_zone_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `city_shipping_zone_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `shipping_zones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders_product`
--
ALTER TABLE `orders_product`
  ADD CONSTRAINT `orders_product_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_manufactor_id_foreign` FOREIGN KEY (`manufactor_id`) REFERENCES `manufactors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `sub__categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_specification`
--
ALTER TABLE `product_specification`
  ADD CONSTRAINT `product_specification_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `specifications`
--
ALTER TABLE `specifications`
  ADD CONSTRAINT `specifications_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `specification_details`
--
ALTER TABLE `specification_details`
  ADD CONSTRAINT `specification_details_specification_id_foreign` FOREIGN KEY (`specification_id`) REFERENCES `specifications` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sub__categories`
--
ALTER TABLE `sub__categories`
  ADD CONSTRAINT `sub__categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
